#!/usr/bin/env python3
"""Integration test for the full athlete body transplant."""
import sys
sys.path.insert(0, '/home/claude/agent-swarm')

print('Testing imports...')

print('1. config/markets.py...', end=' ')
from config.markets import ASSETS, ASSETS_BY_MARKET, MARKET_THRESHOLDS, CORRELATION_MAP
from config.markets import get_correlation, CORRELATION_BLOCK_THRESHOLD
from config.markets import ASSET_OVERRIDES, REGIMES, ExitConfig, get_default_exit_configs
print(f'OK — {len(ASSETS)} assets, {len(ASSETS_BY_MARKET)} markets')

print('2. execution/atr_stops.py...', end=' ')
from execution.atr_stops import compute_atr, calculate_stops, compute_position_risk
sl, tp = calculate_stops(97000, 'buy', 0.015, 'RISK_ON_TRENDING')
print(f'OK — BTC buy: SL={sl:.0f}, TP={tp:.0f}')

print('3. execution/profit_progression.py...', end=' ')
from execution.profit_progression import ProfitProgressionEngine, ProgressionState, ExitDecision
pp = ProfitProgressionEngine()
state = pp.init_state(97000, 0.01, 95000, 100000, 970, 0.015)
print(f'OK — state initialized, peak_pnl={state.peak_pnl_pct}')

print('4. execution/engine.py imports...', end=' ')
import ast
with open('/home/claude/agent-swarm/execution/engine.py') as f:
    ast.parse(f.read())
print('OK — syntax valid')

print('5. database/learning.py...', end=' ')
with open('/home/claude/agent-swarm/database/learning.py') as f:
    ast.parse(f.read())
print('OK — syntax valid')

print('6. execution/capital_allocator.py...', end=' ')
with open('/home/claude/agent-swarm/execution/capital_allocator.py') as f:
    ast.parse(f.read())
print('OK — syntax valid')

print('7. agents/screener_agent.py...', end=' ')
with open('/home/claude/agent-swarm/agents/screener_agent.py') as f:
    ast.parse(f.read())
print('OK — syntax valid')

print('8. hedge_fund/bootstrap.py...', end=' ')
with open('/home/claude/agent-swarm/hedge_fund/bootstrap.py') as f:
    ast.parse(f.read())
print('OK — syntax valid')

# ATR stop tests across regimes
print()
print('=== ATR STOP TESTS (BTC buy @ $97,000, ATR=1.5%) ===')
for regime in ['RISK_OFF_VOLATILE', 'RANGING', 'RISK_ON_TRENDING', 'BREAKOUT']:
    sl, tp = calculate_stops(97000, 'buy', 0.015, regime)
    sl_pct = abs(97000 - sl) / 97000 * 100
    tp_pct = abs(tp - 97000) / 97000 * 100
    print(f'  {regime:20s} SL: {sl_pct:.2f}% (${sl:,.0f}) | TP: {tp_pct:.2f}% (${tp:,.0f})')

# Test with forex (much tighter)
print()
print('=== ATR STOPS: EURUSD buy @ $1.048, ATR=0.3% ===')
for regime in ['RISK_OFF_VOLATILE', 'RANGING', 'RISK_ON_TRENDING']:
    sl, tp = calculate_stops(1.048, 'buy', 0.003, regime)
    sl_pct = abs(1.048 - sl) / 1.048 * 100
    tp_pct = abs(tp - 1.048) / 1.048 * 100
    print(f'  {regime:20s} SL: {sl_pct:.3f}% (${sl:.5f}) | TP: {tp_pct:.3f}% (${tp:.5f})')

# Correlation filter
print()
print('=== CORRELATION FILTER (threshold: {:.2f}) ==='.format(CORRELATION_BLOCK_THRESHOLD))
pairs = [('BTC','ETH'), ('BTC','SPY'), ('GLD','SLV'), ('SPY','TLT'), ('BTC','GLD')]
for a, b in pairs:
    c = get_correlation(a, b)
    blocked = 'BLOCKED' if c >= CORRELATION_BLOCK_THRESHOLD else 'allowed'
    print(f'  {a:6s}-{b:6s}: {c:+.2f} -> {blocked}')

# Profit progression stages
print()
print('=== PROFIT PROGRESSION STAGES ===')
pp = ProfitProgressionEngine()
state = pp.init_state(100.0, 10.0, 95.0, 110.0, 1000.0, 0.02)
ecfg = {
    'trail_mult': 1.5, 'breakeven_at': 1.0, 'partial_at': 1.5,
    'partial_pct': 0.5, 'extend_tp': True, 'behavior': 'neutral'
}

# Simulate price going up then reversing
prices_up = [100, 101, 102, 103, 104, 105, 106]
prices_down = [105, 104, 103, 102, 101]
all_prices = prices_up + prices_down

history = [100.0] * 15
current_qty = 10.0
current_sl = 95.0
current_tp = 110.0

for p in all_prices:
    history.append(p)
    d = pp.evaluate(
        state, p, 100.0, 'buy', current_qty, current_qty * 100,
        current_sl, current_tp, ecfg, 'RISK_ON_TRENDING', history
    )
    
    events = []
    if d.sl_moved:
        events.append(f'SL->{d.new_stop_loss:.2f}')
        current_sl = d.new_stop_loss
    if d.tp_moved:
        events.append(f'TP->{d.new_take_profit:.2f}')
        current_tp = d.new_take_profit
    if d.progression_event:
        events.append(d.progression_event)
    if d.should_close:
        events.append(f'CLOSE:{d.close_reason}(qty={d.close_qty:.1f})')
        if d.close_reason == 'partial':
            current_qty -= d.close_qty
    
    if events:
        pnl_pct = (p - 100) / 100 * 100
        print(f'  ${p:6.2f} (P&L:{pnl_pct:+.1f}%) -> {" | ".join(events)}')

print(f'\n  Stats: {pp.stats}')

# Asset overrides
print()
print('=== ASSET OVERRIDES ===')
for sym, override in ASSET_OVERRIDES.items():
    print(f'  {sym:6s}: min_confidence={override.min_confidence:.2f}, pos_mult={override.position_mult:.2f}')

# Market thresholds
print()
print('=== MARKET THRESHOLDS (Steroid C) ===')
for mkt, thresh in MARKET_THRESHOLDS.items():
    print(f'  {mkt:12s}: breakout={thresh.breakout_pct:.1%}, vol_spike={thresh.vol_spike_mult:.1%}, min_hold={thresh.min_hold_ticks}')

# Exit configs
print()
print('=== DEFAULT EXIT CONFIGS ===')
configs = get_default_exit_configs()
print(f'  {len(configs)} assets configured with defaults')
print(f'  Sample (BTC): trail={configs["BTC"].trail_mult}x, breakeven={configs["BTC"].breakeven_at}x, partial={configs["BTC"].partial_pct:.0%}')

print()
print('=' * 60)
print('ALL IMPORTS AND FUNCTIONAL TESTS PASSED')
print('=' * 60)
