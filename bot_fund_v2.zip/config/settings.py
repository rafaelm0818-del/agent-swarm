"""
Agent Swarm Configuration
"""
import os
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class Settings:
    # API Keys
    ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
    TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    
    # Allowed Telegram user IDs (security - only you can use the bot)
    ALLOWED_USERS: list[int] = field(default_factory=lambda: [
        int(uid) for uid in os.getenv("ALLOWED_TELEGRAM_USERS", "").split(",") if uid
    ])
    
    # Claude model config
    MODEL: str = "claude-sonnet-4-20250514"
    MAX_TOKENS: int = 4096
    
    # Agent-specific settings
    TRADING_DATA_DIR: str = os.getenv("TRADING_DATA_DIR", "./data/trading")
    CODE_WORKSPACE_DIR: str = os.getenv("CODE_WORKSPACE_DIR", "./data/workspace")
    SCRAPE_CACHE_DIR: str = os.getenv("SCRAPE_CACHE_DIR", "./data/scrape_cache")
    
    # Redis for task queue (optional, for async tasks)
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    
    # Rate limiting
    MAX_CONCURRENT_TASKS: int = 3
    TASK_TIMEOUT_SECONDS: int = 300  # 5 min per task

settings = Settings()
