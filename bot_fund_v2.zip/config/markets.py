"""
Market Configuration — The DNA

20 assets across 5 markets. Every parameter stress-tested
across 6 scenarios and tuned by 6 steroids.

This module is the single source of truth for:
  - Asset universe (symbols, prices, volatility, market, beta)
  - Market-calibrated signal thresholds (Steroid C)
  - Correlation map for duplicate exposure blocking (Steroid B)
  - Asset overrides for high-vol demotion (Fix 3)
  - Self-tuning exit config defaults (Profit Progression)
"""
from dataclasses import dataclass, field

# ═══════════════════════════════════════════════════════════════
#  ASSET UNIVERSE — 20 assets, 5 markets
# ═══════════════════════════════════════════════════════════════

@dataclass
class AssetConfig:
    symbol: str
    price: float            # Reference price (updated live)
    vol: float              # Historical daily volatility (decimal)
    market: str             # crypto, stocks, etf, commodity, forex
    beta: float             # Correlation to BTC (crypto benchmark)
    exchange: str = ""      # Where to execute (coinbase, traderspost, etc.)
    min_order: float = 0.0  # Minimum order size in USD
    active: bool = True

ASSETS: dict[str, AssetConfig] = {
    # ── Crypto (high vol, high beta) ──
    "BTC":    AssetConfig("BTC",    97000, 0.015, "crypto",    1.0,  "coinbase",      10),
    "ETH":    AssetConfig("ETH",    3200,  0.018, "crypto",    1.2,  "coinbase",      10),
    "SOL":    AssetConfig("SOL",    185,   0.025, "crypto",    1.5,  "coinbase",      5),
    "XRP":    AssetConfig("XRP",    2.45,  0.022, "crypto",    1.3,  "coinbase",      5),
    "AVAX":   AssetConfig("AVAX",   38,    0.028, "crypto",    1.6,  "coinbase",      5),
    "LINK":   AssetConfig("LINK",   19,    0.020, "crypto",    1.1,  "coinbase",      5),
    # ── Stocks (low vol, low beta) ──
    "AAPL":   AssetConfig("AAPL",   232,   0.010, "stocks",    0.4,  "traderspost",   20),
    "NVDA":   AssetConfig("NVDA",   138,   0.016, "stocks",    0.7,  "traderspost",   20),
    "TSLA":   AssetConfig("TSLA",   340,   0.020, "stocks",    0.9,  "traderspost",   20),
    "MSFT":   AssetConfig("MSFT",   410,   0.008, "stocks",    0.3,  "traderspost",   20),
    "AMZN":   AssetConfig("AMZN",   225,   0.009, "stocks",    0.4,  "traderspost",   20),
    # ── ETFs (very low vol, mix of beta) ──
    "SPY":    AssetConfig("SPY",    598,   0.006, "etf",       0.3,  "traderspost",   20),
    "QQQ":    AssetConfig("QQQ",    520,   0.008, "etf",       0.5,  "traderspost",   20),
    "IWM":    AssetConfig("IWM",    225,   0.009, "etf",       0.4,  "traderspost",   20),
    "TLT":    AssetConfig("TLT",    88,    0.007, "etf",      -0.3,  "traderspost",   20),
    # ── Commodities (low vol, negative/low beta — hedges) ──
    "GLD":    AssetConfig("GLD",    2950,  0.004, "commodity", -0.2,  "traderspost",   20),
    "SLV":    AssetConfig("SLV",    33,    0.008, "commodity", -0.1,  "traderspost",   10),
    "USO":    AssetConfig("USO",    72,    0.012, "commodity",  0.2,  "traderspost",   10),
    # ── Forex (very low vol, uncorrelated) ──
    "EURUSD": AssetConfig("EURUSD", 1.048, 0.003, "forex",    -0.05, "traderspost",   10),
    "GBPJPY": AssetConfig("GBPJPY", 192,   0.005, "forex",     0.1,  "traderspost",   10),
}

# Regime anchor for trend/volatility analysis
REGIME_ANCHOR = "BTC"

# Grouped by market
ASSETS_BY_MARKET: dict[str, list[str]] = {}
for _sym, _cfg in ASSETS.items():
    ASSETS_BY_MARKET.setdefault(_cfg.market, []).append(_sym)

MARKETS = list(ASSETS_BY_MARKET.keys())

# ═══════════════════════════════════════════════════════════════
#  STEROID C: Market-Calibrated Signal Thresholds
# ═══════════════════════════════════════════════════════════════
# Crypto needs a 2% move to signal; SPY needs 0.5%.
# Each market gets its own breakout threshold, vol spike threshold,
# and random signal probability calibrated to its normal volatility.

@dataclass
class MarketThresholds:
    breakout_pct: float      # Min % move to count as breakout
    vol_spike_mult: float    # Vol must exceed this to signal vol_spike
    random_signal_rate: float  # Base probability of momentum/whale signals
    min_hold_ticks: int = 2  # Minimum time before considering exit

MARKET_THRESHOLDS: dict[str, MarketThresholds] = {
    "crypto":    MarketThresholds(0.020, 0.030, 0.06, 2),
    "stocks":    MarketThresholds(0.008, 0.012, 0.08, 3),
    "etf":       MarketThresholds(0.005, 0.008, 0.08, 3),
    "commodity": MarketThresholds(0.006, 0.010, 0.07, 3),
    "forex":     MarketThresholds(0.003, 0.005, 0.09, 4),
}

# ═══════════════════════════════════════════════════════════════
#  STEROID B: Correlation Map
# ═══════════════════════════════════════════════════════════════
# Prevents duplicate exposure. In production, the cerebellum
# recalculates these from live price data. These are sensible
# defaults for cold start.

CORRELATION_MAP: dict[tuple[str, str], float] = {
    # Crypto intra-correlations (very high)
    ("BTC", "ETH"):  0.92, ("BTC", "SOL"):  0.85, ("BTC", "XRP"):  0.80,
    ("BTC", "AVAX"): 0.82, ("BTC", "LINK"): 0.78, ("ETH", "SOL"):  0.88,
    ("ETH", "AVAX"): 0.84, ("ETH", "LINK"): 0.80, ("SOL", "AVAX"): 0.75,
    # Stock intra-correlations
    ("SPY", "QQQ"):  0.90, ("SPY", "IWM"):  0.85, ("QQQ", "NVDA"): 0.82,
    ("AAPL", "MSFT"):0.75, ("AAPL", "QQQ"): 0.80, ("NVDA", "QQQ"): 0.82,
    # Commodity correlations
    ("GLD", "SLV"):  0.88,
    # Cross-market (low or negative)
    ("SPY", "TLT"): -0.45, ("BTC", "GLD"):  0.15, ("BTC", "SPY"):  0.35,
    ("GLD", "TLT"):  0.30,
}

# Correlation blocking threshold
CORRELATION_BLOCK_THRESHOLD = 0.70

def get_correlation(sym_a: str, sym_b: str) -> float:
    """Get correlation between two assets (order-independent)."""
    return CORRELATION_MAP.get((sym_a, sym_b),
           CORRELATION_MAP.get((sym_b, sym_a), 0.0))


# ═══════════════════════════════════════════════════════════════
#  FIX 3 + ETH Demotion: Asset Overrides
# ═══════════════════════════════════════════════════════════════
# High-volatility assets need higher confidence and smaller positions.
# Computed dynamically from vol thresholds.

@dataclass
class AssetOverride:
    min_confidence: float = 0.60  # Minimum signal confidence to trade
    position_mult: float = 1.0    # Position size multiplier

ASSET_OVERRIDES: dict[str, AssetOverride] = {}
for _sym, _cfg in ASSETS.items():
    if _cfg.vol >= 0.025:       # Very high vol (SOL, AVAX)
        ASSET_OVERRIDES[_sym] = AssetOverride(min_confidence=0.80, position_mult=0.5)
    elif _cfg.vol >= 0.020:     # High vol (XRP, LINK, TSLA)
        ASSET_OVERRIDES[_sym] = AssetOverride(min_confidence=0.70, position_mult=0.75)
# ETH special case: consistently worst performer across all stress test runs
ASSET_OVERRIDES["ETH"] = AssetOverride(min_confidence=0.85, position_mult=0.4)


# ═══════════════════════════════════════════════════════════════
#  Profit Progression: Default Exit Config (Self-Tuning)
# ═══════════════════════════════════════════════════════════════
# These are the starting parameters. The learning system (cerebellum)
# adjusts them per-asset based on observed trade behavior.
#
# behavior: "neutral" → "trending" (hold longer) or "reverting" (exit faster)
# The learning system sets this after observing enough trades.

@dataclass
class ExitConfig:
    trail_mult: float = 1.5       # Trail distance = trail_mult × ATR
    breakeven_at: float = 1.0     # Move SL to entry after profit > breakeven_at × ATR
    partial_at: float = 1.5       # Take partial at partial_at × ATR profit
    partial_pct: float = 0.50     # Fraction to close at partial exit
    extend_tp: bool = True        # Allow TP extension if momentum continues
    behavior: str = "neutral"     # Learning sets: "trending" | "reverting" | "neutral"

def get_default_exit_configs() -> dict[str, ExitConfig]:
    """Get fresh default exit configs for all assets. Called per scenario/session."""
    return {sym: ExitConfig() for sym in ASSETS}


# ═══════════════════════════════════════════════════════════════
#  Regime Definitions
# ═══════════════════════════════════════════════════════════════

@dataclass
class RegimeConfig:
    sl_mult: float         # Stop loss multiplier
    max_pos_pct: float     # Max position as % of capital
    max_concurrent: int    # Max concurrent positions
    scan_interval: int     # Seconds between scans

REGIMES: dict[str, RegimeConfig] = {
    "RISK_ON_TRENDING":  RegimeConfig(sl_mult=1.2, max_pos_pct=0.12, max_concurrent=8, scan_interval=30),
    "RANGING":           RegimeConfig(sl_mult=0.8, max_pos_pct=0.08, max_concurrent=6, scan_interval=60),
    "RISK_OFF_VOLATILE": RegimeConfig(sl_mult=0.5, max_pos_pct=0.05, max_concurrent=4, scan_interval=15),
    "BREAKOUT":          RegimeConfig(sl_mult=1.0, max_pos_pct=0.10, max_concurrent=8, scan_interval=30),
    "ACCUMULATION":      RegimeConfig(sl_mult=0.7, max_pos_pct=0.06, max_concurrent=5, scan_interval=60),
}
