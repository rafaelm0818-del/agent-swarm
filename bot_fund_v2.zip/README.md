# Agent Swarm 🤖

Multi-agent AI system controlled via Telegram. Send tasks in natural language and the orchestrator routes them to specialized agents.

## Architecture

```
Telegram Message
      │
      ▼
┌─────────────┐
│ Orchestrator │ ← Claude API classifies & routes the task
└──────┬──────┘
       │
       ├──────────────┬──────────────┐
       ▼              ▼              ▼
┌────────────┐ ┌────────────┐ ┌────────────┐
│  Trading   │ │    Code    │ │  Scraper   │
│   Agent    │ │   Agent    │ │   Agent    │
├────────────┤ ├────────────┤ ├────────────┤
│ fetch_price│ │ write_file │ │ fetch_url  │
│ run_python │ │ read_file  │ │ run_python │
│ web_search │ │ run_code   │ │ web_search │
│            │ │ run_shell  │ │ save_data  │
│            │ │ list_files │ │            │
└────────────┘ └────────────┘ └────────────┘
```

**Key design decisions:**
- Each agent gets its own Claude API conversation with tool use
- Orchestrator uses Claude to route (with keyword fallback)
- Agents can be chained: scraper → trading for research tasks
- All code execution is sandboxed in subprocesses with timeouts
- Telegram user allowlist for security

## Quick Start

```bash
# 1. Clone and setup
git clone <your-repo>
cd agent-swarm
pip install -r requirements.txt

# 2. Configure
cp .env.example .env
# Edit .env with your API keys

# 3. Run
python bot.py
```

## Getting Your Telegram Bot Token

1. Message [@BotFather](https://t.me/BotFather) on Telegram
2. Send `/newbot` and follow prompts
3. Copy the token into your `.env`

## Getting Your Telegram User ID

1. Message [@userinfobot](https://t.me/userinfobot) on Telegram
2. It replies with your user ID
3. Add it to `ALLOWED_TELEGRAM_USERS` in `.env`

## Usage

**Auto-routed (just type naturally):**
```
"What's the price of SOL?"
→ Trading Agent fetches price

"Scrape the top stories from Hacker News"
→ Scraper Agent fetches and parses HN

"Write a Python script that sends me BTC price alerts via Telegram"
→ Code Agent writes the script

"Research the top DeFi protocols by TVL and write a comparison script"
→ Scraper gathers data → Code Agent writes script
```

**Direct routing:**
```
/direct trading Analyze BTC/ETH ratio over the last 30 days
/direct code Write a FastAPI endpoint that returns portfolio value
/direct scraper Get the latest SEC 13F filings for Bridgewater
```

**Other commands:**
```
/agents  - List agents and their tools
/status  - Check active tasks
/history - Recent task log
/clear   - Reset all agent memory
```

## Adding New Agents

1. Create a new file in `agents/` extending `BaseAgent`
2. Define `name`, `description`, `system_prompt`, `get_tools()`, and `handle_tool_call()`
3. Register it in `agents/orchestrator.py` in the `self.agents` dict

Example minimal agent:

```python
class MyAgent(BaseAgent):
    @property
    def name(self) -> str:
        return "myagent"

    @property
    def description(self) -> str:
        return "Does custom stuff"

    @property
    def system_prompt(self) -> str:
        return "You are a helpful agent that..."

    def get_tools(self) -> list[dict]:
        return [...]

    def handle_tool_call(self, tool_name: str, tool_input: dict):
        ...
```

## Deploy on VPS (Hetzner/DigitalOcean)

```bash
# On your VPS
sudo apt update && sudo apt install python3-pip python3-venv -y
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Run with systemd for auto-restart
sudo tee /etc/systemd/system/agent-swarm.service << EOF
[Unit]
Description=Agent Swarm Bot
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$(pwd)
EnvironmentFile=$(pwd)/.env
ExecStart=$(pwd)/venv/bin/python bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable agent-swarm
sudo systemctl start agent-swarm
```

## Extending: Production Upgrades

- **Persistent memory**: Add PostgreSQL/SQLite for task history and agent context
- **Task queue**: Use Redis + Celery for async long-running tasks
- **File sharing**: Have code agent push files to S3/R2 and share download links via Telegram
- **Notifications**: Trading agent sends alerts when conditions are met
- **MCP integration**: Add Claude MCP servers for richer tool access
- **Web dashboard**: FastAPI admin panel to monitor agents and review history
