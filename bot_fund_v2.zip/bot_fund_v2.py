"""
Agent Swarm v2 - Telegram Bot with Priority Engine + Screener

New commands:
  /scan         - Trigger a manual fast scan now
  /deep_scan    - Trigger a manual deep scan now
  /signals      - View active screener signals
  /signal_log   - View signal history (last 24h)
  /regime       - Get current market regime
  /watchlist    - View/edit screener watchlist
  /priorities   - View priority engine status
  /metrics      - View performance metrics
  /force <task> - Force a specific task to run immediately
"""
import asyncio
import json
import os
import logging
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler, ContextTypes, filters,
)
from agents.orchestrator import Orchestrator
from hedge_fund.bootstrap import FundBootstrap
from hedge_fund.fund_manager_v2 import FundManagerV2
from hedge_fund.fund_manager import FundConfig, StrategyStatus
from config.settings import settings

logging.basicConfig(
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    level=logging.INFO
)
logger = logging.getLogger("AgentSwarmV2")

orchestrator = Orchestrator()
fund_config = FundConfig()
bootstrap: FundBootstrap = None
fund_manager: FundManagerV2 = None
fund_task: asyncio.Task = None
active_tasks: dict[int, int] = {}
_bot_app = None


async def telegram_notify(message: str):
    if _bot_app and settings.ALLOWED_USERS:
        for user_id in settings.ALLOWED_USERS:
            try:
                await _bot_app.bot.send_message(
                    chat_id=user_id, text=message, parse_mode="Markdown"
                )
            except Exception as e:
                logger.error(f"Notify failed: {e}")


def authorized(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if settings.ALLOWED_USERS and user_id not in settings.ALLOWED_USERS:
            await update.message.reply_text("⛔ Unauthorized.")
            return
        return await func(update, context)
    return wrapper


# ── Core Commands ───────────────────────────────────────────────

@authorized
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("""🤖 *Autonomous Hedge Fund — Full System*

*Fund:* /fund\\_start /fund\\_stop /fund\\_status
*Screener:* /scan /deep\\_scan /signals /signal\\_log
*Watchlist:* /watchlist (+add, -remove, ^priority, stats)
*Execution:* /positions /close /trades /balance
*Capital:* /allocate /allocate run
*Learning:* /lessons /learning (signals/mistakes/timing/assets)
*Regime:* /regime /regime set RISK\\_ON\\_TRENDING /regime auto
*Budget:* /costs /budget
*Data:* /data /data price BTC ETH /data overview
*Security:* /security
*Analytics:* /performance /audit /db /metrics
*Control:* /strategies /set\\_mode /priorities /force
*Emergency:* /resume /kill

Or just type naturally.""", parse_mode="Markdown")


@authorized
async def cmd_agents(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lines = ["📋 *Agents*\n"]
    agents = orchestrator.agents.copy()
    if fund_manager:
        agents["screener"] = fund_manager.screener
    for key, agent in agents.items():
        lines.append(f"*{key}* - {agent.description}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


@authorized
async def cmd_direct(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.replace("/direct", "", 1).strip()
    parts = text.split(" ", 1)
    if len(parts) < 2:
        await update.message.reply_text("Usage: /direct `<agent> <task>`", parse_mode="Markdown")
        return
    agent_key, task = parts[0].lower(), parts[1]
    all_agents = orchestrator.agents.copy()
    if fund_manager:
        all_agents["screener"] = fund_manager.screener
    if agent_key not in all_agents:
        await update.message.reply_text(f"Unknown. Available: {', '.join(all_agents.keys())}")
        return
    await update.message.reply_text(f"⏳ *{agent_key.upper()}*...", parse_mode="Markdown")
    result = await all_agents[agent_key].run(task)
    all_agents[agent_key].reset()
    icon = "✅" if result.success else "❌"
    await _send_long(update, f"{icon} *{agent_key.upper()}* ({result.elapsed_seconds:.1f}s)\n\n{result.response}")


# ── Fund Commands ───────────────────────────────────────────────

@authorized
async def cmd_fund_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global bootstrap, fund_manager, fund_task
    if fund_task and not fund_task.done():
        await update.message.reply_text("⚠️ Fund running. /fund_stop first.")
        return

    bootstrap = FundBootstrap(
        config=fund_config,
        orchestrator=orchestrator,
        telegram_notify=telegram_notify,
        db_path=os.getenv("DB_PATH", "./data/fund.db"),
        daily_budget=float(os.getenv("DAILY_API_BUDGET", "25.0")),
    )
    fund_manager = bootstrap.fund_manager
    fund_task = asyncio.create_task(fund_manager.run())
    await update.message.reply_text(
        "🚀 *Fund V2 started*\n"
        f"💾 Database: persistent\n"
        f"⚙️ Execution: {bootstrap.connector.name}\n"
        f"🫁 Budget: ${bootstrap.cost_tracker.daily_budget}/day\n"
        f"💰 Capital: ${fund_config.total_capital:,.0f}\n"
        f"📊 Mode: {fund_config.execution_mode}",
        parse_mode="Markdown"
    )


@authorized
async def cmd_fund_stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global fund_task, bootstrap
    if fund_manager:
        # Save state before stopping
        if bootstrap:
            await bootstrap._task_save_state()
        await fund_manager.stop()
        if fund_task:
            fund_task.cancel()
            fund_task = None
        await update.message.reply_text("🛑 Fund stopped. State saved to database.")
    else:
        await update.message.reply_text("Not running.")


@authorized
async def cmd_fund_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not fund_manager:
        await update.message.reply_text("Fund not running. /fund_start")
        return
    if bootstrap:
        await _send_long(update, bootstrap.get_full_status())
    else:
        await _send_long(update, fund_manager.get_status())


@authorized
async def cmd_fund_config(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"""⚙️ *Fund Config*

💰 ${fund_config.total_capital:,.0f} capital
📊 {fund_config.max_single_strategy_allocation:.0%} max/strategy
🛡️ DD limits: {fund_config.max_daily_drawdown:.0%}d / {fund_config.max_weekly_drawdown:.0%}w / {fund_config.max_total_drawdown:.0%} total
📈 Min Sharpe: {fund_config.min_sharpe_for_deploy} | Min PF: {fund_config.min_profit_factor}
⏱️ Research: {fund_config.research_interval_hours}h | Monitor: 30s | Deep: 5m
📋 Paper days: {fund_config.paper_trade_days_required}
🔧 Mode: {fund_config.execution_mode} | Broker: {fund_config.broker}""", parse_mode="Markdown")


# ── Screener Commands ───────────────────────────────────────────

@authorized
async def cmd_scan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Trigger manual fast scan."""
    if not fund_manager:
        await update.message.reply_text("Fund not running. /fund_start first.")
        return
    await update.message.reply_text("⚡ Running fast scan...")
    fund_manager.priority_engine.force_run("fast_scan")
    await asyncio.sleep(3)
    # Show recent signals
    summary = fund_manager.screener.get_signal_summary(hours=1)
    await update.message.reply_text(summary or "No signals detected.", parse_mode="Markdown")


@authorized
async def cmd_deep_scan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Trigger manual deep scan."""
    if not fund_manager:
        await update.message.reply_text("Fund not running.")
        return
    await update.message.reply_text("🔍 Running deep scan (may take 1-2 min)...")
    fund_manager.priority_engine.force_run("deep_scan")


@authorized
async def cmd_signals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View active signals."""
    if not fund_manager:
        await update.message.reply_text("Fund not running.")
        return
    
    import time, json
    now = time.time()
    active = [
        s for s in fund_manager.screener.signal_history
        if (s.expires_at == 0 or s.expires_at > now)
    ]

    if not active:
        await update.message.reply_text("📡 No active signals right now.")
        return

    for signal in active[-10:]:
        await update.message.reply_text(signal.to_telegram(), parse_mode="Markdown")
        await asyncio.sleep(0.3)


@authorized
async def cmd_signal_log(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View signal history."""
    if not fund_manager:
        await update.message.reply_text("Fund not running.")
        return
    summary = fund_manager.screener.get_signal_summary(hours=24)
    await update.message.reply_text(summary, parse_mode="Markdown")


@authorized
async def cmd_watchlist(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View or edit watchlist."""
    if not fund_manager:
        await update.message.reply_text("Fund not running.")
        return

    text = update.message.text.replace("/watchlist", "", 1).strip()

    if text.startswith("+"):
        # Parse: +PEPE crypto or +AAPL stocks
        parts = text[1:].strip().split()
        symbol = parts[0].upper() if parts else ""
        market = parts[1].lower() if len(parts) > 1 else "crypto"
        
        if not symbol:
            await update.message.reply_text("Usage: `/watchlist +PEPE crypto`", parse_mode="Markdown")
            return
        
        result = fund_manager.watchlist_manager._process_recommendation({
            "action": "add",
            "symbol": symbol,
            "market": market,
            "from_agent": "human",
            "reason": "Manually added via Telegram",
            "priority_suggestion": 0.7,
        })
        data = json.loads(result)
        if data.get("success"):
            await update.message.reply_text(f"✅ Added *{symbol}* to {market} watchlist", parse_mode="Markdown")
        else:
            await update.message.reply_text(f"❌ {data.get('error', 'Failed')}")

    elif text.startswith("-"):
        parts = text[1:].strip().split()
        symbol = parts[0].upper() if parts else ""
        market = parts[1].lower() if len(parts) > 1 else "crypto"
        
        if not symbol:
            await update.message.reply_text("Usage: `/watchlist -DOGE crypto`", parse_mode="Markdown")
            return
        
        result = fund_manager.watchlist_manager._remove_asset({
            "symbol": symbol,
            "market": market,
            "reason": "Manually removed via Telegram",
        })
        data = json.loads(result)
        if data.get("success"):
            await update.message.reply_text(f"🗑️ Removed *{symbol}* from {market} watchlist", parse_mode="Markdown")
        else:
            await update.message.reply_text(f"❌ {data.get('error', 'Failed')}")

    elif text.startswith("^"):
        # Boost priority: ^BTC crypto 0.9
        parts = text[1:].strip().split()
        symbol = parts[0].upper() if parts else ""
        market = parts[1].lower() if len(parts) > 1 else "crypto"
        priority = float(parts[2]) if len(parts) > 2 else 0.8
        
        result = fund_manager.watchlist_manager._edit_asset({
            "symbol": symbol,
            "market": market,
            "priority_score": priority,
            "reason": f"Manual priority set to {priority}",
        })
        data = json.loads(result)
        if data.get("success"):
            await update.message.reply_text(
                f"⬆️ *{symbol}* priority → {priority:.0%}", parse_mode="Markdown"
            )
        else:
            await update.message.reply_text(f"❌ {data.get('error', 'Failed')}")

    elif text.lower().startswith("pause "):
        symbol = text.split()[1].upper()
        market = text.split()[2].lower() if len(text.split()) > 2 else "crypto"
        result = fund_manager.watchlist_manager._edit_asset({
            "symbol": symbol, "market": market, "paused": True,
            "reason": "Manually paused",
        })
        await update.message.reply_text(f"⏸️ Paused scanning for *{symbol}*", parse_mode="Markdown")

    elif text.lower().startswith("unpause "):
        symbol = text.split()[1].upper()
        market = text.split()[2].lower() if len(text.split()) > 2 else "crypto"
        result = fund_manager.watchlist_manager._edit_asset({
            "symbol": symbol, "market": market, "paused": False,
            "reason": "Manually unpaused",
        })
        await update.message.reply_text(f"▶️ Resumed scanning for *{symbol}*", parse_mode="Markdown")

    elif text.lower() == "stats":
        stats = json.loads(fund_manager.watchlist_manager._get_stats())
        lines = [f"📊 *Watchlist Stats*\n",
                 f"Total: {stats['total_active']}/{stats['total_capacity']}\n"]
        for market, info in stats.get("by_market", {}).items():
            lines.append(f"*{market}*: {info['count']}/{info['capacity']} | avg priority: {info['avg_priority']} | signals: {info['total_signals']}")
        lines.append("\n*Top Priority:*")
        for a in stats.get("top_priority", [])[:5]:
            lines.append(f"  {a['symbol']} ({a['market']}) - {a['priority_score']:.0%}")
        await _send_long(update, "\n".join(lines))

    elif text.lower() == "cleanup":
        result = json.loads(fund_manager.watchlist_manager._run_cleanup({"dry_run": True}))
        if result.get("actions"):
            lines = ["🧹 *Cleanup Preview (dry run)*\n"]
            for action in result["actions"]:
                lines.append(f"  {action['action']}: {action['symbol']} ({action['market']}) - {action['reason'][:60]}")
            lines.append(f"\n{result['total_changes']} changes. Run `/watchlist cleanup!` to apply.")
            await _send_long(update, "\n".join(lines))
        else:
            await update.message.reply_text("✨ Watchlist is clean, no changes needed.")

    elif text.lower() == "cleanup!":
        result = json.loads(fund_manager.watchlist_manager._run_cleanup({"dry_run": False}))
        await update.message.reply_text(f"🧹 Cleanup done. {result['total_changes']} changes applied.")

    else:
        # Default: show full watchlist
        summary = fund_manager.watchlist_manager.get_telegram_summary()
        help_text = (
            "\n*Commands:*\n"
            "`/watchlist +PEPE crypto` — add\n"
            "`/watchlist -DOGE crypto` — remove\n"
            "`/watchlist ^BTC crypto 0.9` — set priority\n"
            "`/watchlist +AAPL stocks` — add stock\n"
            "`/watchlist +EUR/USD forex` — add forex\n"
            "`/watchlist +GLD commodities` — add commodity\n"
            "`/watchlist pause SOL` — pause scanning\n"
            "`/watchlist unpause SOL` — resume\n"
            "`/watchlist stats` — statistics\n"
            "`/watchlist cleanup` — preview cleanup"
        )
        await _send_long(update, summary + help_text)


# ── Control Commands ────────────────────────────────────────────

@authorized
async def cmd_strategies(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not fund_manager or not fund_manager.strategies:
        await update.message.reply_text("No strategies.")
        return
    for sid, s in fund_manager.strategies.items():
        lines = [f"*{s.name}* `{sid}`", f"Status: {s.status.value}"]
        if s.sharpe_ratio:
            lines.append(f"Sharpe: {s.sharpe_ratio:.2f} | WR: {s.win_rate:.0%} | PF: {s.profit_factor:.2f}")
        if s.status in (StrategyStatus.LIVE, StrategyStatus.DEPLOYED):
            lines.append(f"P&L: ${s.live_pnl:,.2f} | Trades: {s.live_trades}")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


@authorized
async def cmd_set_mode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.replace("/set_mode", "", 1).strip().lower()
    if text not in ("paper", "live"):
        await update.message.reply_text("Usage: /set_mode paper|live")
        return
    fund_config.execution_mode = text
    if fund_manager:
        fund_manager.config.execution_mode = text
    await update.message.reply_text(
        f"{'📋' if text == 'paper' else '💰'} Mode: *{text.upper()}*"
        + ("\n⚠️ LIVE TRADING ENABLED" if text == "live" else ""),
        parse_mode="Markdown"
    )


@authorized
async def cmd_priorities(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View priority engine status."""
    if not fund_manager:
        await update.message.reply_text("Fund not running.")
        return
    status = fund_manager.priority_engine.get_status()
    lines = ["⚡ *Priority Engine*\n"]
    for tier_name, info in status["tiers"].items():
        lines.append(f"*{tier_name}*: {info['running']}/{info['task_count']} active, {info['capacity']} slots free")
    lines.append("\n*Tasks:*")
    for name, info in status["tasks"].items():
        icon = "🟢" if info["enabled"] else "⏸️"
        running = "⚡" if info["running"] else ""
        lines.append(
            f"{icon}{running} `{name}` [{info['priority']}] "
            f"every {info['interval']}s | runs: {info['runs']} | avg: {info['avg_runtime']}"
        )
    await _send_long(update, "\n".join(lines))


@authorized
async def cmd_metrics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View performance metrics."""
    if not fund_manager:
        await update.message.reply_text("Fund not running.")
        return
    m = fund_manager._cycle_metrics
    await update.message.reply_text(f"""📊 *Performance Metrics*

⚡ Fast scans: {m['fast_scans']}
🔍 Deep scans: {m['deep_scans']}
📡 Signals generated: {m['signals_generated']}
✅ Signals acted on: {m['signals_acted_on']}
🔬 Strategies created: {m['strategies_created']}
🚀 Strategies deployed: {m['strategies_deployed']}
🚨 Circuit breakers: {m['circuit_breakers_hit']}""", parse_mode="Markdown")


@authorized
async def cmd_force(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Force a task to run immediately."""
    if not fund_manager:
        await update.message.reply_text("Fund not running.")
        return
    task_name = update.message.text.replace("/force", "", 1).strip()
    available = list(fund_manager.priority_engine.tasks.keys())
    if task_name not in available:
        await update.message.reply_text(f"Available tasks: {', '.join(available)}")
        return
    fund_manager.priority_engine.force_run(task_name)
    await update.message.reply_text(f"⚡ Force-running `{task_name}`", parse_mode="Markdown")


@authorized
async def cmd_resume(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if fund_manager:
        fund_manager.resume()
        await update.message.reply_text("▶️ Resumed. All tasks re-enabled.")
    else:
        await update.message.reply_text("Not running.")


@authorized
async def cmd_kill(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global fund_task, bootstrap
    if fund_manager:
        # Emergency save
        if bootstrap:
            try:
                await bootstrap._task_save_state()
            except Exception:
                pass
        fund_manager.is_running = False
        fund_manager.priority_engine.stop()
        for s in fund_manager.strategies.values():
            if s.status in (StrategyStatus.LIVE, StrategyStatus.DEPLOYED):
                s.status = StrategyStatus.PAUSED
        if fund_task:
            fund_task.cancel()
            fund_task = None
    await update.message.reply_text("🚨 *EMERGENCY STOP* - Everything killed. State saved.", parse_mode="Markdown")


# ── Execution Commands ──────────────────────────────────────────

@authorized
async def cmd_positions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View all open positions with live P&L."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    positions = bootstrap.execution.get_all_positions()
    if not positions:
        await update.message.reply_text("📭 No open positions.")
        return
    
    total_pnl = 0
    lines = ["📊 *Open Positions*\n"]
    for p in positions:
        pnl = p["unrealized_pnl"]
        total_pnl += pnl
        icon = "🟢" if pnl >= 0 else "🔴"
        lines.append(
            f"{icon} *{p['symbol']}* {p['side'].upper()}\n"
            f"  Qty: {p['quantity']} | Entry: ${p['entry_price']:,.4f}\n"
            f"  Now: ${p['current_price']:,.4f} | P&L: ${pnl:+,.2f}\n"
            f"  SL: ${p['stop_loss']:,.2f} | TP: ${p['take_profit']:,.2f}"
        )
    lines.append(f"\n*Total unrealized: ${total_pnl:+,.2f}*")
    await _send_long(update, "\n".join(lines))


@authorized
async def cmd_close(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Close a position. Usage: /close <position_id> or /close all"""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    text = update.message.text.replace("/close", "", 1).strip()
    
    if text.lower() == "all":
        positions = list(bootstrap.execution.positions.keys())
        if not positions:
            await update.message.reply_text("No positions to close.")
            return
        await update.message.reply_text(f"⏳ Closing {len(positions)} positions...")
        for pos_id in positions:
            await bootstrap.execution.close_position(pos_id, reason="manual_close_all")
        await update.message.reply_text(f"✅ Closed {len(positions)} positions.")
        return
    
    if not text:
        positions = bootstrap.execution.get_all_positions()
        if not positions:
            await update.message.reply_text("No open positions.")
            return
        lines = ["Usage: `/close <id>` or `/close all`\n\nPositions:"]
        for p in positions:
            lines.append(f"`{p['id']}` — {p['symbol']} {p['side']} ${p['unrealized_pnl']:+,.2f}")
        await _send_long(update, "\n".join(lines))
        return
    
    result = await bootstrap.execution.close_position(text, reason="manual")
    if result:
        await update.message.reply_text(
            f"✅ Closed {result['symbol']} | P&L: ${result['pnl']:+,.2f} ({result['pnl_pct']:+.2f}%)",
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text("❌ Position not found or close failed.")


@authorized
async def cmd_trades(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View recent trade history."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    trades = bootstrap.db.get_trades(limit=15)
    if not trades:
        await update.message.reply_text("📭 No trades yet.")
        return
    
    lines = ["📜 *Recent Trades*\n"]
    for t in trades:
        icon = "🟢" if (t.get("pnl") or 0) >= 0 else "🔴"
        pnl_str = f"${t['pnl']:+,.2f}" if t.get("pnl") is not None else "open"
        exit_str = f"${t['exit_price']:,.2f}" if t.get("exit_price") else "open"
        lines.append(
            f"{icon} {t['side'].upper()} {t['symbol']} | "
            f"${t['entry_price']:,.2f} → {exit_str} | "
            f"P&L: {pnl_str} | {t['status']}"
        )
    
    stats = bootstrap.db.get_trade_stats()
    if stats and stats.get("total_trades", 0) > 0:
        lines.extend([
            f"\n*All-Time Stats:*",
            f"Trades: {stats['total_trades']} | "
            f"Win: {stats.get('winners', 0)} | Loss: {stats.get('losers', 0)}",
            f"Total P&L: ${stats.get('total_pnl', 0):+,.2f} | "
            f"Fees: ${stats.get('total_fees', 0):,.2f}",
        ])
    await _send_long(update, "\n".join(lines))


@authorized
async def cmd_costs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View API cost tracking."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    await _send_long(update, bootstrap.cost_tracker.get_telegram_summary())


@authorized
async def cmd_audit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View audit log of agent decisions."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    text = update.message.text.replace("/audit", "", 1).strip()
    agent_filter = text if text else None
    
    logs = bootstrap.db.get_audit_log(agent=agent_filter, limit=20)
    if not logs:
        await update.message.reply_text("📭 No audit entries." + (" Try: /audit" if agent_filter else ""))
        return
    
    lines = [f"📋 *Audit Log*{f' ({agent_filter})' if agent_filter else ''}\n"]
    for log in logs:
        ts = log.get("created_at", "")[:16]
        lines.append(
            f"`{ts}` *{log['agent']}* → {log['action']}\n"
            f"  {log['details'][:100]}"
        )
    await _send_long(update, "\n".join(lines))


@authorized
async def cmd_performance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View performance history."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    history = bootstrap.db.get_performance_history(hours=168)
    if not history:
        await update.message.reply_text("📭 No performance data yet. Snapshots are taken hourly.")
        return
    
    lines = ["📈 *Performance History (7d)*\n"]
    for snap in history[-24:]:  # Last 24 snapshots
        ts = snap.get("snapshot_at", "")[:16]
        pnl = snap.get("total_pnl", 0)
        icon = "🟢" if pnl >= 0 else "🔴"
        lines.append(
            f"`{ts}` {icon} P&L: ${pnl:+,.2f} | "
            f"Deployed: ${snap.get('deployed', 0):,.0f} | "
            f"Positions: {snap.get('open_positions', 0)} | "
            f"Strategies: {snap.get('active_strategies', 0)}"
        )
    await _send_long(update, "\n".join(lines))


@authorized
async def cmd_db(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View database stats."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    stats = bootstrap.db.get_db_stats()
    lines = [
        f"💾 *Database*\n",
        f"Size: {stats['db_size_mb']} MB",
        f"Path: `{stats['path']}`\n",
        "*Row Counts:*",
    ]
    for table, count in stats["tables"].items():
        lines.append(f"  {table}: {count:,}")
    await _send_long(update, "\n".join(lines))


@authorized
async def cmd_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View exchange balance."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    balance = bootstrap.connector.get_balance()
    lines = [f"💰 *Balance* ({bootstrap.connector.name})\n"]
    for currency, amount in balance.items():
        if isinstance(amount, (int, float)):
            lines.append(f"  {currency}: ${amount:,.4f}" if currency == "USD" else f"  {currency}: {amount:,.6f}")
        else:
            lines.append(f"  {currency}: {amount}")
    await _send_long(update, "\n".join(lines))


@authorized
async def cmd_budget(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View/set daily API budget."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    text = update.message.text.replace("/budget", "", 1).strip()
    if text:
        try:
            new_budget = float(text)
            bootstrap.cost_tracker.daily_budget = new_budget
            await update.message.reply_text(f"✅ Daily API budget set to ${new_budget:.2f}")
        except ValueError:
            await update.message.reply_text("Usage: `/budget 50.00`", parse_mode="Markdown")
        return
    
    summary = bootstrap.cost_tracker.get_summary(hours=24)
    within, remaining = summary["within_budget"], summary["remaining_budget"]
    icon = "🟢" if within else "🔴"
    await update.message.reply_text(
        f"🫁 *API Budget*\n\n"
        f"{icon} Today: ${summary['total_cost_usd']:.2f} / ${summary['daily_budget']:.2f}\n"
        f"Remaining: ${remaining:.2f}\n\n"
        f"Set: `/budget 50.00`",
        parse_mode="Markdown"
    )


# ── Learning System Commands ────────────────────────────────────

@authorized
async def cmd_lessons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View learning system insights."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    text = update.message.text.replace("/lessons", "", 1).strip()
    
    if text == "refresh":
        bootstrap.learning.get_lessons(force_refresh=True)
        await update.message.reply_text("📚 Lessons refreshed from database.")
        return
    
    await _send_long(update, bootstrap.learning.get_telegram_summary())


@authorized
async def cmd_learning(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View detailed learning system data."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    text = update.message.text.replace("/learning", "", 1).strip()
    lessons = bootstrap.learning.get_lessons(force_refresh=True)
    
    if text == "signals":
        sq = lessons.get("signal_quality", {})
        lines = ["📡 *Signal Quality Analysis*\n"]
        for sig_type, data in sq.get("by_type", {}).items():
            lines.append(
                f"*{sig_type}*: {data.get('total', 0)} total | "
                f"Traded: {data.get('traded', 0)} | "
                f"WR: {data.get('win_rate', 'N/A')} | "
                f"P&L: ${data.get('total_pnl', 0):+,.2f}"
            )
        await _send_long(update, "\n".join(lines) if len(lines) > 1 else "No signal data yet.")
    
    elif text == "mistakes":
        mp = lessons.get("mistake_patterns", {})
        if mp.get("patterns"):
            lines = ["⚠️ *Mistake Patterns*\n"]
            for m in mp["patterns"]:
                lines.append(f"[{m['severity'].upper()}] {m['detail']}")
            await _send_long(update, "\n".join(lines))
        else:
            await update.message.reply_text("✨ No mistake patterns detected.")
    
    elif text == "timing":
        tl = lessons.get("timing_lessons", {})
        await update.message.reply_text(
            f"⏰ *Timing Analysis*\n\n{tl.get('lesson', 'Not enough data yet.')}",
            parse_mode="Markdown"
        )
    
    elif text == "assets":
        al = lessons.get("asset_lessons", {})
        lines = ["📊 *Asset Performance*\n"]
        for asset, data in al.get("by_asset", {}).items():
            icon = "🟢" if data.get("total_pnl", 0) >= 0 else "🔴"
            lines.append(
                f"{icon} *{asset}*: {data['trades']} trades | "
                f"WR: {data.get('win_rate', 0):.0%} | "
                f"P&L: ${data['total_pnl']:+,.2f}"
            )
        await _send_long(update, "\n".join(lines) if len(lines) > 1 else "No asset data yet.")
    
    else:
        await update.message.reply_text(
            "📚 *Learning System*\n\n"
            "`/lessons` — summary\n"
            "`/lessons refresh` — force refresh\n"
            "`/learning signals` — signal quality\n"
            "`/learning mistakes` — mistake patterns\n"
            "`/learning timing` — time analysis\n"
            "`/learning assets` — per-asset perf",
            parse_mode="Markdown"
        )


# ── Adaptive Config Commands ────────────────────────────────────

@authorized
async def cmd_regime(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View or override adaptive regime config."""
    if not bootstrap:
        if not fund_manager:
            await update.message.reply_text("Fund not running.")
            return
        # Fallback: trigger screener regime detection
        await update.message.reply_text("⏳ Running regime detection...")
        result = await fund_manager.screener.run(fund_manager.screener.regime_detection_prompt())
        fund_manager.screener.reset()
        await _send_long(update, f"🌍 *Regime Detection*\n\n{result.response[:2000]}")
        return
    
    text = update.message.text.replace("/regime", "", 1).strip()
    
    if text.startswith("set "):
        regime_name = text[4:].strip().upper()
        if bootstrap.adaptive_config.set_manual_override(regime_name):
            bootstrap.adaptive_config.apply_to_priority_engine(fund_manager.priority_engine)
            bootstrap.adaptive_config.apply_to_cost_tracker(bootstrap.cost_tracker)
            await update.message.reply_text(f"💉 Regime manually set to *{regime_name}*", parse_mode="Markdown")
        else:
            valid = ", ".join(["RISK_ON_TRENDING", "RISK_ON_VOLATILE", "RISK_OFF_TRENDING", "RISK_OFF_VOLATILE", "RANGING", "TRANSITIONING"])
            await update.message.reply_text(f"❌ Unknown regime. Valid: {valid}")
    
    elif text == "auto":
        bootstrap.adaptive_config.clear_override()
        await update.message.reply_text("💉 Regime set to auto-detect mode.")
    
    else:
        await _send_long(update, bootstrap.adaptive_config.get_telegram_summary())


# ── Capital Allocator Commands ──────────────────────────────────

@authorized
async def cmd_allocate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View capital allocation."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    text = update.message.text.replace("/allocate", "", 1).strip()
    
    if text == "run":
        # Force reallocation
        await bootstrap._task_rebalance_check()
        await _send_long(update, bootstrap.allocator.get_telegram_summary())
    else:
        if bootstrap.allocator.allocations:
            await _send_long(update, bootstrap.allocator.get_telegram_summary())
        else:
            await update.message.reply_text(
                "❤️ No allocations computed yet.\n"
                "Run `/allocate run` to compute, or wait for the next auto-rebalance.",
                parse_mode="Markdown"
            )


# ── Data Pipeline Commands ──────────────────────────────────────

@authorized
async def cmd_data(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View data pipeline stats or fetch prices."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    
    text = update.message.text.replace("/data", "", 1).strip()
    
    if text == "flush":
        bootstrap.data_pipeline.flush_cache()
        await update.message.reply_text("👄 Data pipeline cache flushed.")
    
    elif text.startswith("price "):
        symbols = text[6:].strip().upper().split()
        prices = bootstrap.data_pipeline.get_prices_batch(symbols)
        lines = ["💹 *Prices*\n"]
        for sym, data in prices.items():
            icon = "🟢" if data.change_24h >= 0 else "🔴"
            lines.append(
                f"{icon} *{sym}*: ${data.price:,.2f} ({data.change_24h:+.2f}%)\n"
                f"  Vol: ${data.volume_24h:,.0f} | MCap: ${data.market_cap:,.0f}"
            )
        await _send_long(update, "\n".join(lines))
    
    elif text == "overview":
        overview = bootstrap.data_pipeline.get_market_overview()
        await update.message.reply_text(f"📊 *Market Overview*\n\n{overview}", parse_mode="Markdown")
    
    else:
        await _send_long(update, bootstrap.data_pipeline.get_telegram_summary())


# ── Security Commands ───────────────────────────────────────────

@authorized
async def cmd_security(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """View security status."""
    if not bootstrap:
        await update.message.reply_text("Fund not running.")
        return
    await _send_long(update, bootstrap.security.get_telegram_summary())


# ── General Handler ─────────────────────────────────────────────

@authorized
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    task = update.message.text.strip()
    if not task:
        return
    current = active_tasks.get(user_id, 0)
    if current >= settings.MAX_CONCURRENT_TASKS:
        await update.message.reply_text("⚠️ Too many active tasks.")
        return
    active_tasks[user_id] = current + 1
    await update.message.reply_text("⏳ Processing...")
    try:
        response = await orchestrator.route_and_execute(task)
        await _send_long(update, response)
    except Exception as e:
        await update.message.reply_text(f"❌ {str(e)}")
    finally:
        active_tasks[user_id] = max(0, active_tasks.get(user_id, 1) - 1)


async def _send_long(update: Update, text: str, chunk_size: int = 4000):
    if len(text) <= chunk_size:
        try:
            await update.message.reply_text(text, parse_mode="Markdown")
        except Exception:
            await update.message.reply_text(text)
        return
    chunks = []
    while text:
        if len(text) <= chunk_size:
            chunks.append(text)
            break
        split_at = text.rfind("\n", 0, chunk_size)
        if split_at == -1:
            split_at = chunk_size
        chunks.append(text[:split_at])
        text = text[split_at:].lstrip("\n")
    for chunk in chunks:
        try:
            await update.message.reply_text(chunk, parse_mode="Markdown")
        except Exception:
            await update.message.reply_text(chunk)
        await asyncio.sleep(0.3)


# ── Main ────────────────────────────────────────────────────────

def main():
    global _bot_app
    if not settings.TELEGRAM_BOT_TOKEN or not settings.ANTHROPIC_API_KEY:
        logger.error("Missing TELEGRAM_BOT_TOKEN or ANTHROPIC_API_KEY")
        return

    logger.info("Starting Agent Swarm V2...")
    app = Application.builder().token(settings.TELEGRAM_BOT_TOKEN).build()
    _bot_app = app

    # Core
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("agents", cmd_agents))
    app.add_handler(CommandHandler("direct", cmd_direct))

    # Fund
    app.add_handler(CommandHandler("fund_start", cmd_fund_start))
    app.add_handler(CommandHandler("fund_stop", cmd_fund_stop))
    app.add_handler(CommandHandler("fund_status", cmd_fund_status))
    app.add_handler(CommandHandler("fund_config", cmd_fund_config))

    # Screener
    app.add_handler(CommandHandler("scan", cmd_scan))
    app.add_handler(CommandHandler("deep_scan", cmd_deep_scan))
    app.add_handler(CommandHandler("signals", cmd_signals))
    app.add_handler(CommandHandler("signal_log", cmd_signal_log))
    app.add_handler(CommandHandler("watchlist", cmd_watchlist))

    # Control
    app.add_handler(CommandHandler("strategies", cmd_strategies))
    app.add_handler(CommandHandler("set_mode", cmd_set_mode))
    app.add_handler(CommandHandler("priorities", cmd_priorities))
    app.add_handler(CommandHandler("metrics", cmd_metrics))
    app.add_handler(CommandHandler("force", cmd_force))
    app.add_handler(CommandHandler("resume", cmd_resume))
    app.add_handler(CommandHandler("kill", cmd_kill))

    # Execution
    app.add_handler(CommandHandler("positions", cmd_positions))
    app.add_handler(CommandHandler("close", cmd_close))
    app.add_handler(CommandHandler("trades", cmd_trades))
    app.add_handler(CommandHandler("balance", cmd_balance))

    # Analytics
    app.add_handler(CommandHandler("costs", cmd_costs))
    app.add_handler(CommandHandler("budget", cmd_budget))
    app.add_handler(CommandHandler("performance", cmd_performance))
    app.add_handler(CommandHandler("audit", cmd_audit))
    app.add_handler(CommandHandler("db", cmd_db))

    # Learning
    app.add_handler(CommandHandler("lessons", cmd_lessons))
    app.add_handler(CommandHandler("learning", cmd_learning))

    # Adaptive / Regime
    app.add_handler(CommandHandler("regime", cmd_regime))

    # Capital
    app.add_handler(CommandHandler("allocate", cmd_allocate))

    # Data Pipeline
    app.add_handler(CommandHandler("data", cmd_data))

    # Security
    app.add_handler(CommandHandler("security", cmd_security))

    # Catch-all
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
