"""
Watchlist Integration Layer

Wires the WatchlistManagerAgent into the full system:
1. Screener reads from watchlist instead of its own static list
2. All agents can recommend watchlist changes via event bus
3. Cleanup runs on a schedule
4. Fund manager uses watchlist for research context
"""
import asyncio
import json
import time
import logging
from typing import Optional

from agents.watchlist_manager_agent import WatchlistManagerAgent, WatchlistConfig, Market
from agents.screener_agent import ScreenerAgent
from hedge_fund.priority_engine import PriorityEngine, Priority, EventBus

logger = logging.getLogger("WatchlistIntegration")


class WatchlistIntegration:
    """
    Bridges the WatchlistManager with all other system components.
    
    Event bus subscriptions:
      - screener.signal.published → boost asset priority, extend TTL
      - research.opportunity.found → add recommended assets
      - trading.position.opened → boost priority
      - trading.position.closed → potentially reduce priority
      - risk.strategy.rejected → reduce asset priority  
      - regime.update → adjust watchlist based on new regime
      - monitor.strategy.underperforming → flag asset for review
    """

    def __init__(
        self,
        watchlist_manager: WatchlistManagerAgent,
        screener: ScreenerAgent,
        priority_engine: PriorityEngine,
    ):
        self.wm = watchlist_manager
        self.screener = screener
        self.engine = priority_engine
        self.bus = priority_engine.event_bus

    def setup(self):
        """Register all event bus subscriptions and priority tasks."""

        # ── Override screener's watchlist source ─────────────────
        # Monkey-patch the screener to read from watchlist manager
        original_watchlist = self.screener.watchlist
        
        @property
        def dynamic_watchlist(self_screener):
            """Pull watchlist from the WatchlistManager instead of static list."""
            return self.wm.get_active_symbols(market="crypto")
        
        # We'll handle this more cleanly - provide a method the fund manager calls
        self._sync_screener_watchlist()

        # ── Register watchlist tasks with priority engine ────────

        # Cleanup task - Tier 3 (runs every 6 hours)
        self.engine.register(
            name="watchlist_cleanup",
            priority=Priority.LOW,
            interval_seconds=6 * 3600,
            callback=self._task_cleanup,
            timeout_seconds=120,
        )

        # Sync screener watchlist - Tier 2 (every 2 minutes)
        self.engine.register(
            name="watchlist_sync",
            priority=Priority.MEDIUM,
            interval_seconds=120,
            callback=self._task_sync,
            timeout_seconds=10,
        )

        # Discovery scan - Tier 3 (every 12 hours)
        self.engine.register(
            name="watchlist_discovery",
            priority=Priority.LOW,
            interval_seconds=12 * 3600,
            callback=self._task_discovery,
            timeout_seconds=300,
        )

        # ── Subscribe to events ─────────────────────────────────

        # When screener generates a signal, boost that asset
        self.bus.subscribe("task.fast_scan.complete", self._on_scan_complete)
        self.bus.subscribe("task.deep_scan.complete", self._on_scan_complete)

        # When regime changes, adjust watchlist
        self.bus.subscribe("regime.update", self._on_regime_update)

        logger.info("Watchlist integration setup complete")

    # ── Scheduled Tasks ─────────────────────────────────────────

    async def _task_cleanup(self):
        """Run watchlist cleanup."""
        result = self.wm._run_cleanup({"dry_run": False})
        data = json.loads(result)
        if data.get("total_changes", 0) > 0:
            logger.info(f"Watchlist cleanup: {data['total_changes']} changes")
        return data

    async def _task_sync(self):
        """Sync screener watchlist from watchlist manager."""
        self._sync_screener_watchlist()
        return {"synced": True, "count": len(self.screener.watchlist)}

    async def _task_discovery(self):
        """Periodically search for new trending assets to add."""
        # Search trending crypto
        result = await self.wm.run(
            "Search for trending cryptocurrencies and evaluate if any should be "
            "added to our watchlist. Check CoinGecko trending, look at volume "
            "movers, and identify any new assets gaining momentum. Only recommend "
            "assets that have sufficient volume and aren't already on our list."
        )
        self.wm.reset()
        return {"discovery": result.response[:500]}

    # ── Event Handlers ──────────────────────────────────────────

    async def _on_scan_complete(self, result):
        """When screener finishes a scan, check for new signals and update watchlist."""
        # Find signals generated in last 60 seconds
        now = time.time()
        recent_signals = [
            s for s in self.screener.signal_history
            if now - s.timestamp < 60
        ]
        for signal in recent_signals:
            # Record signal on the watchlist asset
            self.wm.record_signal(signal.asset, "crypto")
            
            # High-confidence signals boost priority
            if signal.confidence >= 0.7:
                self.wm._process_recommendation({
                    "action": "boost",
                    "symbol": signal.asset,
                    "market": "crypto",
                    "from_agent": "screener",
                    "reason": f"{signal.signal_type} signal (confidence: {signal.confidence:.0%})",
                    "priority_suggestion": min(1.0, signal.confidence),
                    "tags": [signal.signal_type, signal.direction],
                })

    async def _on_regime_update(self, regime_data):
        """Adjust watchlist based on market regime change."""
        if not isinstance(regime_data, dict):
            return

        favored = regime_data.get("assets_to_favor", [])
        avoid = regime_data.get("assets_to_avoid", [])
        regime = regime_data.get("regime", "unknown")

        for symbol in favored:
            self.wm._process_recommendation({
                "action": "boost",
                "symbol": symbol,
                "market": "crypto",
                "from_agent": "regime_detection",
                "reason": f"Favored in {regime} regime",
                "tags": [f"regime_{regime}"],
            })

        for symbol in avoid:
            self.wm._process_recommendation({
                "action": "reduce",
                "symbol": symbol,
                "market": "crypto",
                "from_agent": "regime_detection",
                "reason": f"Unfavored in {regime} regime",
            })

    # ── Helpers ─────────────────────────────────────────────────

    def _sync_screener_watchlist(self):
        """Push current watchlist to screener."""
        # Get all active crypto symbols (screener's primary market)
        crypto_symbols = self.wm.get_active_symbols(market="crypto")
        self.screener.watchlist = crypto_symbols if crypto_symbols else ["BTC", "ETH", "SOL"]

    # ── Public methods for fund manager ─────────────────────────

    def recommend_add(
        self,
        symbol: str,
        market: str,
        from_agent: str,
        reason: str,
        priority: float = 0.6,
        tags: list[str] = None,
    ) -> dict:
        """Convenience method for any agent to recommend adding an asset."""
        result = self.wm._process_recommendation({
            "action": "add",
            "symbol": symbol,
            "market": market,
            "from_agent": from_agent,
            "reason": reason,
            "priority_suggestion": priority,
            "tags": tags or [],
        })
        return json.loads(result)

    def recommend_remove(self, symbol: str, market: str, from_agent: str, reason: str) -> dict:
        result = self.wm._process_recommendation({
            "action": "remove",
            "symbol": symbol,
            "market": market,
            "from_agent": from_agent,
            "reason": reason,
        })
        return json.loads(result)

    def get_research_context(self) -> str:
        """Generate context string for the research agent about current watchlist."""
        stats = json.loads(self.wm._get_stats())
        active = self.wm.get_active_assets()

        by_market = {}
        for a in active:
            by_market.setdefault(a.market.value, []).append(
                f"{a.symbol} (priority: {a.priority_score:.2f}, signals: {a.signals_generated}, tags: {a.tags})"
            )

        lines = [f"Current Watchlist ({stats['total_active']}/{stats['total_capacity']}):"]
        for market, assets in by_market.items():
            lines.append(f"\n{market.upper()}:")
            for a_str in assets:
                lines.append(f"  - {a_str}")

        return "\n".join(lines)
