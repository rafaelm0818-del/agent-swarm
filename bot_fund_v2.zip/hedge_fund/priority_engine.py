"""
Priority Engine - Real-Time Agent Execution Manager

Tier system (highest to lowest priority):

  TIER 0 - CRITICAL (< 1 second response)
  ├── Circuit breakers (drawdown limits)
  ├── Stop loss triggers
  └── Position liquidation

  TIER 1 - HIGH (every 10-30 seconds)
  ├── Monitor Agent (live P&L, position health)
  ├── Screener Agent (signal detection)
  └── Order execution queue

  TIER 2 - MEDIUM (every 5-15 minutes)  
  ├── Screener deep scans
  ├── Cross-agent signal validation
  └── Position sizing adjustments

  TIER 3 - LOW (every 1-24 hours)
  ├── Research Agent (new opportunities)
  ├── Quant Agent (backtesting)
  ├── Risk Agent (strategy review)
  ├── Engineer Agent (deployment)
  └── Rebalancer (portfolio optimization)

Key principle: NEVER let a Tier 3 task block a Tier 0/1 task.
"""
import asyncio
import time
import logging
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Callable, Awaitable, Any, Optional
from collections import defaultdict

logger = logging.getLogger("PriorityEngine")


class Priority(IntEnum):
    CRITICAL = 0   # Circuit breakers, stop losses
    HIGH = 1       # Monitor, screener signals
    MEDIUM = 2     # Deep scans, validation
    LOW = 3        # Research, backtest, deploy


@dataclass
class ScheduledTask:
    """A task that runs on a recurring schedule."""
    name: str
    priority: Priority
    interval_seconds: float
    callback: Callable[[], Awaitable[Any]]
    last_run: float = 0.0
    is_running: bool = False
    run_count: int = 0
    total_runtime: float = 0.0
    errors: int = 0
    enabled: bool = True
    
    # Concurrency control
    max_concurrent: int = 1  # How many instances can run simultaneously
    current_concurrent: int = 0
    
    # Timeout
    timeout_seconds: float = 300.0  # Kill if exceeds this
    
    @property
    def avg_runtime(self) -> float:
        return self.total_runtime / max(self.run_count, 1)
    
    @property
    def is_due(self) -> bool:
        if not self.enabled:
            return False
        return (time.time() - self.last_run) >= self.interval_seconds
    
    @property
    def overdue_by(self) -> float:
        """How many seconds past due. Negative = not yet due."""
        return time.time() - self.last_run - self.interval_seconds


@dataclass
class TaskResult:
    task_name: str
    priority: Priority
    success: bool
    runtime: float
    result: Any = None
    error: str = ""


class PriorityEngine:
    """
    Manages agent execution with strict priority ordering.
    
    Core guarantees:
    1. CRITICAL tasks ALWAYS run immediately, preempting everything
    2. HIGH tasks run on tight loops, never blocked by LOW tasks
    3. LOW tasks only run when HIGH/MEDIUM slots are clear
    4. Each tier has its own asyncio task pool
    """

    def __init__(self):
        self.tasks: dict[str, ScheduledTask] = {}
        self.is_running = False
        self._tier_locks: dict[Priority, asyncio.Semaphore] = {
            Priority.CRITICAL: asyncio.Semaphore(5),   # Always room for critical
            Priority.HIGH: asyncio.Semaphore(3),       # 3 concurrent high-pri
            Priority.MEDIUM: asyncio.Semaphore(2),     # 2 concurrent medium
            Priority.LOW: asyncio.Semaphore(1),        # 1 at a time for low
        }
        self._task_results: list[TaskResult] = []
        self._event_bus = EventBus()
        self._running_tasks: dict[str, asyncio.Task] = {}

    @property
    def event_bus(self) -> 'EventBus':
        return self._event_bus

    def register(
        self,
        name: str,
        priority: Priority,
        interval_seconds: float,
        callback: Callable[[], Awaitable[Any]],
        timeout_seconds: float = 300.0,
    ):
        """Register a recurring task."""
        self.tasks[name] = ScheduledTask(
            name=name,
            priority=priority,
            interval_seconds=interval_seconds,
            callback=callback,
            timeout_seconds=timeout_seconds,
        )
        logger.info(f"Registered task: {name} (Tier {priority.value}, every {interval_seconds}s)")

    async def run(self):
        """Main priority loop."""
        self.is_running = True
        logger.info("🚀 Priority Engine started")
        
        # The core loop runs every 500ms to check for due tasks
        while self.is_running:
            try:
                # Collect all due tasks, sorted by priority (lowest number = highest priority)
                due_tasks = sorted(
                    [t for t in self.tasks.values() if t.is_due and not t.is_running],
                    key=lambda t: (t.priority.value, -t.overdue_by)
                )

                for task in due_tasks:
                    # Check if we have capacity in this tier
                    tier_sem = self._tier_locks[task.priority]
                    
                    if task.priority == Priority.CRITICAL:
                        # Critical tasks ALWAYS run
                        asyncio.create_task(self._execute_task(task, tier_sem))
                    elif tier_sem._value > 0:
                        # Non-critical: only if there's capacity
                        # Also check: don't start LOW tasks if HIGH tasks are overdue
                        if task.priority >= Priority.LOW:
                            high_overdue = any(
                                t.is_due and t.priority <= Priority.HIGH 
                                for t in self.tasks.values() 
                                if not t.is_running
                            )
                            if high_overdue:
                                continue  # Skip low-pri, let high-pri go first
                        
                        asyncio.create_task(self._execute_task(task, tier_sem))

                await asyncio.sleep(0.5)  # 500ms tick

            except Exception as e:
                logger.error(f"Priority engine error: {e}", exc_info=True)
                await asyncio.sleep(1)

    async def _execute_task(self, task: ScheduledTask, semaphore: asyncio.Semaphore):
        """Execute a single task with timeout and error handling."""
        async with semaphore:
            task.is_running = True
            task.last_run = time.time()
            start = time.time()

            try:
                result = await asyncio.wait_for(
                    task.callback(),
                    timeout=task.timeout_seconds
                )
                runtime = time.time() - start
                task.run_count += 1
                task.total_runtime += runtime

                self._task_results.append(TaskResult(
                    task_name=task.name,
                    priority=task.priority,
                    success=True,
                    runtime=runtime,
                    result=result,
                ))

                # Publish result to event bus for cross-agent communication
                await self._event_bus.publish(f"task.{task.name}.complete", result)

                if runtime > task.interval_seconds * 0.8:
                    logger.warning(
                        f"⚠️ Task {task.name} took {runtime:.1f}s "
                        f"(interval: {task.interval_seconds}s) - may cause drift"
                    )

            except asyncio.TimeoutError:
                task.errors += 1
                logger.error(f"❌ Task {task.name} timed out after {task.timeout_seconds}s")
                self._task_results.append(TaskResult(
                    task_name=task.name,
                    priority=task.priority,
                    success=False,
                    runtime=task.timeout_seconds,
                    error="timeout",
                ))
            except Exception as e:
                task.errors += 1
                logger.error(f"❌ Task {task.name} failed: {e}", exc_info=True)
                self._task_results.append(TaskResult(
                    task_name=task.name,
                    priority=task.priority,
                    success=False,
                    runtime=time.time() - start,
                    error=str(e),
                ))
            finally:
                task.is_running = False

    def stop(self):
        self.is_running = False

    def get_status(self) -> dict:
        """Get engine status for monitoring."""
        status = {"tiers": {}, "tasks": {}}
        for priority in Priority:
            tier_tasks = [t for t in self.tasks.values() if t.priority == priority]
            status["tiers"][priority.name] = {
                "task_count": len(tier_tasks),
                "running": sum(1 for t in tier_tasks if t.is_running),
                "capacity": self._tier_locks[priority]._value,
            }
        for name, task in self.tasks.items():
            status["tasks"][name] = {
                "priority": task.priority.name,
                "interval": task.interval_seconds,
                "running": task.is_running,
                "runs": task.run_count,
                "avg_runtime": f"{task.avg_runtime:.2f}s",
                "errors": task.errors,
                "enabled": task.enabled,
            }
        return status

    def pause_task(self, name: str):
        if name in self.tasks:
            self.tasks[name].enabled = False

    def resume_task(self, name: str):
        if name in self.tasks:
            self.tasks[name].enabled = True

    def force_run(self, name: str):
        """Force a task to run immediately on next tick."""
        if name in self.tasks:
            self.tasks[name].last_run = 0


class EventBus:
    """
    Simple pub/sub for cross-agent communication.
    
    This is how agents talk to each other:
    - Screener publishes signals → Monitor picks them up
    - Monitor publishes alerts → Risk Agent responds
    - Research publishes opportunities → Quant picks them up
    """

    def __init__(self):
        self._subscribers: dict[str, list[Callable]] = defaultdict(list)
        self._message_log: list[dict] = []
        self._max_log = 1000

    def subscribe(self, event: str, callback: Callable[..., Awaitable[Any]]):
        """Subscribe to an event type."""
        self._subscribers[event].append(callback)

    async def publish(self, event: str, data: Any = None):
        """Publish an event to all subscribers."""
        self._message_log.append({
            "event": event,
            "timestamp": time.time(),
            "data_preview": str(data)[:200] if data else None,
        })
        if len(self._message_log) > self._max_log:
            self._message_log = self._message_log[-self._max_log:]

        for callback in self._subscribers.get(event, []):
            try:
                await callback(data)
            except Exception as e:
                logger.error(f"Event handler error for {event}: {e}")

        # Also publish to wildcard subscribers
        for callback in self._subscribers.get("*", []):
            try:
                await callback(event, data)
            except Exception as e:
                logger.error(f"Wildcard handler error: {e}")

    def get_recent_events(self, limit: int = 50) -> list[dict]:
        return self._message_log[-limit:]
