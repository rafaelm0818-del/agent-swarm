"""
Fund Manager v2 - Priority-Driven with Screener Integration

This replaces the simple loop with the PriorityEngine.
Each function of the fund is now a scheduled task at the right priority tier.

Architecture:
                    ┌─────────────────────────┐
                    │     PRIORITY ENGINE      │
                    └────────┬────────────────┘
                             │
    ┌────────────────────────┼────────────────────────────┐
    │                        │                            │
    ▼                        ▼                            ▼
┌─────────┐          ┌──────────────┐            ┌─────────────┐
│ TIER 0  │          │   TIER 1     │            │  TIER 2-3   │
│CRITICAL │          │   HIGH       │            │  MED/LOW    │
├─────────┤          ├──────────────┤            ├─────────────┤
│Circuit  │          │Fast Scan (30s)│           │Deep Scan(5m)│
│Breakers │          │Monitor   (30s)│           │Research(24h)│
│Stop Loss│          │Order Exec    │            │Backtest     │
│         │          │              │            │Risk Review  │
│         │          │              │            │Deploy       │
│         │          │              │            │Rebalance(12h│
└─────────┘          └──────┬───────┘            └──────┬──────┘
                            │                           │
                            ▼                           ▼
                    ┌──────────────┐            ┌──────────────┐
                    │  EVENT BUS   │◄───────────│  EVENT BUS   │
                    │  (signals)   │───────────►│  (actions)   │
                    └──────────────┘            └──────────────┘

Signal Flow:
  Screener Fast Scan → publishes signal → Monitor picks it up
  Monitor detects issue → publishes alert → Risk Agent responds
  Screener Deep Scan → publishes opportunity → Research picks it up
  Research validates → Quant backtests → Risk reviews → Engineer deploys
"""
import asyncio
import json
import time
import logging
from datetime import datetime, timedelta

from hedge_fund.priority_engine import PriorityEngine, Priority, EventBus
from hedge_fund.fund_manager import (
    FundManager, FundConfig, Strategy, StrategyStatus
)
from hedge_fund.watchlist_integration import WatchlistIntegration
from agents.screener_agent import ScreenerAgent
from agents.signal_intelligence import SignalIntelligenceEngine
from agents.watchlist_manager_agent import WatchlistManagerAgent, WatchlistConfig

logger = logging.getLogger("FundManagerV2")


class FundManagerV2(FundManager):
    """
    Enhanced fund manager with priority-based execution, screener,
    and dynamic watchlist management across all markets.
    """

    def __init__(self, config: FundConfig, orchestrator, telegram_notify=None):
        super().__init__(config, orchestrator, telegram_notify)
        
        self.priority_engine = PriorityEngine()
        self.screener = ScreenerAgent()
        self.watchlist_manager = WatchlistManagerAgent(WatchlistConfig())
        
        # Register agents in orchestrator
        self.orchestrator.agents["screener"] = self.screener
        self.orchestrator.agents["watchlist_manager"] = self.watchlist_manager
        
        # Watchlist integration (connects everything)
        self.watchlist_integration = WatchlistIntegration(
            watchlist_manager=self.watchlist_manager,
            screener=self.screener,
            priority_engine=self.priority_engine,
        )
        
        # Signal queue: screener signals waiting to be processed
        self._pending_signals: list[dict] = []
        
        # ══ Signal Intelligence Layer ══
        # Sits between screener and execution — applies steroids D, E, F
        # plus counter-trend, persistence, and correlation filters
        self.signal_intelligence = SignalIntelligenceEngine()
        
        # Performance tracking
        self._cycle_metrics = {
            "fast_scans": 0,
            "deep_scans": 0,
            "signals_generated": 0,
            "signals_acted_on": 0,
            "strategies_created": 0,
            "strategies_deployed": 0,
            "circuit_breakers_hit": 0,
            "watchlist_adds": 0,
            "watchlist_removes": 0,
        }

    async def run(self):
        """Start the priority-driven fund loop."""
        self.is_running = True

        # Setup watchlist integration (event bus + task registration)
        self.watchlist_integration.setup()

        wl_stats = json.loads(self.watchlist_manager._get_stats())
        await self._notify(
            "🚀 *Hedge Fund V2 Online*\n"
            f"Capital: ${self.config.total_capital:,.2f}\n"
            f"Mode: {self.config.execution_mode}\n"
            f"Watchlist: {wl_stats['total_active']} assets across "
            f"{len(wl_stats['by_market'])} markets\n\n"
            "*Priority Tiers:*\n"
            "⚡ T0 Circuit breakers (always)\n"
            "🔴 T1 Fast scan + monitor (30s)\n"  
            "🟡 T2 Deep scan + validate (5m)\n"
            "🟢 T3 Research + build + deploy (1-24h)\n"
            "📋 T3 Watchlist cleanup + discovery (6-12h)"
        )

        # ── Register all tasks with priorities ──────────────────

        # TIER 0: CRITICAL - Circuit breakers
        self.priority_engine.register(
            name="circuit_breakers",
            priority=Priority.CRITICAL,
            interval_seconds=5,        # Check every 5 seconds
            callback=self._task_circuit_breakers,
            timeout_seconds=3,
        )

        # TIER 1: HIGH - Screener fast scan
        self.priority_engine.register(
            name="fast_scan",
            priority=Priority.HIGH,
            interval_seconds=30,       # Every 30 seconds
            callback=self._task_fast_scan,
            timeout_seconds=45,
        )

        # TIER 1: HIGH - Monitor live positions
        self.priority_engine.register(
            name="monitor",
            priority=Priority.HIGH,
            interval_seconds=30,       # Every 30 seconds
            callback=self._task_monitor,
            timeout_seconds=60,
        )

        # TIER 2: MEDIUM - Deep scan
        self.priority_engine.register(
            name="deep_scan",
            priority=Priority.MEDIUM,
            interval_seconds=300,      # Every 5 minutes
            callback=self._task_deep_scan,
            timeout_seconds=120,
        )

        # TIER 2: MEDIUM - Process screener signals
        self.priority_engine.register(
            name="signal_processor",
            priority=Priority.MEDIUM,
            interval_seconds=60,       # Every minute
            callback=self._task_process_signals,
            timeout_seconds=60,
        )

        # TIER 2: MEDIUM - Regime detection
        self.priority_engine.register(
            name="regime_detection",
            priority=Priority.MEDIUM,
            interval_seconds=900,      # Every 15 minutes
            callback=self._task_regime_detection,
            timeout_seconds=90,
        )

        # TIER 3: LOW - Research new strategies
        self.priority_engine.register(
            name="research",
            priority=Priority.LOW,
            interval_seconds=self.config.research_interval_hours * 3600,
            callback=self._task_research,
            timeout_seconds=600,
        )

        # TIER 3: LOW - Process strategy pipeline
        self.priority_engine.register(
            name="pipeline",
            priority=Priority.LOW,
            interval_seconds=300,      # Every 5 minutes, process next pipeline step
            callback=self._task_pipeline,
            timeout_seconds=600,
        )

        # TIER 3: LOW - Rebalance
        self.priority_engine.register(
            name="rebalance",
            priority=Priority.LOW,
            interval_seconds=self.config.rebalance_interval_hours * 3600,
            callback=self._task_rebalance,
            timeout_seconds=300,
        )

        # TIER 3: LOW - Self-Tune Exit Configs (Learning System → Execution Engine)
        # Cerebellum analyzes closed trades and classifies assets as trending/reverting
        # Then updates the execution engine's exit configs per asset
        self.priority_engine.register(
            name="self_tune",
            priority=Priority.LOW,
            interval_seconds=1800,     # Every 30 minutes
            callback=self._task_self_tune,
            timeout_seconds=120,
        )

        # TIER 3: LOW - Signal Intelligence Stats Report
        self.priority_engine.register(
            name="intel_report",
            priority=Priority.LOW,
            interval_seconds=3600,     # Every hour
            callback=self._task_intel_report,
            timeout_seconds=30,
        )

        # ── Set up event bus subscriptions ──────────────────────

        bus = self.priority_engine.event_bus

        # When screener completes fast scan, process any signals immediately
        bus.subscribe("task.fast_scan.complete", self._on_fast_scan_complete)
        
        # When deep scan finds something, queue it for research
        bus.subscribe("task.deep_scan.complete", self._on_deep_scan_complete)
        
        # When a strategy gets deployed, start monitoring it
        bus.subscribe("strategy.deployed", self._on_strategy_deployed)

        # ── Run the engine ──────────────────────────────────────
        
        logger.info("Starting priority engine...")
        await self.priority_engine.run()

    async def stop(self):
        """Graceful shutdown."""
        self.priority_engine.stop()
        await super().stop()

    # ── Tier 0: Critical Tasks ──────────────────────────────────

    async def _task_circuit_breakers(self):
        """Check all circuit breakers. MUST be fast (<1s)."""
        if self._check_circuit_breakers():
            self._cycle_metrics["circuit_breakers_hit"] += 1
            # Pause all non-critical tasks
            self.priority_engine.pause_task("fast_scan")
            self.priority_engine.pause_task("deep_scan")
            self.priority_engine.pause_task("research")
            self.priority_engine.pause_task("pipeline")
            self.priority_engine.pause_task("rebalance")
            return {"status": "triggered"}
        return {"status": "ok"}

    # ── Tier 1: High Priority Tasks ─────────────────────────────

    async def _task_fast_scan(self):
        """Quick screener scan - detect immediate signals."""
        self._cycle_metrics["fast_scans"] += 1
        
        prompt = ScreenerAgent.fast_scan_prompt(self.screener.watchlist)
        result = await self.screener.run(prompt)
        self.screener.reset()
        
        return {"scan_type": "fast", "result": result.response[:500]}

    async def _task_monitor(self):
        """Monitor live positions and strategies."""
        live = [s for s in self.strategies.values() 
                if s.status in (StrategyStatus.LIVE, StrategyStatus.DEPLOYED)]
        
        if not live:
            return {"status": "no_live_strategies"}

        # Check paper trade promotions
        for strategy in live:
            if strategy.status == StrategyStatus.DEPLOYED and strategy.live_start_date:
                start = datetime.fromisoformat(strategy.live_start_date)
                days = (datetime.utcnow() - start).days
                strategy.paper_trade_days = days
                
                if days >= self.config.paper_trade_days_required:
                    strategy.status = StrategyStatus.LIVE
                    strategy.log_change("monitor", "promoted", f"Paper traded {days} days")
                    await self._notify(
                        f"📈 *Strategy Promoted to Live*\n{strategy.name}\n"
                        f"Paper P&L: ${strategy.live_pnl:,.2f}"
                    )

        # Get current screener signals for cross-reference
        active_signals = self.screener._get_active_signals(None, None)
        
        monitor_prompt = f"""Quick health check on live strategies:
{json.dumps([{'name': s.name, 'assets': s.assets, 'pnl': s.live_pnl, 'trades': s.live_trades} for s in live])}

Active screener signals: {active_signals[:1000]}

Flag any strategy that needs attention. Be brief."""

        result = await self.orchestrator.route_and_execute(monitor_prompt)
        return {"status": "checked", "live_count": len(live)}

    # ── Tier 2: Medium Priority Tasks ───────────────────────────

    async def _task_deep_scan(self):
        """Comprehensive technical analysis scan."""
        self._cycle_metrics["deep_scans"] += 1

        active_signals = json.loads(
            self.screener._get_active_signals(None, None)
        )

        prompt = ScreenerAgent.deep_scan_prompt(
            self.screener.watchlist, 
            active_signals
        )
        result = await self.screener.run(prompt)
        self.screener.reset()
        
        return {"scan_type": "deep", "result": result.response[:500]}

    async def _task_process_signals(self):
        """
        Process pending screener signals through the Signal Intelligence Layer.
        
        Pipeline:
          Raw signals → Steroid D (stacking) → Steroid E (multi-TF) → Steroid F (mean-reversion)
          → Counter-trend filter → Persistence filter → Correlation filter
          → Enhanced signals with boosted/penalized confidence
        """
        recent_signals = [
            s for s in self.screener.signal_history
            if time.time() - s.timestamp < 300  # Last 5 minutes
            and not s.consumed_by  # Not yet processed
        ]

        if not recent_signals:
            return {"processed": 0, "passed": 0, "blocked": 0}

        # Convert ScreenerSignals to dicts for the intelligence engine
        raw_signal_dicts = [
            {
                "signal_id": s.signal_id,
                "asset": s.asset,
                "direction": s.direction,
                "signal_type": s.signal_type,
                "confidence": s.confidence,
                "price": s.price_at_signal,
                "timestamp": s.timestamp,
                "details": s.details,
            }
            for s in recent_signals
        ]
        
        # Get current regime from execution engine or adaptive config
        regime = "RANGING"
        if hasattr(self, 'execution_engine') and hasattr(self.execution_engine, 'current_regime'):
            regime = self.execution_engine.current_regime
        
        # Get open positions for correlation blocking
        open_positions = {}
        if hasattr(self, 'execution_engine') and hasattr(self.execution_engine, 'positions'):
            open_positions = self.execution_engine.positions
        
        # Get price histories for multi-TF alignment
        price_histories = {}
        if hasattr(self, 'execution_engine') and hasattr(self.execution_engine, 'positions'):
            for pos_id, pos in open_positions.items():
                if hasattr(pos, 'price_history'):
                    price_histories[pos.symbol] = pos.price_history
        
        # Get exit configs from learning system
        exit_configs = {}
        if hasattr(self, 'execution_engine') and hasattr(self.execution_engine, '_exit_configs'):
            exit_configs = self.execution_engine._exit_configs
        
        # ══ Run through Signal Intelligence Engine ══
        enhanced_signals = self.signal_intelligence.process_signals(
            raw_signals=raw_signal_dicts,
            regime=regime,
            open_positions=open_positions,
            price_histories=price_histories,
            exit_configs=exit_configs,
        )
        
        # Only process signals that passed ALL filters
        passed = [s for s in enhanced_signals if s.passed_all_filters]
        blocked = [s for s in enhanced_signals if not s.passed_all_filters]
        
        # Apply asset-specific minimum confidence from overrides
        try:
            from config.markets import ASSET_OVERRIDES
            actionable = []
            for s in passed:
                override = ASSET_OVERRIDES.get(s.asset)
                min_conf = override.min_confidence if override else 0.70
                if s.confidence >= min_conf:
                    actionable.append(s)
                else:
                    logger.debug(
                        f"FILTERED (low confidence): {s.asset} {s.confidence:.2f} < {min_conf:.2f}"
                    )
        except ImportError:
            actionable = [s for s in passed if s.confidence >= 0.7]
        
        # Mark originals as consumed
        for sig in recent_signals:
            sig.consumed_by.append("signal_intelligence")
        
        for signal in actionable:
            self._cycle_metrics["signals_acted_on"] += 1
            
            # Check if we already have a strategy for this asset
            existing = [
                s for s in self.strategies.values()
                if signal.asset in s.assets 
                and s.status in (StrategyStatus.LIVE, StrategyStatus.DEPLOYED, 
                                StrategyStatus.BACKTESTING, StrategyStatus.RISK_REVIEW)
            ]

            if not existing:
                # New opportunity - create a strategy from the enhanced signal
                stacked_tag = " ⚡STACKED" if signal.stacked else ""
                mr_tag = " 🔄MR" if signal.is_mean_reversion else ""
                tf_tag = " ✅TF" if signal.timeframe_aligned else " ⚠️TF-misalign"
                
                await self._notify(
                    f"📡 *Enhanced Signal*{stacked_tag}{mr_tag}{tf_tag}\n"
                    f"Asset: {signal.asset} | Direction: {signal.direction}\n"
                    f"Type: {signal.signal_type}"
                    f"{' + ' + ', '.join(signal.stacked_types) if signal.stacked else ''}\n"
                    f"Confidence: {signal.original_confidence:.2f} → {signal.confidence:.2f}\n"
                    f"Persistence: {signal.persistence_count} consecutive\n"
                    f"Queuing for strategy development..."
                )
                
                # Include enhancement metadata in the pending signal
                self._pending_signals.append({
                    "signal_id": signal.signal_id,
                    "asset": signal.asset,
                    "direction": signal.direction,
                    "signal_type": signal.signal_type,
                    "confidence": signal.confidence,
                    "original_confidence": signal.original_confidence,
                    "stacked": signal.stacked,
                    "stacked_types": signal.stacked_types,
                    "is_mean_reversion": signal.is_mean_reversion,
                    "timeframe_aligned": signal.timeframe_aligned,
                    "persistence_count": signal.persistence_count,
                    "suggested_behavior": signal.suggested_behavior,
                    "price": signal.price,
                    "timestamp": signal.timestamp,
                })

        # Log blocked signal summary for learning
        if blocked:
            block_reasons = {}
            for s in blocked:
                reason = s.filter_blocked_by or "unknown"
                block_reasons[reason] = block_reasons.get(reason, 0) + 1
            logger.info(
                f"Signal Intelligence: {len(passed)} passed, {len(blocked)} blocked "
                f"({', '.join(f'{r}={c}' for r, c in block_reasons.items())}), "
                f"{len(actionable)} actionable"
            )

        return {
            "processed": len(recent_signals),
            "passed": len(passed),
            "blocked": len(blocked),
            "actionable": len(actionable),
        }

    async def _task_regime_detection(self):
        """Detect overall market regime."""
        prompt = ScreenerAgent.regime_detection_prompt()
        result = await self.screener.run(prompt)
        self.screener.reset()

        # Parse regime and update watchlist if needed
        regime_data = self._parse_json_from_response(result.response)
        if regime_data:
            regime = regime_data.get("regime", "unknown")
            favored = regime_data.get("assets_to_favor", [])
            
            if favored:
                for asset in favored:
                    self.screener.add_to_watchlist(asset)

            await self.priority_engine.event_bus.publish("regime.update", regime_data)
            
            # Notify on regime changes
            await self._notify(
                f"🌍 *Market Regime Update*\n"
                f"Regime: {regime}\n"
                f"Confidence: {regime_data.get('confidence', 0):.0%}\n"
                f"Trend: {regime_data.get('trend_direction', 'N/A')}\n"
                f"Volatility: {regime_data.get('volatility_level', 'N/A')}\n"
                f"Favored: {', '.join(favored) if favored else 'N/A'}"
            )

        return {"regime": regime_data}

    # ── Tier 3: Low Priority Tasks ──────────────────────────────

    async def _task_research(self):
        """Research new opportunities (enhanced with screener + watchlist + learning data)."""
        signal_summary = self.screener.get_signal_summary(hours=24)
        active_signals = json.loads(self.screener._get_active_signals(None, None))
        watchlist_context = self.watchlist_integration.get_research_context()

        # Inject learning insights if available
        learning_context = ""
        if hasattr(self, 'learning') and self.learning:
            learning_context = self.learning.get_research_context()

        pending_context = ""
        if self._pending_signals:
            pending_context = f"\n\nPending high-confidence signals to build strategies for:\n{json.dumps(self._pending_signals[:5], indent=2)}"
            self._pending_signals = self._pending_signals[5:]

        await self._research_cycle_enhanced(signal_summary, active_signals, pending_context, watchlist_context, learning_context)
        return {"researched": True}

    async def _research_cycle_enhanced(self, signal_summary, active_signals, pending_context, watchlist_context="", learning_context=""):
        """Enhanced research that incorporates screener + watchlist + learning data from all markets."""
        active_assets = set()
        for s in self.strategies.values():
            if s.status in (StrategyStatus.LIVE, StrategyStatus.DEPLOYED):
                active_assets.update(s.assets)

        research_prompt = f"""You are the research arm of an autonomous hedge fund.

Screener Intelligence (last 24h):
{signal_summary}

Active Signals:
{json.dumps(active_signals[:10], indent=2)}
{pending_context}

{watchlist_context}

{learning_context}

Current Portfolio:
- Capital: ${self.portfolio_state['cash']:,.2f}
- Active strategies: {len([s for s in self.strategies.values() if s.status == StrategyStatus.LIVE])}
- Assets already traded: {list(active_assets) if active_assets else 'None'}

IMPORTANT: 
1. The screener has already identified potential setups above.
2. You have access to assets across ALL markets (crypto, stocks, forex, commodities, ETFs) - not just crypto.
3. When you find opportunities, also recommend watchlist changes:
   - New assets that should be added
   - Stale assets that should be removed
   - Priority adjustments for existing assets

Your job:
1. Validate the screener's signals with deeper research
2. Develop specific, backtestable strategy hypotheses from the strongest signals
3. Look for CROSS-MARKET opportunities (e.g., crypto-stock correlations, commodity hedges)
4. If no screener signals are compelling, search for NEW opportunities

For each opportunity, provide detailed JSON:
{{
  "market_regime": "...",
  "opportunities": [
    {{
      "name": "strategy name",
      "assets": ["BTC"],
      "market": "crypto",
      "timeframe": "4h",
      "hypothesis": "Specific, testable hypothesis with numbers",
      "entry_logic": "Exact conditions with indicator values",
      "exit_logic": "Exact exit conditions",
      "source_signal_id": "sig_xxx if from screener, null if new",
      "data_needed": "what to backtest"
    }}
  ],
  "watchlist_recommendations": [
    {{
      "action": "add|boost|reduce|remove",
      "symbol": "PEPE",
      "market": "crypto",
      "reason": "why",
      "priority": 0.7,
      "tags": ["memecoin", "momentum"]
    }}
  ]
}}

Quality over quantity. Only propose strategies you'd bet your own money on."""

        result = await self.orchestrator.route_and_execute(research_prompt)
        
        try:
            parsed = self._parse_json_from_response(result)
            if not parsed:
                return

            # Process strategy opportunities
            opportunities = parsed.get("opportunities", [])
            for opp in opportunities:
                strategy_id = f"strat_{int(time.time())}_{opp['name'][:10].replace(' ', '_').lower()}"
                strategy = Strategy(
                    id=strategy_id,
                    name=opp["name"],
                    description=opp.get("hypothesis", ""),
                    hypothesis=opp.get("hypothesis", ""),
                    assets=opp.get("assets", []),
                    timeframe=opp.get("timeframe", "4h"),
                )
                strategy.status = StrategyStatus.BACKTESTING
                strategy.log_change("researcher", "created", 
                    f"Source: {'screener signal' if opp.get('source_signal_id') else 'new research'}")
                self.strategies[strategy_id] = strategy
                self._cycle_metrics["strategies_created"] += 1

                # Record on watchlist that this asset spawned a strategy
                for asset_symbol in opp.get("assets", []):
                    market = opp.get("market", "crypto")
                    self.watchlist_manager.record_strategy_spawned(asset_symbol, market)

                if self.config.alert_on_new_strategy:
                    await self._notify(
                        f"🔬 *New Strategy*\n"
                        f"Name: {strategy.name}\n"
                        f"Assets: {', '.join(strategy.assets)}\n"
                        f"TF: {strategy.timeframe}\n"
                        f"Hypothesis: {strategy.hypothesis[:200]}"
                    )

            # Process watchlist recommendations from research
            wl_recs = parsed.get("watchlist_recommendations", [])
            for rec in wl_recs:
                try:
                    wl_result = self.watchlist_manager._process_recommendation({
                        "action": rec.get("action", "add"),
                        "symbol": rec.get("symbol", ""),
                        "market": rec.get("market", "crypto"),
                        "from_agent": "research",
                        "reason": rec.get("reason", "Research recommendation"),
                        "priority_suggestion": rec.get("priority", 0.6),
                        "tags": rec.get("tags", []),
                    })
                    wl_data = json.loads(wl_result)
                    if wl_data.get("success"):
                        action = rec.get("action", "add")
                        self._cycle_metrics[f"watchlist_{'adds' if action == 'add' else 'removes'}"] += 1
                        await self._notify(
                            f"📋 *Watchlist {action.upper()}*: {rec['symbol']} ({rec.get('market', 'crypto')})\n"
                            f"Reason: {rec.get('reason', 'N/A')[:100]}"
                        )
                except Exception as e:
                    logger.error(f"Watchlist recommendation failed: {e}")

        except Exception as e:
            logger.error(f"Research parsing failed: {e}")

    async def _task_pipeline(self):
        """Process strategy pipeline - move strategies through stages."""
        await self._process_pipeline()
        return {"processed": True}

    async def _task_rebalance(self):
        """Rebalance portfolio allocations."""
        await self._rebalance_cycle()
        return {"rebalanced": True}

    async def _task_self_tune(self):
        """
        Self-Tuning Exit Configs — The Cerebellum Adjusts the Body
        
        Calls the learning system to analyze closed trades and classify
        each asset as "trending" (hold longer) or "reverting" (exit faster).
        Then updates the execution engine's exit configs per asset.
        
        This is where the system teaches itself:
        - BTC keeps hitting trail stops early → classify as REVERTING → tighten trail
        - TSLA keeps reaching TP and beyond → classify as TRENDING → widen trail
        """
        try:
            if not hasattr(self, 'learning') or not self.learning:
                return {"self_tuned": False, "reason": "no learning system"}
            
            if not hasattr(self, 'execution_engine') or not self.execution_engine:
                return {"self_tuned": False, "reason": "no execution engine"}
            
            # Call the learning system's exit tuning method
            result = self.learning.compute_exit_tuning(self.execution_engine)
            
            if result and "tuning" in result:
                # Extract trending/reverting classifications
                trending = [
                    sym for sym, info in result["tuning"].items()
                    if info.get("config", {}).get("behavior") == "trending"
                ]
                reverting = [
                    sym for sym, info in result["tuning"].items()
                    if info.get("config", {}).get("behavior") == "reverting"
                ]
                
                if trending or reverting:
                    msg_parts = ["🧬 *Self-Tune Results*"]
                    if trending:
                        msg_parts.append(f"📈 Trending (hold longer): {', '.join(trending)}")
                    if reverting:
                        msg_parts.append(f"📉 Reverting (exit faster): {', '.join(reverting)}")
                    await self._notify("\n".join(msg_parts))
                
                return {"self_tuned": True, "trending": trending, "reverting": reverting}
            
            return {"self_tuned": True, "changes": 0}
            
        except Exception as e:
            logger.warning(f"Self-tune failed: {e}")
            return {"self_tuned": False, "error": str(e)}

    async def _task_intel_report(self):
        """
        Periodic Signal Intelligence stats report.
        Shows how the filters and enhancements are performing.
        """
        try:
            report = self.signal_intelligence.get_stats_summary()
            
            # Also include profit progression stats if available
            pp_report = ""
            if hasattr(self, 'execution_engine') and hasattr(self.execution_engine, 'profit_progression'):
                pp_report = "\n" + self.execution_engine.profit_progression.get_stats_summary()
            
            await self._notify(f"{report}{pp_report}")
            
            # Reset hourly stats
            self.signal_intelligence.reset_stats()
            if hasattr(self, 'execution_engine') and hasattr(self.execution_engine, 'profit_progression'):
                self.execution_engine.profit_progression.reset_stats()
            
            return {"reported": True}
        except Exception as e:
            logger.warning(f"Intel report failed: {e}")
            return {"reported": False}

    # ── Event Handlers ──────────────────────────────────────────

    async def _on_fast_scan_complete(self, result):
        """Called when fast scan completes - check for urgent signals."""
        urgent = [
            s for s in self.screener.signal_history
            if time.time() - s.timestamp < 30  # Just generated
            and s.strength >= 0.8
            and s.confidence >= 0.8
        ]
        for signal in urgent:
            self._cycle_metrics["signals_generated"] += 1
            await self._notify(f"⚡ *URGENT SIGNAL*\n{signal.to_telegram()}")

    async def _on_deep_scan_complete(self, result):
        """Called when deep scan completes."""
        pass  # Signals are already published and will be picked up by signal_processor

    async def _on_strategy_deployed(self, strategy_data):
        """Called when a strategy gets deployed."""
        self._cycle_metrics["strategies_deployed"] += 1

    # ── Enhanced Status ─────────────────────────────────────────

    def get_status(self) -> str:
        """Enhanced status with priority engine, screener, and watchlist info."""
        base_status = super().get_status()
        
        engine_status = self.priority_engine.get_status()
        signal_summary = self.screener.get_signal_summary(hours=4)
        wl_stats = json.loads(self.watchlist_manager._get_stats())
        
        lines = [
            base_status,
            "\n*Priority Engine:*",
        ]
        
        for tier_name, tier_info in engine_status["tiers"].items():
            lines.append(
                f"  {tier_name}: {tier_info['running']}/{tier_info['task_count']} running"
            )

        # Watchlist summary
        lines.append(f"\n📋 *Watchlist:* {wl_stats['total_active']}/{wl_stats['total_capacity']} assets")
        for market, info in wl_stats.get("by_market", {}).items():
            lines.append(f"  {market}: {info['count']}/{info['capacity']} (avg priority: {info['avg_priority']})")

        lines.extend([
            f"\n{signal_summary}",
            f"\n*Signal Intelligence:*",
            f"{self.signal_intelligence.get_stats_summary()}",
            f"\n*Metrics:*",
            f"Fast scans: {self._cycle_metrics['fast_scans']}",
            f"Deep scans: {self._cycle_metrics['deep_scans']}",
            f"Signals: {self._cycle_metrics['signals_generated']} generated, {self._cycle_metrics['signals_acted_on']} acted on",
            f"Strategies: {self._cycle_metrics['strategies_created']} created, {self._cycle_metrics['strategies_deployed']} deployed",
            f"Watchlist: +{self._cycle_metrics['watchlist_adds']} / -{self._cycle_metrics['watchlist_removes']}",
        ])

        return "\n".join(lines)

    def resume(self):
        """Resume all tasks after circuit breaker."""
        super().resume()
        # Re-enable paused tasks
        for task_name in ["fast_scan", "deep_scan", "research", "pipeline", "rebalance"]:
            self.priority_engine.resume_task(task_name)
