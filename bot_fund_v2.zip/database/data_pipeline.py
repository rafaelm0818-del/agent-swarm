"""
Data Pipeline - The Stomach

Centralized data ingestion, caching, and distribution layer.
All agents read from here instead of making their own API calls.

Features:
  - Multi-source price fetching (CoinGecko, Yahoo Finance)
  - Tiered caching (hot: 10s, warm: 60s, cold: 5m)
  - OHLCV history storage in database
  - Batch price requests (one call serves all agents)
  - Automatic source failover
  - Rate-limit aware (coordinates with security rate limiter)

Data Flow:
  External APIs → Data Pipeline (fetch + cache) → All Agents
  
  Instead of:
    Screener → CoinGecko
    Trading  → CoinGecko  (duplicate!)
    Research → CoinGecko  (triplicate!)
    
  Now:
    Data Pipeline → CoinGecko (once)
    Screener  ← Pipeline cache
    Trading   ← Pipeline cache
    Research  ← Pipeline cache
"""
import json
import time
import logging
import threading
import requests
from typing import Optional
from dataclasses import dataclass, field

logger = logging.getLogger("DataPipeline")

# CoinGecko symbol mapping
CG_MAP = {
    "BTC": "bitcoin", "ETH": "ethereum", "SOL": "solana",
    "XRP": "ripple", "DOGE": "dogecoin", "AVAX": "avalanche-2",
    "LINK": "chainlink", "ADA": "cardano", "DOT": "polkadot",
    "MATIC": "matic-network", "PEPE": "pepe", "SHIB": "shiba-inu",
    "UNI": "uniswap", "AAVE": "aave", "LTC": "litecoin",
    "NEAR": "near", "APT": "aptos", "ARB": "arbitrum",
    "OP": "optimism", "SUI": "sui", "SEI": "sei-network",
    "INJ": "injective-protocol", "TIA": "celestia",
    "RENDER": "render-token", "FET": "fetch-ai",
}


@dataclass
class PriceData:
    """Cached price data for an asset."""
    symbol: str
    price: float
    change_24h: float = 0.0
    volume_24h: float = 0.0
    market_cap: float = 0.0
    high_24h: float = 0.0
    low_24h: float = 0.0
    fetched_at: float = field(default_factory=time.time)
    source: str = "unknown"

    @property
    def age_seconds(self) -> float:
        return time.time() - self.fetched_at

    def is_stale(self, max_age: float = 30) -> bool:
        return self.age_seconds > max_age


@dataclass
class OHLCVBar:
    """Single OHLCV candle."""
    timestamp: float
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


class DataPipeline:
    """
    Centralized data management for all agents.
    """

    def __init__(self, rate_limiter=None, db=None):
        self.rate_limiter = rate_limiter
        self.db = db

        # Tiered cache
        self._price_cache: dict[str, PriceData] = {}
        self._ohlcv_cache: dict[str, list[OHLCVBar]] = {}
        self._ohlcv_cache_time: dict[str, float] = {}
        
        # Batch tracking
        self._last_batch_fetch = 0
        self._batch_interval = 10  # Fetch all prices every 10s max
        
        self._lock = threading.Lock()
        self._request_count = 0
        self._cache_hits = 0

    # ── Price Data ──────────────────────────────────────────────

    def get_price(self, symbol: str, max_age: float = 30) -> Optional[PriceData]:
        """
        Get current price for a symbol. Uses cache if fresh enough.
        """
        symbol = symbol.upper()
        
        # Check cache
        cached = self._price_cache.get(symbol)
        if cached and not cached.is_stale(max_age):
            self._cache_hits += 1
            return cached

        # Fetch fresh
        price_data = self._fetch_single_price(symbol)
        if price_data:
            self._price_cache[symbol] = price_data
        return price_data

    def get_prices_batch(self, symbols: list[str], max_age: float = 15) -> dict[str, PriceData]:
        """
        Get prices for multiple symbols in one API call.
        This is the primary method agents should use.
        """
        symbols = [s.upper() for s in symbols]
        result = {}
        need_fetch = []

        # Check cache first
        for symbol in symbols:
            cached = self._price_cache.get(symbol)
            if cached and not cached.is_stale(max_age):
                result[symbol] = cached
                self._cache_hits += 1
            else:
                need_fetch.append(symbol)

        # Batch fetch missing
        if need_fetch:
            fresh = self._fetch_batch_prices(need_fetch)
            for symbol, data in fresh.items():
                self._price_cache[symbol] = data
                result[symbol] = data

        return result

    def _fetch_single_price(self, symbol: str) -> Optional[PriceData]:
        """Fetch price from CoinGecko for a single symbol."""
        cg_id = CG_MAP.get(symbol, symbol.lower())
        
        if self.rate_limiter and not self.rate_limiter.check("coingecko"):
            logger.warning("CoinGecko rate limit hit")
            return self._price_cache.get(symbol)  # Return stale cache

        try:
            self._request_count += 1
            r = requests.get(
                "https://api.coingecko.com/api/v3/simple/price",
                params={
                    "ids": cg_id,
                    "vs_currencies": "usd",
                    "include_24hr_change": "true",
                    "include_24hr_vol": "true",
                    "include_market_cap": "true",
                },
                timeout=10,
            )
            data = r.json()
            if cg_id in data:
                d = data[cg_id]
                return PriceData(
                    symbol=symbol,
                    price=d.get("usd", 0),
                    change_24h=d.get("usd_24h_change", 0),
                    volume_24h=d.get("usd_24h_vol", 0),
                    market_cap=d.get("usd_market_cap", 0),
                    source="coingecko",
                )
        except Exception as e:
            logger.error(f"Price fetch failed for {symbol}: {e}")
        return None

    def _fetch_batch_prices(self, symbols: list[str]) -> dict[str, PriceData]:
        """Fetch multiple prices in one CoinGecko call."""
        result = {}
        
        # Map symbols to CoinGecko IDs
        cg_ids = {}
        for sym in symbols:
            cg_id = CG_MAP.get(sym, sym.lower())
            cg_ids[cg_id] = sym

        if self.rate_limiter and not self.rate_limiter.check("coingecko"):
            logger.warning("CoinGecko rate limit hit on batch")
            return result

        try:
            self._request_count += 1
            ids_str = ",".join(cg_ids.keys())
            r = requests.get(
                "https://api.coingecko.com/api/v3/simple/price",
                params={
                    "ids": ids_str,
                    "vs_currencies": "usd",
                    "include_24hr_change": "true",
                    "include_24hr_vol": "true",
                    "include_market_cap": "true",
                },
                timeout=15,
            )
            data = r.json()

            for cg_id, symbol in cg_ids.items():
                if cg_id in data:
                    d = data[cg_id]
                    result[symbol] = PriceData(
                        symbol=symbol,
                        price=d.get("usd", 0),
                        change_24h=d.get("usd_24h_change", 0),
                        volume_24h=d.get("usd_24h_vol", 0),
                        market_cap=d.get("usd_market_cap", 0),
                        source="coingecko_batch",
                    )
        except Exception as e:
            logger.error(f"Batch price fetch failed: {e}")

        return result

    # ── OHLCV Data ──────────────────────────────────────────────

    def get_ohlcv(self, symbol: str, days: int = 30, max_age: float = 300) -> list[dict]:
        """
        Get OHLCV data for technical analysis.
        Caches for 5 minutes by default.
        """
        symbol = symbol.upper()
        cache_key = f"{symbol}_{days}d"

        # Check cache
        cached_time = self._ohlcv_cache_time.get(cache_key, 0)
        if time.time() - cached_time < max_age and cache_key in self._ohlcv_cache:
            self._cache_hits += 1
            return [vars(bar) for bar in self._ohlcv_cache[cache_key]]

        # Fetch from CoinGecko
        cg_id = CG_MAP.get(symbol, symbol.lower())

        if self.rate_limiter and not self.rate_limiter.check("coingecko"):
            cached = self._ohlcv_cache.get(cache_key, [])
            return [vars(bar) for bar in cached]

        try:
            self._request_count += 1
            r = requests.get(
                f"https://api.coingecko.com/api/v3/coins/{cg_id}/ohlc",
                params={"vs_currency": "usd", "days": days},
                timeout=15,
            )
            data = r.json()

            bars = []
            for row in data:
                if len(row) >= 5:
                    bars.append(OHLCVBar(
                        timestamp=row[0] / 1000,
                        open=row[1],
                        high=row[2],
                        low=row[3],
                        close=row[4],
                    ))

            self._ohlcv_cache[cache_key] = bars
            self._ohlcv_cache_time[cache_key] = time.time()
            return [vars(bar) for bar in bars]

        except Exception as e:
            logger.error(f"OHLCV fetch failed for {symbol}: {e}")
            cached = self._ohlcv_cache.get(cache_key, [])
            return [vars(bar) for bar in cached]

    # ── Stock Data via yfinance ─────────────────────────────────

    def get_stock_price(self, symbol: str) -> Optional[PriceData]:
        """Fetch stock price via Yahoo Finance."""
        cached = self._price_cache.get(symbol)
        if cached and not cached.is_stale(60):  # Stocks update slower
            self._cache_hits += 1
            return cached

        try:
            self._request_count += 1
            import yfinance as yf
            ticker = yf.Ticker(symbol)
            info = ticker.fast_info
            price_data = PriceData(
                symbol=symbol,
                price=info.get("lastPrice", 0) or info.get("regularMarketPrice", 0),
                change_24h=info.get("regularMarketChangePercent", 0),
                volume_24h=info.get("regularMarketVolume", 0),
                market_cap=info.get("marketCap", 0),
                source="yfinance",
            )
            self._price_cache[symbol] = price_data
            return price_data
        except Exception as e:
            logger.error(f"Stock price fetch failed for {symbol}: {e}")
            return None

    # ── Analytics ───────────────────────────────────────────────

    def get_stats(self) -> dict:
        """Get pipeline statistics."""
        total = self._request_count + self._cache_hits
        return {
            "api_requests": self._request_count,
            "cache_hits": self._cache_hits,
            "cache_hit_rate": f"{self._cache_hits / max(total, 1):.0%}",
            "cached_prices": len(self._price_cache),
            "cached_ohlcv": len(self._ohlcv_cache),
            "savings_estimate": f"~{self._cache_hits} API calls saved",
        }

    def get_market_overview(self, symbols: list[str] = None) -> str:
        """Quick market overview for agents."""
        if not symbols:
            symbols = ["BTC", "ETH", "SOL", "SPY"]

        prices = self.get_prices_batch(symbols)
        lines = []
        for sym, data in prices.items():
            icon = "🟢" if data.change_24h >= 0 else "🔴"
            lines.append(
                f"{icon} {sym}: ${data.price:,.2f} ({data.change_24h:+.2f}%)"
            )
        return "\n".join(lines) if lines else "No price data available"

    def get_telegram_summary(self) -> str:
        stats = self.get_stats()
        return (
            f"👄 *Data Pipeline*\n\n"
            f"API calls: {stats['api_requests']}\n"
            f"Cache hits: {stats['cache_hits']} ({stats['cache_hit_rate']})\n"
            f"Cached prices: {stats['cached_prices']}\n"
            f"Cached OHLCV: {stats['cached_ohlcv']}\n"
            f"Estimated savings: {stats['savings_estimate']}"
        )

    def flush_cache(self):
        """Clear all caches."""
        self._price_cache.clear()
        self._ohlcv_cache.clear()
        self._ohlcv_cache_time.clear()
        logger.info("Data pipeline cache flushed")
