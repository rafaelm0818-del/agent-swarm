"""
Learning System - The Cerebellum

Learns from past performance and feeds insights back to every agent.
This is the feedback loop that turns experience into edge.

What it learns:
  1. Strategy Fingerprinting - categorize strategies by type, what worked/failed
  2. Signal Quality Scoring - track which screener signals led to profitable trades
  3. Regime-Strategy Mapping - which strategy types work in which regimes
  4. Agent Performance - which agents make the best decisions
  5. Mistake Patterns - detect repeated failures and warn research
  6. Time-of-Day Analysis - when do signals perform best
  7. Correlation Lessons - which asset pairs move together in practice

How it works:
  - Reads from database (trades, strategies, signals, audit_log)
  - Generates structured "lessons" (JSON)
  - These lessons get injected into agent prompts as context
  - Agents that receive lessons produce better decisions over time

This is NOT ML/neural nets. It's structured statistical analysis 
that generates human-readable insights for Claude to reason about.
"""
import json
import time
import logging
import math
from datetime import datetime, timezone, timedelta
from typing import Optional
from database.models import Database

logger = logging.getLogger("LearningSystem")


class LearningSystem:
    """
    Analyzes historical performance and generates actionable lessons
    that get injected into agent prompts.
    """

    def __init__(self, db: Database):
        self.db = db
        self._lessons_cache: dict = {}
        self._cache_ttl = 3600  # Refresh lessons every hour
        self._last_refresh = 0

    def get_lessons(self, force_refresh: bool = False) -> dict:
        """
        Get all current lessons. Returns cached version unless stale.
        """
        if force_refresh or time.time() - self._last_refresh > self._cache_ttl:
            self._refresh_lessons()
        return self._lessons_cache

    def _refresh_lessons(self):
        """Recompute all lessons from database."""
        logger.info("Refreshing learning system lessons...")
        self._lessons_cache = {
            "strategy_lessons": self._learn_strategy_patterns(),
            "signal_quality": self._learn_signal_quality(),
            "regime_lessons": self._learn_regime_patterns(),
            "timing_lessons": self._learn_timing_patterns(),
            "mistake_patterns": self._learn_mistake_patterns(),
            "asset_lessons": self._learn_asset_patterns(),
            "agent_performance": self._learn_agent_performance(),
            "exit_tuning": self.compute_exit_tuning(),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        self._last_refresh = time.time()
        logger.info(f"Lessons refreshed: {len(self._lessons_cache)} categories")

    # ── Strategy Pattern Learning ───────────────────────────────

    def _learn_strategy_patterns(self) -> dict:
        """What types of strategies work and which don't?"""
        strategies = self.db.get_strategies(limit=200)
        if not strategies:
            return {"lesson": "No strategy history yet. Need more data."}

        # Categorize by outcome
        winners = [s for s in strategies if s.get("live_pnl", 0) > 0 and s.get("status") in ("live", "retired")]
        losers = [s for s in strategies if s.get("live_pnl", 0) < 0 and s.get("status") in ("live", "retired")]
        rejected = [s for s in strategies if s.get("status") == "rejected"]

        # Find common traits in winners vs losers
        winner_traits = self._extract_traits(winners)
        loser_traits = self._extract_traits(losers)
        rejected_traits = self._extract_traits(rejected)

        # Sharpe distribution
        sharpes = [s.get("sharpe_ratio", 0) for s in strategies if s.get("sharpe_ratio")]
        avg_sharpe = sum(sharpes) / len(sharpes) if sharpes else 0

        return {
            "total_strategies": len(strategies),
            "winners": len(winners),
            "losers": len(losers),
            "rejected": len(rejected),
            "win_rate": len(winners) / max(len(winners) + len(losers), 1),
            "avg_sharpe": round(avg_sharpe, 2),
            "winning_traits": winner_traits,
            "losing_traits": loser_traits,
            "rejected_traits": rejected_traits,
            "lesson": self._generate_strategy_lesson(winners, losers, rejected),
        }

    def _extract_traits(self, strategies: list) -> dict:
        """Extract common traits from a group of strategies."""
        if not strategies:
            return {}

        timeframes = {}
        assets = {}
        regimes = {}

        for s in strategies:
            tf = s.get("timeframe", "unknown")
            timeframes[tf] = timeframes.get(tf, 0) + 1

            for asset in s.get("assets", []):
                assets[asset] = assets.get(asset, 0) + 1

            regime = s.get("market_regime", "unknown")
            if regime:
                regimes[regime] = regimes.get(regime, 0) + 1

        return {
            "common_timeframes": sorted(timeframes.items(), key=lambda x: -x[1])[:3],
            "common_assets": sorted(assets.items(), key=lambda x: -x[1])[:5],
            "common_regimes": sorted(regimes.items(), key=lambda x: -x[1])[:3],
            "avg_win_rate": round(
                sum(s.get("win_rate", 0) for s in strategies) / len(strategies), 3
            ),
            "avg_profit_factor": round(
                sum(s.get("profit_factor", 0) for s in strategies) / len(strategies), 2
            ),
        }

    def _generate_strategy_lesson(self, winners, losers, rejected) -> str:
        """Generate human-readable strategy lesson."""
        parts = []

        if winners:
            w_tfs = [s.get("timeframe", "?") for s in winners]
            most_common_tf = max(set(w_tfs), key=w_tfs.count) if w_tfs else "unknown"
            avg_sharpe = sum(s.get("sharpe_ratio", 0) for s in winners) / len(winners)
            parts.append(
                f"Winning strategies tend to use {most_common_tf} timeframe "
                f"with avg Sharpe {avg_sharpe:.2f}."
            )

        if losers:
            l_tfs = [s.get("timeframe", "?") for s in losers]
            most_common_bad_tf = max(set(l_tfs), key=l_tfs.count) if l_tfs else "unknown"
            parts.append(
                f"Losing strategies often use {most_common_bad_tf} timeframe. "
                f"Consider avoiding or adding extra filters."
            )

        if rejected and len(rejected) > 3:
            parts.append(
                f"{len(rejected)} strategies were rejected by risk. "
                f"Common issue: insufficient backtest quality."
            )

        if len(winners) + len(losers) < 5:
            parts.append("Not enough completed strategies for reliable patterns yet.")

        return " ".join(parts) if parts else "Gathering data..."

    # ── Signal Quality Learning ─────────────────────────────────

    def _learn_signal_quality(self) -> dict:
        """Which screener signals actually lead to profits?"""
        signals = self.db.get_signals(hours=168 * 4)  # Last 4 weeks
        trades = self.db.get_trades(limit=500)

        if not signals:
            return {"lesson": "No signal history yet."}

        # Match signals to trade outcomes
        trade_by_signal = {}
        for t in trades:
            sid = t.get("signal_id", "")
            if sid:
                trade_by_signal[sid] = t

        # Score signal types
        signal_scores = {}
        for sig in signals:
            sig_type = sig.get("signal_type", "unknown")
            if sig_type not in signal_scores:
                signal_scores[sig_type] = {
                    "total": 0, "traded": 0, "profitable": 0, "total_pnl": 0,
                    "avg_confidence": 0, "avg_strength": 0,
                }
            scores = signal_scores[sig_type]
            scores["total"] += 1
            scores["avg_confidence"] += sig.get("confidence", 0)
            scores["avg_strength"] += sig.get("strength", 0)

            sig_id = sig.get("signal_id", "")
            if sig_id in trade_by_signal:
                trade = trade_by_signal[sig_id]
                scores["traded"] += 1
                pnl = trade.get("pnl", 0) or 0
                scores["total_pnl"] += pnl
                if pnl > 0:
                    scores["profitable"] += 1

        # Calculate averages and rankings
        for sig_type, scores in signal_scores.items():
            if scores["total"] > 0:
                scores["avg_confidence"] = round(scores["avg_confidence"] / scores["total"], 3)
                scores["avg_strength"] = round(scores["avg_strength"] / scores["total"], 3)
                scores["trade_rate"] = round(scores["traded"] / scores["total"], 3)
                if scores["traded"] > 0:
                    scores["win_rate"] = round(scores["profitable"] / scores["traded"], 3)
                    scores["avg_pnl"] = round(scores["total_pnl"] / scores["traded"], 2)

        # Rank by profitability
        ranked = sorted(
            signal_scores.items(),
            key=lambda x: x[1].get("total_pnl", 0),
            reverse=True
        )

        best = ranked[0] if ranked else ("none", {})
        worst = ranked[-1] if len(ranked) > 1 else ("none", {})

        return {
            "by_type": signal_scores,
            "best_signal_type": best[0],
            "worst_signal_type": worst[0],
            "total_signals": len(signals),
            "lesson": (
                f"Best signal type: '{best[0]}' with ${best[1].get('total_pnl', 0):+,.2f} total P&L. "
                f"Worst: '{worst[0]}' with ${worst[1].get('total_pnl', 0):+,.2f}. "
                f"Prioritize {best[0]} signals and add extra confirmation for {worst[0]}."
                if len(ranked) > 1 else "Need more signal-to-trade data."
            ),
        }

    # ── Regime Pattern Learning ─────────────────────────────────

    def _learn_regime_patterns(self) -> dict:
        """Which strategies work in which market regimes?"""
        strategies = self.db.get_strategies(limit=200)
        if not strategies:
            return {"lesson": "No regime data yet."}

        regime_perf = {}
        for s in strategies:
            regime = s.get("market_regime", "unknown")
            if not regime:
                continue
            if regime not in regime_perf:
                regime_perf[regime] = {"strategies": 0, "winners": 0, "total_pnl": 0}
            regime_perf[regime]["strategies"] += 1
            pnl = s.get("live_pnl", 0)
            regime_perf[regime]["total_pnl"] += pnl
            if pnl > 0:
                regime_perf[regime]["winners"] += 1

        for regime, data in regime_perf.items():
            if data["strategies"] > 0:
                data["win_rate"] = round(data["winners"] / data["strategies"], 3)

        return {
            "by_regime": regime_perf,
            "lesson": self._generate_regime_lesson(regime_perf),
        }

    def _generate_regime_lesson(self, regime_perf: dict) -> str:
        if not regime_perf:
            return "No regime performance data yet."

        best_regime = max(regime_perf.items(), key=lambda x: x[1].get("total_pnl", 0))
        worst_regime = min(regime_perf.items(), key=lambda x: x[1].get("total_pnl", 0))

        return (
            f"Best performing regime: '{best_regime[0]}' "
            f"(${best_regime[1]['total_pnl']:+,.2f}, "
            f"{best_regime[1].get('win_rate', 0):.0%} win rate). "
            f"Worst: '{worst_regime[0]}' "
            f"(${worst_regime[1]['total_pnl']:+,.2f}). "
            f"Size up in {best_regime[0]} regimes, reduce exposure in {worst_regime[0]}."
        )

    # ── Timing Patterns ─────────────────────────────────────────

    def _learn_timing_patterns(self) -> dict:
        """When do trades perform best?"""
        trades = self.db.get_trades(status="closed", limit=500)
        if len(trades) < 10:
            return {"lesson": "Not enough closed trades for timing analysis."}

        by_hour = {}
        by_day = {}
        for t in trades:
            opened = t.get("opened_at", "")
            if not opened:
                continue
            try:
                dt = datetime.fromisoformat(opened.replace("Z", "+00:00"))
                hour = dt.hour
                day = dt.strftime("%A")

                for bucket, key in [(by_hour, hour), (by_day, day)]:
                    if key not in bucket:
                        bucket[key] = {"count": 0, "total_pnl": 0, "winners": 0}
                    bucket[key]["count"] += 1
                    pnl = t.get("pnl", 0) or 0
                    bucket[key]["total_pnl"] += pnl
                    if pnl > 0:
                        bucket[key]["winners"] += 1
            except (ValueError, AttributeError):
                continue

        best_hour = max(by_hour.items(), key=lambda x: x[1]["total_pnl"]) if by_hour else None
        worst_hour = min(by_hour.items(), key=lambda x: x[1]["total_pnl"]) if by_hour else None
        best_day = max(by_day.items(), key=lambda x: x[1]["total_pnl"]) if by_day else None

        return {
            "by_hour": {k: v for k, v in sorted(by_hour.items())},
            "by_day": by_day,
            "best_hour": best_hour[0] if best_hour else None,
            "worst_hour": worst_hour[0] if worst_hour else None,
            "best_day": best_day[0] if best_day else None,
            "lesson": (
                f"Best trading hour: {best_hour[0]}:00 UTC (${best_hour[1]['total_pnl']:+,.2f}). "
                f"Worst: {worst_hour[0]}:00 UTC (${worst_hour[1]['total_pnl']:+,.2f}). "
                f"Best day: {best_day[0]}."
                if best_hour and worst_hour and best_day
                else "Gathering timing data..."
            ),
        }

    # ── Mistake Patterns ────────────────────────────────────────

    def _learn_mistake_patterns(self) -> dict:
        """Detect repeated failures and patterns to avoid."""
        trades = self.db.get_trades(status="closed", limit=500)
        audit = self.db.get_audit_log(limit=200)

        mistakes = []

        # Pattern 1: Consecutive losses
        consecutive_losses = 0
        max_consecutive = 0
        for t in sorted(trades, key=lambda x: x.get("opened_at", "")):
            if (t.get("pnl", 0) or 0) < 0:
                consecutive_losses += 1
                max_consecutive = max(max_consecutive, consecutive_losses)
            else:
                consecutive_losses = 0

        if max_consecutive >= 5:
            mistakes.append({
                "type": "loss_streak",
                "severity": "high",
                "detail": f"Max consecutive losses: {max_consecutive}. Consider reducing position size after 3 consecutive losses.",
            })

        # Pattern 2: Stop loss hit rate
        stop_losses = [t for t in trades if t.get("metadata", {}).get("close_reason") == "stop_loss"
                       or "stop_loss" in str(t.get("metadata", {}))]
        if trades and len(stop_losses) / max(len(trades), 1) > 0.5:
            mistakes.append({
                "type": "high_stop_rate",
                "severity": "high",
                "detail": f"{len(stop_losses)}/{len(trades)} trades hit stop loss ({len(stop_losses)/len(trades):.0%}). Stops may be too tight or entries too early.",
            })

        # Pattern 3: Large single losses
        big_losses = [t for t in trades if (t.get("pnl", 0) or 0) < -100]
        if big_losses:
            worst = min(big_losses, key=lambda t: t.get("pnl", 0))
            mistakes.append({
                "type": "outsized_loss",
                "severity": "medium",
                "detail": f"{len(big_losses)} trades lost >$100. Worst: ${worst.get('pnl', 0):,.2f} on {worst.get('symbol', '?')}. Review position sizing.",
            })

        # Pattern 4: Rejected strategies repeating
        rejected_audit = [a for a in audit if a.get("action") == "strategy_rejected"]
        if len(rejected_audit) > 5:
            reasons = [a.get("details", "") for a in rejected_audit]
            mistakes.append({
                "type": "repeated_rejections",
                "severity": "medium",
                "detail": f"{len(rejected_audit)} strategies rejected. Research agent may be proposing similar low-quality setups.",
            })

        return {
            "patterns": mistakes,
            "max_consecutive_losses": max_consecutive,
            "total_mistakes": len(mistakes),
            "lesson": " | ".join(m["detail"] for m in mistakes) if mistakes else "No significant mistake patterns detected yet.",
        }

    # ── Asset Pattern Learning ──────────────────────────────────

    def _learn_asset_patterns(self) -> dict:
        """Which assets are we best at trading?"""
        trades = self.db.get_trades(status="closed", limit=500)
        if not trades:
            return {"lesson": "No closed trades for asset analysis."}

        by_asset = {}
        for t in trades:
            symbol = t.get("symbol", "?")
            if symbol not in by_asset:
                by_asset[symbol] = {"trades": 0, "winners": 0, "total_pnl": 0, "total_fees": 0}
            by_asset[symbol]["trades"] += 1
            pnl = t.get("pnl", 0) or 0
            by_asset[symbol]["total_pnl"] += pnl
            by_asset[symbol]["total_fees"] += t.get("fees", 0) or 0
            if pnl > 0:
                by_asset[symbol]["winners"] += 1

        for symbol, data in by_asset.items():
            if data["trades"] > 0:
                data["win_rate"] = round(data["winners"] / data["trades"], 3)
                data["avg_pnl"] = round(data["total_pnl"] / data["trades"], 2)

        ranked = sorted(by_asset.items(), key=lambda x: x[1]["total_pnl"], reverse=True)

        return {
            "by_asset": by_asset,
            "best_asset": ranked[0][0] if ranked else None,
            "worst_asset": ranked[-1][0] if len(ranked) > 1 else None,
            "lesson": (
                f"Best asset: {ranked[0][0]} (${ranked[0][1]['total_pnl']:+,.2f}, "
                f"{ranked[0][1].get('win_rate', 0):.0%} WR). "
                + (f"Worst: {ranked[-1][0]} (${ranked[-1][1]['total_pnl']:+,.2f}). "
                   f"Consider increasing {ranked[0][0]} allocation and reviewing {ranked[-1][0]} setups."
                   if len(ranked) > 1 else "")
            ) if ranked else "Need more trade data.",
        }

    # ── Agent Performance ───────────────────────────────────────

    def _learn_agent_performance(self) -> dict:
        """Which agents are making the best decisions?"""
        audit = self.db.get_audit_log(limit=500)
        if not audit:
            return {"lesson": "No audit data yet."}

        by_agent = {}
        for entry in audit:
            agent = entry.get("agent", "unknown")
            if agent not in by_agent:
                by_agent[agent] = {"actions": 0, "action_types": {}}
            by_agent[agent]["actions"] += 1
            action = entry.get("action", "unknown")
            by_agent[agent]["action_types"][action] = by_agent[agent]["action_types"].get(action, 0) + 1

        return {
            "by_agent": by_agent,
            "most_active": max(by_agent.items(), key=lambda x: x[1]["actions"])[0] if by_agent else None,
            "lesson": "Agent activity tracked. Correlate with trade outcomes for decision quality scoring.",
        }

    # ── Prompt Injection ────────────────────────────────────────

    def get_research_context(self) -> str:
        """Generate context to inject into the research agent's prompt."""
        lessons = self.get_lessons()
        
        parts = ["=== LEARNING SYSTEM INSIGHTS ===\n"]

        # Strategy lessons
        sl = lessons.get("strategy_lessons", {})
        if sl.get("lesson"):
            parts.append(f"STRATEGY PATTERNS: {sl['lesson']}")
            if sl.get("win_rate"):
                parts.append(f"Historical strategy win rate: {sl['win_rate']:.0%}")

        # Signal quality
        sq = lessons.get("signal_quality", {})
        if sq.get("lesson"):
            parts.append(f"\nSIGNAL QUALITY: {sq['lesson']}")

        # Regime
        rl = lessons.get("regime_lessons", {})
        if rl.get("lesson"):
            parts.append(f"\nREGIME INSIGHTS: {rl['lesson']}")

        # Mistakes
        mp = lessons.get("mistake_patterns", {})
        if mp.get("lesson") and mp.get("total_mistakes", 0) > 0:
            parts.append(f"\n⚠️ MISTAKES TO AVOID: {mp['lesson']}")

        # Timing
        tl = lessons.get("timing_lessons", {})
        if tl.get("lesson"):
            parts.append(f"\nTIMING: {tl['lesson']}")

        # Assets
        al = lessons.get("asset_lessons", {})
        if al.get("lesson"):
            parts.append(f"\nASSET PERFORMANCE: {al['lesson']}")

        parts.append("\nUse these insights to improve strategy proposals. Avoid repeating past mistakes.")
        return "\n".join(parts)

    def get_risk_context(self) -> str:
        """Context for the risk agent."""
        lessons = self.get_lessons()
        mp = lessons.get("mistake_patterns", {})
        sl = lessons.get("strategy_lessons", {})

        parts = ["=== RISK CONTEXT FROM LEARNING SYSTEM ===\n"]
        if mp.get("patterns"):
            for m in mp["patterns"]:
                parts.append(f"⚠️ [{m['severity'].upper()}] {m['detail']}")
        if sl.get("avg_sharpe"):
            parts.append(f"\nHistorical avg Sharpe: {sl['avg_sharpe']}")
        return "\n".join(parts)

    def get_screener_context(self) -> str:
        """Context for the screener about signal quality."""
        lessons = self.get_lessons()
        sq = lessons.get("signal_quality", {})

        if not sq.get("by_type"):
            return ""

        parts = ["=== SIGNAL QUALITY FEEDBACK ===\n"]
        for sig_type, data in sq.get("by_type", {}).items():
            if data.get("traded", 0) > 0:
                parts.append(
                    f"{sig_type}: {data.get('win_rate', 0):.0%} win rate, "
                    f"${data.get('avg_pnl', 0):+,.2f} avg P&L, "
                    f"{data['traded']} trades"
                )
        parts.append("\nPrioritize signal types with higher win rates.")
        return "\n".join(parts)

    def get_telegram_summary(self) -> str:
        """Telegram-friendly learning summary."""
        lessons = self.get_lessons()
        sl = lessons.get("strategy_lessons", {})
        sq = lessons.get("signal_quality", {})
        mp = lessons.get("mistake_patterns", {})

        lines = ["📚 *Learning System*\n"]

        if sl.get("total_strategies", 0) > 0:
            lines.append(
                f"Strategies: {sl['total_strategies']} total | "
                f"{sl.get('winners', 0)} won | {sl.get('losers', 0)} lost | "
                f"{sl.get('win_rate', 0):.0%} WR"
            )

        if sq.get("best_signal_type"):
            lines.append(f"Best signal: {sq['best_signal_type']}")

        if mp.get("total_mistakes", 0) > 0:
            lines.append(f"⚠️ Mistakes detected: {mp['total_mistakes']}")
            for m in mp.get("patterns", [])[:3]:
                lines.append(f"  • {m['detail'][:80]}")

        al = lessons.get("asset_lessons", {})
        if al.get("best_asset"):
            lines.append(f"Best asset: {al['best_asset']}")

        return "\n".join(lines) if len(lines) > 1 else "📚 Learning system: gathering data..."

    # ── Self-Tuning Exit Config (Profit Progression) ───────────

    def compute_exit_tuning(self, execution_engine=None) -> dict:
        """
        Analyze closed trades per asset and compute optimal exit config.
        
        Classifies each asset as "trending" (hold longer) or "reverting" (exit faster)
        based on observed trade behavior. Updates the execution engine's exit configs.
        
        Stress test results: BTC → REVERTING (take profits fast), TSLA → TRENDING (let it run)
        """
        trades = self.db.get_trades(status="closed", limit=500)
        if not trades or len(trades) < 10:
            return {"lesson": "Need more closed trades for self-tuning."}
        
        tuning_results = {}
        
        # Group trades by asset
        by_asset = {}
        for t in trades:
            sym = t.get("symbol", "?")
            if sym not in by_asset:
                by_asset[sym] = []
            by_asset[sym].append(t)
        
        for sym, asset_trades in by_asset.items():
            if len(asset_trades) < 3:
                continue
            
            # Analyze trade characteristics
            winners = [t for t in asset_trades if (t.get("pnl", 0) or 0) > 0]
            losers = [t for t in asset_trades if (t.get("pnl", 0) or 0) < 0]
            
            # Exit reason breakdown
            tp_trades = [t for t in asset_trades if t.get("metadata", {}).get("reason") in ("take_profit", "trail_stop")]
            sl_trades = [t for t in asset_trades if t.get("metadata", {}).get("reason") in ("stop_loss",)]
            partial_trades = [t for t in asset_trades if t.get("metadata", {}).get("partial")]
            
            win_rate = len(winners) / len(asset_trades) if asset_trades else 0
            
            # Compute average duration (if available in metadata)
            durations = [
                t.get("metadata", {}).get("duration", 0)
                for t in asset_trades if t.get("metadata", {}).get("duration")
            ]
            avg_duration = sum(durations) / len(durations) if durations else 5
            
            # Classification logic (from stress test cerebellum)
            config = {
                "trail_mult": 1.5,
                "breakeven_at": 1.0,
                "partial_at": 1.5,
                "partial_pct": 0.50,
                "extend_tp": True,
                "behavior": "neutral",
            }
            
            reasoning = []
            
            if len(tp_trades) > len(sl_trades) and avg_duration > 4:
                # Asset trends well — widen trail, let it run
                config["behavior"] = "trending"
                config["trail_mult"] = min(2.5, 1.5 + 0.3)
                config["partial_pct"] = max(0.30, 0.50 - 0.10)
                reasoning.append(f"TRENDING: {len(tp_trades)} TP > {len(sl_trades)} SL, avg dur {avg_duration:.1f}")
            
            elif (len(sl_trades) > len(tp_trades) * 1.5) and avg_duration < 3:
                # Asset mean-reverts — tighten trail, take profits faster
                config["behavior"] = "reverting"
                config["trail_mult"] = max(0.8, 1.5 - 0.3)
                config["partial_pct"] = min(0.70, 0.50 + 0.10)
                config["breakeven_at"] = max(0.5, 1.0 - 0.2)
                reasoning.append(f"REVERTING: {len(sl_trades)} SL >> {len(tp_trades)} TP, avg dur {avg_duration:.1f}")
            
            # Check for "profits left on table" pattern
            peak_data = [
                t for t in asset_trades
                if t.get("metadata", {}).get("peak_pnl_pct", 0) > 3
                and (t.get("pnl_pct", 0) or 0) < t.get("metadata", {}).get("peak_pnl_pct", 0) * 0.3
            ]
            if len(peak_data) >= 2:
                config["trail_mult"] = max(0.8, config["trail_mult"] - 0.2)
                reasoning.append(f"LEFT PROFIT: {len(peak_data)} trades peaked high then reversed → tightened trail")
            
            tuning_results[sym] = {
                "config": config,
                "trades": len(asset_trades),
                "win_rate": round(win_rate, 3),
                "reasoning": "; ".join(reasoning) if reasoning else "neutral (default config)",
            }
            
            # Apply to execution engine if provided
            if execution_engine and reasoning:
                execution_engine.update_exit_config(sym, config)
                logger.info(f"🧬 SELF-TUNE {sym}: {'; '.join(reasoning)}")
        
        return {
            "tuning": tuning_results,
            "assets_tuned": len([r for r in tuning_results.values() if r.get("reasoning") != "neutral (default config)"]),
            "total_assets": len(tuning_results),
            "lesson": self._generate_tuning_summary(tuning_results),
        }
    
    def _generate_tuning_summary(self, results: dict) -> str:
        """Human-readable summary of tuning decisions."""
        trending = [s for s, r in results.items() if r["config"]["behavior"] == "trending"]
        reverting = [s for s, r in results.items() if r["config"]["behavior"] == "reverting"]
        
        parts = []
        if trending:
            parts.append(f"Trending (hold longer): {', '.join(trending)}")
        if reverting:
            parts.append(f"Reverting (exit faster): {', '.join(reverting)}")
        if not parts:
            parts.append("All assets at default config — need more trade data")
        
        return " | ".join(parts)
