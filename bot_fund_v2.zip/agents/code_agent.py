"""
Code Writing & Deployment Agent

Capabilities:
- Write Python/JS/bash scripts
- Execute and test code
- Read/write files in workspace
- Run shell commands for deployment
- Git operations
"""
import os
import subprocess
from agents.base_agent import BaseAgent
from config.settings import settings


class CodeAgent(BaseAgent):

    def __init__(self):
        super().__init__()
        os.makedirs(settings.CODE_WORKSPACE_DIR, exist_ok=True)

    @property
    def name(self) -> str:
        return "code"

    @property
    def description(self) -> str:
        return (
            "Writes, tests, and deploys code. Handles Python scripts, "
            "shell commands, file operations, git, and deployment tasks."
        )

    @property
    def system_prompt(self) -> str:
        return f"""You are a senior software engineer agent. You can:
- Write code in Python, JavaScript, Bash, and other languages
- Execute code and shell commands
- Read and write files in the workspace at {settings.CODE_WORKSPACE_DIR}
- Run git commands
- Deploy services

When given a coding task:
1. Plan your approach briefly
2. Write the code using the write_file tool
3. Test it using run_code or run_shell
4. Fix any issues
5. Report the result

Write clean, production-grade code with error handling.
Format responses for Telegram - be concise, show key code snippets inline.
Always confirm what files were created/modified."""

    def get_tools(self) -> list[dict]:
        return [
            {
                "name": "write_file",
                "description": "Create or overwrite a file in the workspace.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "filename": {
                            "type": "string",
                            "description": "Filename (relative to workspace dir)"
                        },
                        "content": {
                            "type": "string",
                            "description": "File content"
                        }
                    },
                    "required": ["filename", "content"]
                }
            },
            {
                "name": "read_file",
                "description": "Read a file from the workspace.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "filename": {
                            "type": "string",
                            "description": "Filename (relative to workspace dir)"
                        }
                    },
                    "required": ["filename"]
                }
            },
            {
                "name": "run_code",
                "description": "Execute Python code directly.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "code": {
                            "type": "string",
                            "description": "Python code to execute"
                        }
                    },
                    "required": ["code"]
                }
            },
            {
                "name": "run_shell",
                "description": "Execute a shell command in the workspace directory.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "Shell command to run"
                        }
                    },
                    "required": ["command"]
                }
            },
            {
                "name": "list_files",
                "description": "List files in the workspace or a subdirectory.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Subdirectory path (relative to workspace). Empty for root.",
                            "default": ""
                        }
                    }
                }
            },
        ]

    def handle_tool_call(self, tool_name: str, tool_input: dict):
        if tool_name == "write_file":
            return self._write_file(tool_input["filename"], tool_input["content"])
        elif tool_name == "read_file":
            return self._read_file(tool_input["filename"])
        elif tool_name == "run_code":
            return self._run_code(tool_input["code"])
        elif tool_name == "run_shell":
            return self._run_shell(tool_input["command"])
        elif tool_name == "list_files":
            return self._list_files(tool_input.get("path", ""))
        else:
            raise ValueError(f"Unknown tool: {tool_name}")

    def _write_file(self, filename: str, content: str) -> str:
        filepath = os.path.join(settings.CODE_WORKSPACE_DIR, filename)
        os.makedirs(os.path.dirname(filepath) if os.path.dirname(filepath) else settings.CODE_WORKSPACE_DIR, exist_ok=True)
        with open(filepath, "w") as f:
            f.write(content)
        return f"Written {len(content)} bytes to {filename}"

    def _read_file(self, filename: str) -> str:
        filepath = os.path.join(settings.CODE_WORKSPACE_DIR, filename)
        if not os.path.exists(filepath):
            return f"Error: {filename} not found"
        with open(filepath, "r") as f:
            content = f.read()
        if len(content) > 10000:
            return content[:10000] + f"\n... (truncated, {len(content)} bytes total)"
        return content

    def _run_code(self, code: str) -> str:
        try:
            result = subprocess.run(
                ["python3", "-c", code],
                capture_output=True, text=True,
                timeout=120,
                cwd=settings.CODE_WORKSPACE_DIR
            )
            output = result.stdout.strip()
            if result.returncode != 0:
                output += f"\nSTDERR: {result.stderr.strip()}"
            return output if output else "(no output)"
        except subprocess.TimeoutExpired:
            return "Error: Execution timed out (120s limit)"

    def _run_shell(self, command: str) -> str:
        # Security: block obviously dangerous commands
        blocked = ["rm -rf /", "mkfs", "dd if=", ":(){", "fork bomb"]
        if any(b in command.lower() for b in blocked):
            return "Error: Command blocked for safety"
        try:
            result = subprocess.run(
                command, shell=True,
                capture_output=True, text=True,
                timeout=120,
                cwd=settings.CODE_WORKSPACE_DIR
            )
            output = result.stdout.strip()
            if result.returncode != 0:
                output += f"\nSTDERR: {result.stderr.strip()}"
            return output[:5000] if output else "(no output)"
        except subprocess.TimeoutExpired:
            return "Error: Command timed out (120s limit)"

    def _list_files(self, path: str) -> str:
        target = os.path.join(settings.CODE_WORKSPACE_DIR, path)
        if not os.path.exists(target):
            return f"Path not found: {path}"
        try:
            result = subprocess.run(
                ["find", ".", "-maxdepth", "3", "-type", "f"],
                capture_output=True, text=True,
                cwd=target
            )
            return result.stdout.strip() if result.stdout.strip() else "(empty directory)"
        except Exception as e:
            return f"Error: {str(e)}"
