"""
Watchlist Manager Agent

The central nervous system for what the fund pays attention to.
Every other agent can recommend adds/removes, and the Watchlist Manager
makes the final decision based on scoring, capacity, and market context.

Supported Markets:
  - Crypto (spot only, no futures)
  - US Stocks
  - Forex
  - Commodities
  - ETFs

NOT supported (for now):
  - Futures
  - Options
  - Derivatives

Features:
  - Multi-market watchlists with per-asset metadata
  - Priority scoring (higher score = more attention from screener)
  - Auto-add from agent recommendations (screener, research, trading)
  - Auto-remove stale/underperforming assets
  - Capacity limits per market (don't spread too thin)
  - Reason tracking (why was this added? by whom?)
  - Expiry system (assets can have a TTL before auto-review)
  - Tags for grouping (momentum, mean_reversion, earnings_play, etc.)
"""
import json
import time
import logging
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum
from agents.base_agent import BaseAgent

logger = logging.getLogger("WatchlistManager")


class Market(str, Enum):
    CRYPTO = "crypto"
    STOCKS = "stocks"
    FOREX = "forex"
    COMMODITIES = "commodities"
    ETF = "etf"


# Assets that are BLOCKED
BLOCKED_MARKETS = {"futures", "options", "derivatives", "perps", "perpetuals"}


@dataclass
class WatchlistAsset:
    """A single asset on the watchlist with full metadata."""
    symbol: str
    market: Market
    
    # Scoring & priority
    priority_score: float = 0.5       # 0.0 - 1.0, higher = more screener attention
    
    # Why it's here
    added_by: str = ""                # Which agent added it
    add_reason: str = ""              # Why it was added
    source_signal_id: str = ""        # If added from a screener signal
    
    # Tags for grouping
    tags: list[str] = field(default_factory=list)   # momentum, breakout, earnings, etc.
    
    # Asset metadata
    sector: str = ""                  # Tech, DeFi, Energy, etc.
    market_cap_tier: str = ""         # large, mid, small, micro
    avg_daily_volume: float = 0.0
    current_price: float = 0.0
    
    # Lifecycle
    added_at: float = field(default_factory=time.time)
    last_updated: float = field(default_factory=time.time)
    expires_at: float = 0.0           # 0 = no expiry
    review_at: float = 0.0            # When to re-evaluate
    
    # Performance tracking (while on watchlist)
    price_at_add: float = 0.0
    signals_generated: int = 0
    strategies_spawned: int = 0
    
    # Change history
    change_log: list[dict] = field(default_factory=list)
    
    # Status
    active: bool = True
    paused: bool = False              # Temporarily stop scanning
    
    def log_change(self, agent: str, action: str, details: str = ""):
        self.change_log.append({
            "timestamp": time.time(),
            "agent": agent,
            "action": action,
            "details": details,
        })
        self.last_updated = time.time()

    def to_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "market": self.market.value,
            "priority_score": self.priority_score,
            "added_by": self.added_by,
            "add_reason": self.add_reason,
            "tags": self.tags,
            "sector": self.sector,
            "active": self.active,
            "paused": self.paused,
            "signals_generated": self.signals_generated,
            "strategies_spawned": self.strategies_spawned,
            "age_hours": round((time.time() - self.added_at) / 3600, 1),
        }

    def to_telegram(self) -> str:
        market_icons = {
            Market.CRYPTO: "₿", Market.STOCKS: "📈",
            Market.FOREX: "💱", Market.COMMODITIES: "🛢️", Market.ETF: "📦",
        }
        icon = market_icons.get(self.market, "📊")
        status = "🟢" if self.active and not self.paused else "⏸️" if self.paused else "🔴"
        score_bar = "█" * int(self.priority_score * 5) + "░" * (5 - int(self.priority_score * 5))
        return (
            f"{status} {icon} *{self.symbol}* ({self.market.value})\n"
            f"Priority: [{score_bar}] {self.priority_score:.0%}\n"
            f"Added by: {self.added_by} | {self.add_reason[:60]}\n"
            f"Tags: {', '.join(self.tags) if self.tags else 'none'}\n"
            f"Signals: {self.signals_generated} | Strategies: {self.strategies_spawned}"
        )


@dataclass
class WatchlistConfig:
    """Capacity and rules for the watchlist."""
    # Max assets per market (don't spread too thin)
    max_crypto: int = 20
    max_stocks: int = 15
    max_forex: int = 8
    max_commodities: int = 6
    max_etf: int = 8
    
    # Total max across all markets
    max_total: int = 50
    
    # Auto-cleanup rules
    stale_days: int = 14              # Review assets with no signals after X days
    min_priority_to_keep: float = 0.2 # Below this, auto-remove on cleanup
    auto_cleanup_enabled: bool = True
    
    # Default TTL for different add sources
    default_ttl_hours: dict = field(default_factory=lambda: {
        "screener": 48,       # Screener adds expire after 48h unless renewed
        "research": 168,      # Research adds last 7 days
        "trading": 72,        # Trading agent adds last 3 days
        "human": 0,           # Manual adds never expire
        "watchlist_manager": 96,  # Self-managed adds last 4 days
    })

    def max_for_market(self, market: Market) -> int:
        return {
            Market.CRYPTO: self.max_crypto,
            Market.STOCKS: self.max_stocks,
            Market.FOREX: self.max_forex,
            Market.COMMODITIES: self.max_commodities,
            Market.ETF: self.max_etf,
        }.get(market, 10)


class WatchlistManagerAgent(BaseAgent):
    """
    Manages dynamic watchlists across all markets.
    
    Other agents interact with this through:
    1. Direct tool calls (add/remove/edit)
    2. Event bus recommendations (auto-processed)
    3. The fund manager's orchestration loop
    
    The screener reads from this watchlist instead of its own static one.
    """

    def __init__(self, config: WatchlistConfig = None):
        super().__init__()
        self.config = config or WatchlistConfig()
        self.watchlist: dict[str, WatchlistAsset] = {}
        self._recommendation_queue: list[dict] = []
        
        # Seed with common assets
        self._seed_defaults()

    def _seed_defaults(self):
        """Start with a sensible default watchlist."""
        defaults = [
            ("BTC", Market.CRYPTO, 0.9, ["large_cap", "benchmark"]),
            ("ETH", Market.CRYPTO, 0.9, ["large_cap", "smart_contracts"]),
            ("SOL", Market.CRYPTO, 0.8, ["large_cap", "high_throughput"]),
            ("XRP", Market.CRYPTO, 0.6, ["large_cap", "payments"]),
            ("LINK", Market.CRYPTO, 0.6, ["mid_cap", "oracle"]),
            ("AVAX", Market.CRYPTO, 0.5, ["mid_cap", "l1"]),
            ("SPY", Market.ETF, 0.7, ["benchmark", "sp500"]),
            ("QQQ", Market.ETF, 0.7, ["benchmark", "nasdaq"]),
            ("AAPL", Market.STOCKS, 0.5, ["large_cap", "tech"]),
            ("NVDA", Market.STOCKS, 0.6, ["large_cap", "ai", "semiconductors"]),
            ("GLD", Market.COMMODITIES, 0.5, ["safe_haven", "gold"]),
            ("EUR/USD", Market.FOREX, 0.4, ["major_pair"]),
        ]
        for symbol, market, priority, tags in defaults:
            key = f"{market.value}:{symbol}"
            self.watchlist[key] = WatchlistAsset(
                symbol=symbol,
                market=market,
                priority_score=priority,
                added_by="system",
                add_reason="Default seed",
                tags=tags,
            )

    @property
    def name(self) -> str:
        return "watchlist_manager"

    @property
    def description(self) -> str:
        return (
            "Manages dynamic watchlists across crypto, stocks, forex, commodities, "
            "and ETFs (no futures). Adds, edits, removes assets based on agent "
            "recommendations. Tracks priority scoring, tags, and lifecycle. "
            "The screener and all other agents read from this watchlist."
        )

    @property
    def system_prompt(self) -> str:
        return f"""You are the Watchlist Manager for an autonomous hedge fund.

You manage what assets the fund pays attention to across ALL markets:
- Crypto (spot only, NO futures/perps)
- US Stocks
- Forex pairs
- Commodities
- ETFs

Current watchlist has {len(self.watchlist)} assets.
Capacity limits: {self.config.max_crypto} crypto, {self.config.max_stocks} stocks, {self.config.max_forex} forex, {self.config.max_commodities} commodities, {self.config.max_etf} ETFs. Max total: {self.config.max_total}.

IMPORTANT RULES:
1. NEVER add futures, options, perpetuals, or derivatives
2. Every add must have a clear reason and appropriate tags
3. Set priority_score based on opportunity quality (0.0-1.0)
4. Higher priority = screener scans it more frequently
5. Remove assets that haven't generated signals in {self.config.stale_days} days
6. Don't add duplicates
7. Respect capacity limits per market - if full, must remove lowest priority first

When processing recommendations from other agents:
- Validate the asset exists and is in a supported market
- Check for duplicates
- If at capacity, compare priority score to lowest on the list
- Set appropriate TTL based on the source agent

You have tools to add, edit, remove, list, and search the watchlist.
Always explain your reasoning for watchlist changes."""

    def get_tools(self) -> list[dict]:
        return [
            {
                "name": "add_asset",
                "description": "Add an asset to the watchlist.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "symbol": {
                            "type": "string",
                            "description": "Asset symbol (e.g., BTC, AAPL, EUR/USD, GLD)"
                        },
                        "market": {
                            "type": "string",
                            "enum": ["crypto", "stocks", "forex", "commodities", "etf"],
                            "description": "Which market this asset belongs to"
                        },
                        "priority_score": {
                            "type": "number",
                            "description": "Priority 0.0-1.0 (higher = more screener attention)"
                        },
                        "reason": {
                            "type": "string",
                            "description": "Why this asset should be watched"
                        },
                        "tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Tags for grouping (e.g., momentum, breakout, earnings)"
                        },
                        "sector": {
                            "type": "string",
                            "description": "Sector (Tech, DeFi, Energy, etc.)"
                        },
                        "ttl_hours": {
                            "type": "number",
                            "description": "Hours until this expires (0 = never)"
                        },
                        "source_agent": {
                            "type": "string",
                            "description": "Which agent recommended this"
                        }
                    },
                    "required": ["symbol", "market", "priority_score", "reason"]
                }
            },
            {
                "name": "remove_asset",
                "description": "Remove an asset from the watchlist.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "symbol": {
                            "type": "string",
                            "description": "Asset symbol"
                        },
                        "market": {
                            "type": "string",
                            "enum": ["crypto", "stocks", "forex", "commodities", "etf"],
                            "description": "Market"
                        },
                        "reason": {
                            "type": "string",
                            "description": "Why removing"
                        }
                    },
                    "required": ["symbol", "market", "reason"]
                }
            },
            {
                "name": "edit_asset",
                "description": "Edit an existing asset's properties (priority, tags, pause/unpause).",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "symbol": {
                            "type": "string",
                            "description": "Asset symbol"
                        },
                        "market": {
                            "type": "string",
                            "enum": ["crypto", "stocks", "forex", "commodities", "etf"]
                        },
                        "priority_score": {
                            "type": "number",
                            "description": "New priority (0.0-1.0)"
                        },
                        "tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Replace tags"
                        },
                        "add_tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Add tags (keeps existing)"
                        },
                        "remove_tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Remove specific tags"
                        },
                        "paused": {
                            "type": "boolean",
                            "description": "Pause/unpause scanning"
                        },
                        "reason": {
                            "type": "string",
                            "description": "Reason for edit"
                        }
                    },
                    "required": ["symbol", "market"]
                }
            },
            {
                "name": "list_watchlist",
                "description": "List assets on the watchlist with optional filters.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "market": {
                            "type": "string",
                            "enum": ["crypto", "stocks", "forex", "commodities", "etf", "all"],
                            "description": "Filter by market (default: all)"
                        },
                        "tag": {
                            "type": "string",
                            "description": "Filter by tag"
                        },
                        "min_priority": {
                            "type": "number",
                            "description": "Min priority score filter"
                        },
                        "sort_by": {
                            "type": "string",
                            "enum": ["priority", "age", "signals", "symbol"],
                            "description": "Sort order"
                        },
                        "active_only": {
                            "type": "boolean",
                            "description": "Only show active assets",
                            "default": True
                        }
                    }
                }
            },
            {
                "name": "search_new_assets",
                "description": "Search for potential new assets to add to the watchlist. Uses web/API search.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query (e.g., 'trending crypto by volume', 'tech stocks near 52w high')"
                        },
                        "market": {
                            "type": "string",
                            "enum": ["crypto", "stocks", "forex", "commodities", "etf"],
                            "description": "Which market to search in"
                        }
                    },
                    "required": ["query", "market"]
                }
            },
            {
                "name": "run_cleanup",
                "description": "Run watchlist cleanup: remove expired assets, flag stale ones, rebalance priorities.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "dry_run": {
                            "type": "boolean",
                            "description": "If true, report what would change without actually changing",
                            "default": True
                        }
                    }
                }
            },
            {
                "name": "get_stats",
                "description": "Get watchlist statistics and health metrics.",
                "input_schema": {
                    "type": "object",
                    "properties": {}
                }
            },
            {
                "name": "process_recommendation",
                "description": "Process a recommendation from another agent to add/edit/remove an asset.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["add", "boost", "reduce", "remove"],
                            "description": "Recommended action"
                        },
                        "symbol": {"type": "string"},
                        "market": {
                            "type": "string",
                            "enum": ["crypto", "stocks", "forex", "commodities", "etf"]
                        },
                        "from_agent": {
                            "type": "string",
                            "description": "Which agent is making this recommendation"
                        },
                        "reason": {"type": "string"},
                        "priority_suggestion": {
                            "type": "number",
                            "description": "Suggested priority score"
                        },
                        "tags": {
                            "type": "array",
                            "items": {"type": "string"}
                        }
                    },
                    "required": ["action", "symbol", "market", "from_agent", "reason"]
                }
            },
        ]

    def handle_tool_call(self, tool_name: str, tool_input: dict):
        handlers = {
            "add_asset": self._add_asset,
            "remove_asset": self._remove_asset,
            "edit_asset": self._edit_asset,
            "list_watchlist": self._list_watchlist,
            "search_new_assets": self._search_new_assets,
            "run_cleanup": self._run_cleanup,
            "get_stats": self._get_stats,
            "process_recommendation": self._process_recommendation,
        }
        handler = handlers.get(tool_name)
        if not handler:
            raise ValueError(f"Unknown tool: {tool_name}")
        return handler(tool_input)

    # ── Core Operations ─────────────────────────────────────────

    def _add_asset(self, params: dict) -> str:
        symbol = params["symbol"].upper()
        market_str = params["market"].lower()
        
        # Block futures/derivatives
        if market_str in BLOCKED_MARKETS:
            return json.dumps({
                "success": False, 
                "error": f"Market '{market_str}' is blocked. No futures/options/derivatives."
            })

        try:
            market = Market(market_str)
        except ValueError:
            return json.dumps({"success": False, "error": f"Unknown market: {market_str}"})

        key = f"{market.value}:{symbol}"
        
        # Check duplicate
        if key in self.watchlist and self.watchlist[key].active:
            return json.dumps({
                "success": False,
                "error": f"{symbol} already on {market.value} watchlist",
                "existing": self.watchlist[key].to_dict()
            })

        # Check capacity
        market_count = sum(
            1 for a in self.watchlist.values() 
            if a.market == market and a.active
        )
        max_cap = self.config.max_for_market(market)
        
        if market_count >= max_cap:
            # Find lowest priority to potentially replace
            lowest = min(
                (a for a in self.watchlist.values() if a.market == market and a.active),
                key=lambda a: a.priority_score,
                default=None
            )
            new_priority = params.get("priority_score", 0.5)
            
            if lowest and new_priority > lowest.priority_score:
                # Auto-replace lowest priority
                lowest.active = False
                lowest.log_change("watchlist_manager", "removed_for_capacity",
                    f"Replaced by {symbol} (priority {new_priority:.2f} > {lowest.priority_score:.2f})")
                replaced_msg = f"Replaced {lowest.symbol} (priority {lowest.priority_score:.2f})"
            else:
                return json.dumps({
                    "success": False,
                    "error": f"{market.value} watchlist full ({market_count}/{max_cap}). "
                             f"Lowest priority is {lowest.symbol} at {lowest.priority_score:.2f}. "
                             f"New asset needs higher priority to replace it.",
                })

        # Check total capacity
        total_active = sum(1 for a in self.watchlist.values() if a.active)
        if total_active >= self.config.max_total:
            return json.dumps({
                "success": False,
                "error": f"Total watchlist full ({total_active}/{self.config.max_total})"
            })

        # Calculate TTL
        source = params.get("source_agent", "watchlist_manager")
        ttl_hours = params.get("ttl_hours", self.config.default_ttl_hours.get(source, 72))
        expires_at = time.time() + ttl_hours * 3600 if ttl_hours > 0 else 0

        # Create asset
        asset = WatchlistAsset(
            symbol=symbol,
            market=market,
            priority_score=min(1.0, max(0.0, params.get("priority_score", 0.5))),
            added_by=params.get("source_agent", "watchlist_manager"),
            add_reason=params.get("reason", ""),
            tags=params.get("tags", []),
            sector=params.get("sector", ""),
            expires_at=expires_at,
            review_at=time.time() + self.config.stale_days * 86400,
        )
        asset.log_change(source, "added", params.get("reason", ""))
        self.watchlist[key] = asset

        return json.dumps({
            "success": True,
            "added": asset.to_dict(),
            "market_usage": f"{market_count + 1}/{max_cap}",
            "total_usage": f"{total_active + 1}/{self.config.max_total}",
        })

    def _remove_asset(self, params: dict) -> str:
        symbol = params["symbol"].upper()
        market = params["market"].lower()
        key = f"{market}:{symbol}"

        if key not in self.watchlist:
            return json.dumps({"success": False, "error": f"{symbol} not found on {market} watchlist"})

        asset = self.watchlist[key]
        asset.active = False
        asset.log_change("watchlist_manager", "removed", params.get("reason", ""))

        return json.dumps({
            "success": True,
            "removed": symbol,
            "market": market,
            "was_priority": asset.priority_score,
            "had_signals": asset.signals_generated,
        })

    def _edit_asset(self, params: dict) -> str:
        symbol = params["symbol"].upper()
        market = params["market"].lower()
        key = f"{market}:{symbol}"

        if key not in self.watchlist:
            return json.dumps({"success": False, "error": f"{symbol} not found"})

        asset = self.watchlist[key]
        changes = []

        if "priority_score" in params:
            old = asset.priority_score
            asset.priority_score = min(1.0, max(0.0, params["priority_score"]))
            changes.append(f"priority: {old:.2f} → {asset.priority_score:.2f}")

        if "tags" in params:
            asset.tags = params["tags"]
            changes.append(f"tags replaced: {asset.tags}")

        if "add_tags" in params:
            for tag in params["add_tags"]:
                if tag not in asset.tags:
                    asset.tags.append(tag)
            changes.append(f"tags added: {params['add_tags']}")

        if "remove_tags" in params:
            asset.tags = [t for t in asset.tags if t not in params["remove_tags"]]
            changes.append(f"tags removed: {params['remove_tags']}")

        if "paused" in params:
            asset.paused = params["paused"]
            changes.append(f"paused: {asset.paused}")

        reason = params.get("reason", "; ".join(changes))
        asset.log_change("watchlist_manager", "edited", reason)

        return json.dumps({
            "success": True,
            "updated": asset.to_dict(),
            "changes": changes,
        })

    def _list_watchlist(self, params: dict) -> str:
        market_filter = params.get("market", "all")
        tag_filter = params.get("tag")
        min_priority = params.get("min_priority", 0.0)
        sort_by = params.get("sort_by", "priority")
        active_only = params.get("active_only", True)

        assets = list(self.watchlist.values())

        # Apply filters
        if active_only:
            assets = [a for a in assets if a.active]
        if market_filter != "all":
            assets = [a for a in assets if a.market.value == market_filter]
        if tag_filter:
            assets = [a for a in assets if tag_filter in a.tags]
        if min_priority > 0:
            assets = [a for a in assets if a.priority_score >= min_priority]

        # Sort
        sort_keys = {
            "priority": lambda a: -a.priority_score,
            "age": lambda a: a.added_at,
            "signals": lambda a: -a.signals_generated,
            "symbol": lambda a: a.symbol,
        }
        assets.sort(key=sort_keys.get(sort_by, sort_keys["priority"]))

        return json.dumps({
            "count": len(assets),
            "assets": [a.to_dict() for a in assets[:50]],
        })

    def _search_new_assets(self, params: dict) -> str:
        """Search for new assets to potentially add. Uses subprocess for API calls."""
        import subprocess
        query = params["query"]
        market = params["market"]

        if market == "crypto":
            code = f"""
import requests, json
r = requests.get(
    'https://api.coingecko.com/api/v3/search/trending',
    timeout=10
)
data = r.json()
coins = data.get('coins', [])
results = []
for c in coins[:15]:
    item = c.get('item', {{}})
    results.append({{
        'symbol': item.get('symbol', '').upper(),
        'name': item.get('name', ''),
        'market_cap_rank': item.get('market_cap_rank', 999),
        'price_btc': item.get('price_btc', 0),
    }})
print(json.dumps(results, indent=2))
"""
        elif market == "stocks":
            code = f"""
import requests, json
# Use Yahoo Finance trending
headers = {{'User-Agent': 'Mozilla/5.0'}}
r = requests.get(
    'https://query1.finance.yahoo.com/v1/finance/trending/US',
    headers=headers, timeout=10
)
data = r.json()
quotes = data.get('finance', {{}}).get('result', [{{}}])[0].get('quotes', [])
results = [{{'symbol': q.get('symbol', '')}} for q in quotes[:15]]
print(json.dumps(results, indent=2))
"""
        else:
            return json.dumps({"results": [], "note": f"Search for {market} requires manual input"})

        try:
            result = subprocess.run(
                ["python3", "-c", code],
                capture_output=True, text=True, timeout=15
            )
            return result.stdout.strip() if result.stdout.strip() else f"STDERR: {result.stderr.strip()}"
        except Exception as e:
            return json.dumps({"error": str(e)})

    def _run_cleanup(self, params: dict) -> str:
        """Clean up expired and stale assets."""
        dry_run = params.get("dry_run", True)
        now = time.time()
        actions = []

        for key, asset in self.watchlist.items():
            if not asset.active:
                continue

            # Check expired
            if asset.expires_at > 0 and now > asset.expires_at:
                actions.append({
                    "action": "expire",
                    "symbol": asset.symbol,
                    "market": asset.market.value,
                    "reason": f"TTL expired (was set by {asset.added_by})",
                })
                if not dry_run:
                    asset.active = False
                    asset.log_change("watchlist_manager", "expired", "TTL reached")

            # Check stale (no signals in stale_days)
            elif asset.signals_generated == 0 and (now - asset.added_at) > self.config.stale_days * 86400:
                if asset.priority_score < self.config.min_priority_to_keep:
                    actions.append({
                        "action": "remove_stale",
                        "symbol": asset.symbol,
                        "market": asset.market.value,
                        "reason": f"No signals in {self.config.stale_days} days, priority {asset.priority_score:.2f} below threshold",
                    })
                    if not dry_run:
                        asset.active = False
                        asset.log_change("watchlist_manager", "removed_stale", "No signals, low priority")
                else:
                    actions.append({
                        "action": "flag_review",
                        "symbol": asset.symbol,
                        "market": asset.market.value,
                        "reason": f"No signals in {self.config.stale_days} days but priority {asset.priority_score:.2f} keeps it",
                    })

        return json.dumps({
            "dry_run": dry_run,
            "actions": actions,
            "total_changes": len(actions),
        })

    def _get_stats(self, _params: dict = None) -> str:
        """Get watchlist statistics."""
        active = [a for a in self.watchlist.values() if a.active]
        
        by_market = {}
        for a in active:
            m = a.market.value
            by_market.setdefault(m, {"count": 0, "avg_priority": 0, "total_signals": 0})
            by_market[m]["count"] += 1
            by_market[m]["avg_priority"] += a.priority_score
            by_market[m]["total_signals"] += a.signals_generated
        
        for m in by_market:
            if by_market[m]["count"] > 0:
                by_market[m]["avg_priority"] = round(
                    by_market[m]["avg_priority"] / by_market[m]["count"], 2
                )
            by_market[m]["capacity"] = self.config.max_for_market(Market(m))

        return json.dumps({
            "total_active": len(active),
            "total_capacity": self.config.max_total,
            "by_market": by_market,
            "top_priority": [a.to_dict() for a in sorted(active, key=lambda x: -x.priority_score)[:5]],
            "most_signals": [a.to_dict() for a in sorted(active, key=lambda x: -x.signals_generated)[:5]],
        })

    def _process_recommendation(self, params: dict) -> str:
        """Process a recommendation from another agent."""
        action = params["action"]
        symbol = params["symbol"].upper()
        market = params["market"].lower()
        from_agent = params["from_agent"]
        reason = params.get("reason", "")

        if market in BLOCKED_MARKETS:
            return json.dumps({
                "success": False,
                "error": f"Cannot process recommendation for blocked market: {market}"
            })

        key = f"{market}:{symbol}"

        if action == "add":
            return self._add_asset({
                "symbol": symbol,
                "market": market,
                "priority_score": params.get("priority_suggestion", 0.6),
                "reason": f"[{from_agent}] {reason}",
                "tags": params.get("tags", []),
                "source_agent": from_agent,
            })

        elif action == "boost":
            if key in self.watchlist and self.watchlist[key].active:
                asset = self.watchlist[key]
                old_priority = asset.priority_score
                boost = min(0.2, params.get("priority_suggestion", old_priority + 0.15) - old_priority)
                asset.priority_score = min(1.0, old_priority + max(0.05, boost))
                asset.log_change(from_agent, "boosted", f"{reason} ({old_priority:.2f} → {asset.priority_score:.2f})")
                return json.dumps({"success": True, "boosted": asset.to_dict()})
            else:
                # Not on list yet, add it
                return self._add_asset({
                    "symbol": symbol,
                    "market": market,
                    "priority_score": params.get("priority_suggestion", 0.6),
                    "reason": f"[{from_agent}] {reason}",
                    "tags": params.get("tags", []),
                    "source_agent": from_agent,
                })

        elif action == "reduce":
            if key in self.watchlist and self.watchlist[key].active:
                asset = self.watchlist[key]
                old_priority = asset.priority_score
                asset.priority_score = max(0.0, old_priority - 0.15)
                asset.log_change(from_agent, "reduced", f"{reason} ({old_priority:.2f} → {asset.priority_score:.2f})")
                return json.dumps({"success": True, "reduced": asset.to_dict()})
            return json.dumps({"success": False, "error": "Not on watchlist"})

        elif action == "remove":
            return self._remove_asset({
                "symbol": symbol,
                "market": market,
                "reason": f"[{from_agent}] {reason}",
            })

        return json.dumps({"success": False, "error": f"Unknown action: {action}"})

    # ── Public API for other agents ─────────────────────────────

    def get_active_symbols(self, market: Optional[str] = None) -> list[str]:
        """Get list of active symbols for the screener to scan."""
        assets = [a for a in self.watchlist.values() if a.active and not a.paused]
        if market:
            assets = [a for a in assets if a.market.value == market]
        # Sort by priority so screener scans highest priority first
        assets.sort(key=lambda a: -a.priority_score)
        return [a.symbol for a in assets]

    def get_active_assets(self, market: Optional[str] = None) -> list[WatchlistAsset]:
        """Get full asset objects for detailed queries."""
        assets = [a for a in self.watchlist.values() if a.active and not a.paused]
        if market:
            assets = [a for a in assets if a.market.value == market]
        assets.sort(key=lambda a: -a.priority_score)
        return assets

    def record_signal(self, symbol: str, market: str):
        """Called by screener when a signal is generated for this asset."""
        key = f"{market}:{symbol.upper()}"
        if key in self.watchlist:
            self.watchlist[key].signals_generated += 1
            self.watchlist[key].last_updated = time.time()
            # Extend expiry when signals are generated (asset is proving useful)
            if self.watchlist[key].expires_at > 0:
                self.watchlist[key].expires_at = max(
                    self.watchlist[key].expires_at,
                    time.time() + 48 * 3600  # Extend by at least 48h
                )

    def record_strategy_spawned(self, symbol: str, market: str):
        """Called when a strategy is created for this asset."""
        key = f"{market}:{symbol.upper()}"
        if key in self.watchlist:
            self.watchlist[key].strategies_spawned += 1

    def get_telegram_summary(self) -> str:
        """Generate a Telegram-friendly watchlist summary."""
        active = [a for a in self.watchlist.values() if a.active]
        if not active:
            return "📋 Watchlist is empty."

        lines = [f"📋 *Watchlist* ({len(active)}/{self.config.max_total})\n"]

        for market in Market:
            market_assets = sorted(
                [a for a in active if a.market == market],
                key=lambda a: -a.priority_score
            )
            if not market_assets:
                continue
            
            market_icons = {
                Market.CRYPTO: "₿", Market.STOCKS: "📈",
                Market.FOREX: "💱", Market.COMMODITIES: "🛢️", Market.ETF: "📦",
            }
            icon = market_icons.get(market, "📊")
            max_cap = self.config.max_for_market(market)
            lines.append(f"{icon} *{market.value.upper()}* ({len(market_assets)}/{max_cap})")
            
            for a in market_assets:
                status = "⏸️" if a.paused else ""
                score = "█" * int(a.priority_score * 5) + "░" * (5 - int(a.priority_score * 5))
                lines.append(f"  {status}{a.symbol} [{score}] sig:{a.signals_generated}")
            lines.append("")

        return "\n".join(lines)
