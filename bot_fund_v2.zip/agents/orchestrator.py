"""
Orchestrator Agent

Routes incoming tasks to the appropriate specialized agent.
Can also chain agents for multi-step tasks.
"""
import json
import anthropic
from agents.base_agent import AgentResult
from agents.trading_agent import TradingAgent
from agents.code_agent import CodeAgent
from agents.scraper_agent import ScraperAgent
from config.settings import settings


class Orchestrator:
    """
    Routes tasks to specialized agents using Claude as the router.
    Also handles multi-step tasks that require multiple agents.
    """

    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.agents = {
            "trading": TradingAgent(),
            "code": CodeAgent(),
            "scraper": ScraperAgent(),
        }
        self.task_history: list[dict] = []

    def _get_agent_descriptions(self) -> str:
        lines = []
        for key, agent in self.agents.items():
            lines.append(f"- **{key}**: {agent.description}")
        return "\n".join(lines)

    async def route_and_execute(self, user_message: str) -> str:
        """
        Main entry point. Routes a user message to the right agent(s)
        and returns the final response.
        """
        # Step 1: Use Claude to determine routing
        routing = self._determine_routing(user_message)

        if not routing["steps"]:
            return "I couldn't determine which agent should handle this. Try being more specific about what you need."

        # Step 2: Execute each step
        results = []
        context_from_previous = ""

        for step in routing["steps"]:
            agent_key = step["agent"]
            task = step["task"]

            if agent_key not in self.agents:
                results.append(f"⚠️ Unknown agent: {agent_key}")
                continue

            agent = self.agents[agent_key]

            # If this step builds on previous results, inject context
            full_task = task
            if context_from_previous:
                full_task = f"Previous step results:\n{context_from_previous}\n\nYour task: {task}"

            # Execute
            result = await agent.run(full_task)

            # Reset agent conversation for next task
            agent.reset()

            icon = "✅" if result.success else "❌"
            header = f"{icon} **{agent.name.upper()} Agent** ({result.elapsed_seconds:.1f}s, {result.tokens_used} tokens)"
            results.append(f"{header}\n{result.response}")

            # Pass results forward for chaining
            context_from_previous = result.response

        # Store in history
        self.task_history.append({
            "input": user_message,
            "routing": routing,
            "results": [r for r in results]
        })

        return "\n\n---\n\n".join(results)

    def _determine_routing(self, user_message: str) -> dict:
        """Use Claude to decide which agent(s) to use and in what order."""

        routing_prompt = f"""You are a task router for a multi-agent system. Given a user request, determine which agent(s) should handle it and in what order.

Available agents:
{self._get_agent_descriptions()}

Respond with a JSON object containing a "steps" array. Each step has:
- "agent": one of {list(self.agents.keys())}
- "task": the specific sub-task for that agent (rewritten to be clear and actionable)

Rules:
- Most tasks need only ONE agent. Only use multiple if the task genuinely requires chaining.
- If a task needs web data first, then analysis, use scraper -> trading.
- If a task needs code written based on research, use scraper/trading -> code.
- Keep sub-tasks focused and specific.

Examples:
User: "What's the price of BTC?" -> {{"steps": [{{"agent": "trading", "task": "Fetch the current price of Bitcoin and include 24h change"}}]}}
User: "Scrape the top posts from r/cryptocurrency and analyze sentiment" -> {{"steps": [{{"agent": "scraper", "task": "Scrape the top 20 post titles from r/cryptocurrency"}}, {{"agent": "trading", "task": "Analyze the sentiment of these Reddit posts and identify any notable trends or tokens being discussed"}}]}}
User: "Write a Python script that monitors ETH price" -> {{"steps": [{{"agent": "code", "task": "Write a Python script that monitors ETH price using CoinGecko API, checking every 60 seconds and printing alerts on significant moves"}}]}}

Respond with ONLY the JSON, no other text."""

        try:
            response = self.client.messages.create(
                model=settings.MODEL,
                max_tokens=500,
                messages=[{"role": "user", "content": f"{routing_prompt}\n\nUser request: {user_message}"}]
            )

            text = response.content[0].text.strip()
            # Clean up potential markdown wrapping
            if text.startswith("```"):
                text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()

            return json.loads(text)

        except Exception as e:
            # Fallback: try to route based on keywords
            return self._keyword_fallback(user_message)

    def _keyword_fallback(self, message: str) -> dict:
        """Simple keyword-based routing as fallback."""
        msg_lower = message.lower()

        if any(kw in msg_lower for kw in ["price", "market", "trade", "stock", "crypto", "btc", "eth", "backtest", "signal", "analysis"]):
            return {"steps": [{"agent": "trading", "task": message}]}
        elif any(kw in msg_lower for kw in ["scrape", "fetch", "download", "crawl", "extract", "website", "url", "http"]):
            return {"steps": [{"agent": "scraper", "task": message}]}
        elif any(kw in msg_lower for kw in ["write", "code", "script", "deploy", "build", "create", "function", "class", "git"]):
            return {"steps": [{"agent": "code", "task": message}]}
        else:
            # Default to trading agent for general queries
            return {"steps": [{"agent": "trading", "task": message}]}
