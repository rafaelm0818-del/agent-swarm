"""
Base Agent - Claude API with tool use loop.
All specialized agents inherit from this.
"""
import json
import time
import anthropic
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable
from config.settings import settings


@dataclass
class AgentResult:
    """Result from an agent execution."""
    success: bool
    response: str
    data: dict = field(default_factory=dict)
    tokens_used: int = 0
    elapsed_seconds: float = 0.0
    agent_name: str = ""


class BaseAgent(ABC):
    """
    Base agent with Claude API tool-use loop.
    
    Each agent defines:
      - name / description
      - system prompt
      - tools (Claude API format)
      - tool handlers (actual Python functions)
    """

    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.conversation_history: list[dict] = []
        self.max_tool_rounds = 10  # prevent infinite loops

    @property
    @abstractmethod
    def name(self) -> str:
        """Agent name for routing."""
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        """What this agent does (used by orchestrator for routing)."""
        ...

    @property
    @abstractmethod
    def system_prompt(self) -> str:
        """System prompt for this agent."""
        ...

    @abstractmethod
    def get_tools(self) -> list[dict]:
        """Return Claude API tool definitions."""
        ...

    @abstractmethod
    def handle_tool_call(self, tool_name: str, tool_input: dict) -> Any:
        """Execute a tool call and return the result."""
        ...

    def reset(self):
        """Clear conversation history."""
        self.conversation_history = []

    async def run(self, task: str) -> AgentResult:
        """
        Execute a task using Claude with tool-use loop.
        Runs synchronously (Claude SDK), wrapped for async compatibility.
        """
        start = time.time()
        total_tokens = 0

        # Add user task to conversation
        self.conversation_history.append({
            "role": "user",
            "content": task
        })

        tools = self.get_tools()

        for round_num in range(self.max_tool_rounds):
            try:
                response = self.client.messages.create(
                    model=settings.MODEL,
                    max_tokens=settings.MAX_TOKENS,
                    system=self.system_prompt,
                    tools=tools if tools else anthropic.NOT_GIVEN,
                    messages=self.conversation_history
                )
            except Exception as e:
                return AgentResult(
                    success=False,
                    response=f"API error: {str(e)}",
                    agent_name=self.name,
                    elapsed_seconds=time.time() - start,
                    tokens_used=total_tokens
                )

            total_tokens += response.usage.input_tokens + response.usage.output_tokens

            # If Claude is done (no more tool calls), extract final text
            if response.stop_reason == "end_turn":
                final_text = self._extract_text(response.content)
                self.conversation_history.append({
                    "role": "assistant",
                    "content": response.content
                })
                return AgentResult(
                    success=True,
                    response=final_text,
                    agent_name=self.name,
                    elapsed_seconds=time.time() - start,
                    tokens_used=total_tokens
                )

            # Claude wants to use tools
            if response.stop_reason == "tool_use":
                # Add assistant message with tool calls
                self.conversation_history.append({
                    "role": "assistant",
                    "content": response.content
                })

                # Process each tool call
                tool_results = []
                for block in response.content:
                    if block.type == "tool_use":
                        try:
                            result = self.handle_tool_call(block.name, block.input)
                            tool_results.append({
                                "type": "tool_result",
                                "tool_use_id": block.id,
                                "content": json.dumps(result) if not isinstance(result, str) else result
                            })
                        except Exception as e:
                            tool_results.append({
                                "type": "tool_result",
                                "tool_use_id": block.id,
                                "content": f"Tool error: {str(e)}",
                                "is_error": True
                            })

                # Add tool results to conversation
                self.conversation_history.append({
                    "role": "user",
                    "content": tool_results
                })

        # Hit max rounds
        return AgentResult(
            success=False,
            response="Agent hit maximum tool-use rounds without completing.",
            agent_name=self.name,
            elapsed_seconds=time.time() - start,
            tokens_used=total_tokens
        )

    def _extract_text(self, content_blocks) -> str:
        """Extract text from Claude response content blocks."""
        texts = []
        for block in content_blocks:
            if hasattr(block, "text"):
                texts.append(block.text)
        return "\n".join(texts) if texts else "(No text response)"
