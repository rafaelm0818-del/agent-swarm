"""
Signal Intelligence Engine — Pre-Trade Filter & Enhancement Layer

This module sits between the Screener (EYES) and the Execution Engine (GUT).
It transforms raw signals into trade-ready decisions by applying:

  Steroid D: Signal Stacking — 2+ signal types on same asset = confidence boost
  Steroid E: Multi-Timeframe Alignment — short + medium trends must agree
  Steroid F: Mean-Reversion Mode — fade overextended moves in RANGING regime
  
  Pre-Trade Filters:
  - Counter-trend filter: Don't buy in bearish regime, don't short in bullish
  - Signal persistence: Require 2+ consecutive signals before acting
  - Correlation blocking: Check open positions for correlated duplicate exposure

Stress Test Results (these filters + enhancements):
  - Win rate: 45.5% → 58.0%
  - Scenarios profitable: 5/6
  - Flash Crash: -$277 → +$152 (regime-capped ATR + filters)
  - Markets active: 2 → 4 (market-calibrated thresholds unlock non-crypto)

Architecture:
  Screener → [Signal Intelligence] → Execution Engine
                 ↕                        ↕
            Learning System          Profit Progression
"""

import time
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("SignalIntelligence")


# ═══════════════════════════════════════════════════════════════
#  Data Structures
# ═══════════════════════════════════════════════════════════════

@dataclass
class EnhancedSignal:
    """A signal that has been processed through the intelligence layer."""
    # Original signal data
    signal_id: str
    asset: str
    direction: str              # "bullish" or "bearish"
    signal_type: str            # Original primary signal type
    confidence: float           # Enhanced confidence (may be boosted or penalized)
    price: float
    timestamp: float
    
    # Enhancement metadata
    original_confidence: float = 0.0
    stacked: bool = False           # True if 2+ signal types confirmed
    stacked_types: list = field(default_factory=list)  # Which signal types agreed
    timeframe_aligned: bool = True  # True if short/medium trends agree
    timeframe_penalty: float = 0.0  # Confidence penalty from misalignment
    is_mean_reversion: bool = False # True if this is a fade-the-move signal
    
    # Filter results
    passed_all_filters: bool = True
    filter_blocked_by: str = ""     # Which filter blocked it (if any)
    persistence_count: int = 0      # How many consecutive signals for this asset
    
    # Learning hints (for cerebellum)
    suggested_behavior: str = ""    # "trending" or "reverting" hint based on context


@dataclass
class SignalIntelligenceStats:
    """Aggregate stats for reporting."""
    signals_received: int = 0
    signals_passed: int = 0
    signals_blocked: int = 0
    blocked_counter_trend: int = 0
    blocked_persistence: int = 0
    blocked_correlation: int = 0
    stacked_signals: int = 0
    mean_reversion_signals: int = 0
    timeframe_penalties: int = 0
    avg_confidence_boost: float = 0.0


# ═══════════════════════════════════════════════════════════════
#  Signal Intelligence Engine
# ═══════════════════════════════════════════════════════════════

class SignalIntelligenceEngine:
    """
    Pre-trade filter and signal enhancement layer.
    
    Usage:
        intel = SignalIntelligenceEngine()
        
        # Process a batch of raw signals from screener
        enhanced = intel.process_signals(
            raw_signals=screener_signals,
            regime=current_regime,
            open_positions=engine.positions,
            price_histories=price_data,
        )
        
        # Only trade the ones that passed all filters
        tradeable = [s for s in enhanced if s.passed_all_filters]
    """
    
    def __init__(self):
        self.stats = SignalIntelligenceStats()
        self._signal_history: dict[str, list] = {}  # asset → list of recent signal timestamps+directions
        self._last_reset = time.time()
    
    def process_signals(
        self,
        raw_signals: list[dict],
        regime: str = "RANGING",
        open_positions: Optional[dict] = None,
        price_histories: Optional[dict] = None,
        exit_configs: Optional[dict] = None,
    ) -> list[EnhancedSignal]:
        """
        Process a batch of raw screener signals through all filters and enhancements.
        
        Args:
            raw_signals: List of dicts with keys: signal_id, asset, direction, signal_type, 
                        confidence, price, timestamp, (optional) details
            regime: Current market regime from adaptive config
            open_positions: Dict of {position_id: Position} from execution engine
            price_histories: Dict of {asset: [price1, price2, ...]} for multi-TF analysis
            exit_configs: Dict of {asset: ExitConfig} from learning system
        
        Returns:
            List of EnhancedSignal objects (both passed and blocked, check .passed_all_filters)
        """
        if open_positions is None:
            open_positions = {}
        if price_histories is None:
            price_histories = {}
        if exit_configs is None:
            exit_configs = {}
        
        enhanced_signals = []
        
        # ── Step 1: Group signals by asset for stacking detection ──
        signals_by_asset: dict[str, list[dict]] = {}
        for sig in raw_signals:
            asset = sig.get("asset", "")
            signals_by_asset.setdefault(asset, []).append(sig)
        
        # ── Step 2: Process each signal through the pipeline ──
        for sig in raw_signals:
            self.stats.signals_received += 1
            
            asset = sig.get("asset", "")
            direction = sig.get("direction", "neutral")
            signal_type = sig.get("signal_type", "unknown")
            confidence = sig.get("confidence", 0.5)
            price = sig.get("price", 0.0)
            timestamp = sig.get("timestamp", time.time())
            signal_id = sig.get("signal_id", f"sig_{int(timestamp)}_{asset}")
            
            enhanced = EnhancedSignal(
                signal_id=signal_id,
                asset=asset,
                direction=direction,
                signal_type=signal_type,
                confidence=confidence,
                original_confidence=confidence,
                price=price,
                timestamp=timestamp,
            )
            
            # ── Steroid D: Signal Stacking ──
            enhanced = self._apply_signal_stacking(enhanced, signals_by_asset.get(asset, []))
            
            # ── Steroid E: Multi-Timeframe Alignment ──
            enhanced = self._apply_timeframe_alignment(enhanced, price_histories.get(asset, []))
            
            # ── Steroid F: Mean-Reversion Check ──
            enhanced = self._check_mean_reversion(enhanced, regime, price_histories.get(asset, []))
            
            # ── Filter 1: Counter-Trend ──
            enhanced = self._filter_counter_trend(enhanced, regime)
            if not enhanced.passed_all_filters:
                enhanced_signals.append(enhanced)
                continue
            
            # ── Filter 2: Signal Persistence ──
            enhanced = self._filter_persistence(enhanced)
            if not enhanced.passed_all_filters:
                enhanced_signals.append(enhanced)
                continue
            
            # ── Filter 3: Correlation Blocking ──
            enhanced = self._filter_correlation(enhanced, open_positions)
            if not enhanced.passed_all_filters:
                enhanced_signals.append(enhanced)
                continue
            
            # ── All filters passed ──
            self.stats.signals_passed += 1
            enhanced_signals.append(enhanced)
        
        return enhanced_signals
    
    # ═══════════════════════════════════════════════════════════
    #  STEROID D: Signal Stacking
    # ═══════════════════════════════════════════════════════════
    
    def _apply_signal_stacking(
        self, signal: EnhancedSignal, same_asset_signals: list[dict]
    ) -> EnhancedSignal:
        """
        If 2+ different signal types fire on the same asset in the same direction,
        boost confidence. This is high-conviction: breakout + momentum + volume
        all agreeing = strong signal.
        
        Stress test: LINK +$120 on just 3 stacked trades in Bull Run.
        """
        confirming_types = set()
        for other in same_asset_signals:
            if other.get("signal_id") == signal.signal_id:
                continue  # Skip self
            if other.get("direction") == signal.direction:
                confirming_types.add(other.get("signal_type", "unknown"))
        
        if confirming_types:
            # Add the original signal type
            confirming_types.add(signal.signal_type)
            
            # Boost: +8% per additional confirming signal type, max +15%
            extra_signals = len(confirming_types) - 1  # Subtract the primary
            boost = min(0.15, extra_signals * 0.08)
            signal.confidence = min(0.99, signal.confidence + boost)
            signal.stacked = True
            signal.stacked_types = sorted(confirming_types)
            self.stats.stacked_signals += 1
            
            if boost > 0:
                self.stats.avg_confidence_boost = (
                    (self.stats.avg_confidence_boost * (self.stats.stacked_signals - 1) + boost)
                    / self.stats.stacked_signals
                )
            
            logger.info(
                f"STACKED: {signal.asset} {signal.direction} — "
                f"{len(confirming_types)} types: {signal.stacked_types} "
                f"→ confidence {signal.original_confidence:.2f} → {signal.confidence:.2f}"
            )
        
        return signal
    
    # ═══════════════════════════════════════════════════════════
    #  STEROID E: Multi-Timeframe Alignment
    # ═══════════════════════════════════════════════════════════
    
    def _apply_timeframe_alignment(
        self, signal: EnhancedSignal, price_history: list
    ) -> EnhancedSignal:
        """
        Check if short-term (5-period) and medium-term (12-period) trends agree
        with the signal direction.
        
        - Both agree: +10% confidence bonus
        - Disagree: -10% confidence penalty  
        - Not enough data: no change
        
        Filters out "entering during noise" where short-term blips
        contradict the medium-term trend.
        """
        if len(price_history) < 13:
            return signal  # Not enough data
        
        # Short-term trend (last 5 periods)
        short_start = price_history[-6] if len(price_history) >= 6 else price_history[0]
        short_end = price_history[-1]
        short_trend = "bullish" if short_end > short_start else "bearish"
        
        # Medium-term trend (last 12 periods)
        med_start = price_history[-13] if len(price_history) >= 13 else price_history[0]
        med_end = price_history[-1]
        med_trend = "bullish" if med_end > med_start else "bearish"
        
        if short_trend == med_trend == signal.direction:
            # Both timeframes align with signal → confidence boost
            signal.confidence = min(0.99, signal.confidence + 0.10)
            signal.timeframe_aligned = True
        elif short_trend != med_trend:
            # Timeframes disagree → confidence penalty
            signal.confidence = max(0.30, signal.confidence - 0.10)
            signal.timeframe_aligned = False
            signal.timeframe_penalty = 0.10
            self.stats.timeframe_penalties += 1
            logger.debug(
                f"TF MISALIGN: {signal.asset} signal={signal.direction} "
                f"short={short_trend} med={med_trend} → -10% confidence"
            )
        elif short_trend == med_trend and short_trend != signal.direction:
            # Both timeframes agree but AGAINST the signal → bigger penalty
            signal.confidence = max(0.20, signal.confidence - 0.15)
            signal.timeframe_aligned = False
            signal.timeframe_penalty = 0.15
            self.stats.timeframe_penalties += 1
        
        return signal
    
    # ═══════════════════════════════════════════════════════════
    #  STEROID F: Mean-Reversion Mode
    # ═══════════════════════════════════════════════════════════
    
    def _check_mean_reversion(
        self, signal: EnhancedSignal, regime: str, price_history: list
    ) -> EnhancedSignal:
        """
        In RANGING regime, check if price has deviated significantly from
        its 20-period mean. If so, generate a mean-reversion hint.
        
        This doesn't create NEW signals — it tags existing signals that
        align with a mean-reversion thesis, boosting their confidence.
        
        Stress test: Choppy Sideways went from -$43 to +$138 in first iteration.
        """
        if regime not in ("RANGING", "ACCUMULATION"):
            return signal  # Mean reversion only makes sense in ranging markets
        
        if len(price_history) < 20:
            return signal
        
        # Calculate 20-period mean
        mean_20 = sum(price_history[-20:]) / 20
        current_price = price_history[-1]
        deviation_pct = (current_price - mean_20) / mean_20
        
        # Get market-specific breakout threshold for deviation comparison
        try:
            from config.markets import ASSETS, MARKET_THRESHOLDS
            asset_cfg = ASSETS.get(signal.asset)
            if asset_cfg:
                threshold = MARKET_THRESHOLDS.get(asset_cfg.market)
                if threshold:
                    deviation_threshold = threshold.breakout_pct * 1.5
                else:
                    deviation_threshold = 0.03
            else:
                deviation_threshold = 0.03
        except ImportError:
            deviation_threshold = 0.03
        
        # Check for mean-reversion opportunity
        if abs(deviation_pct) > deviation_threshold:
            # Price is overextended from mean
            reversion_direction = "bearish" if deviation_pct > 0 else "bullish"
            
            if signal.direction == reversion_direction:
                # Signal aligns with mean-reversion thesis → boost
                signal.is_mean_reversion = True
                signal.confidence = min(0.99, signal.confidence + 0.05)
                signal.suggested_behavior = "reverting"
                self.stats.mean_reversion_signals += 1
                
                logger.info(
                    f"MEAN-REVERSION: {signal.asset} deviated {deviation_pct:+.2%} from mean "
                    f"→ {reversion_direction} signal boosted"
                )
        
        return signal
    
    # ═══════════════════════════════════════════════════════════
    #  FILTER 1: Counter-Trend Filter
    # ═══════════════════════════════════════════════════════════
    
    def _filter_counter_trend(self, signal: EnhancedSignal, regime: str) -> EnhancedSignal:
        """
        Block signals that go against the current market regime.
        
        RISK_OFF_VOLATILE or RISK_ON_TRENDING have clear directional bias.
        Don't fight the regime.
        
        Mean-reversion signals are EXEMPT from this filter (they're supposed
        to counter-trend in ranging markets).
        """
        if signal.is_mean_reversion:
            return signal  # Mean-reversion is intentionally counter-trend
        
        # Map regimes to allowed directions
        regime_direction = {
            "RISK_ON_TRENDING": "bullish",    # Only buy in risk-on
            "RISK_OFF_VOLATILE": "bearish",   # Only sell/short in risk-off  
            # RANGING, BREAKOUT, ACCUMULATION → both directions OK
        }
        
        allowed = regime_direction.get(regime)
        if allowed and signal.direction != allowed and signal.direction != "neutral":
            signal.passed_all_filters = False
            signal.filter_blocked_by = "counter_trend"
            self.stats.blocked_counter_trend += 1
            self.stats.signals_blocked += 1
            
            logger.debug(
                f"BLOCKED (counter-trend): {signal.asset} {signal.direction} "
                f"in {regime} regime (only {allowed} allowed)"
            )
        
        return signal
    
    # ═══════════════════════════════════════════════════════════
    #  FILTER 2: Signal Persistence
    # ═══════════════════════════════════════════════════════════
    
    def _filter_persistence(self, signal: EnhancedSignal) -> EnhancedSignal:
        """
        Require at least 2 consecutive signals for the same asset in the
        same direction before allowing a trade. Prevents acting on one-off noise.
        
        Stacked signals (2+ types) are EXEMPT — the stacking itself
        provides the confirmation we'd normally get from persistence.
        """
        if signal.stacked:
            signal.persistence_count = 2  # Auto-pass: stacking = confirmation
            return signal
        
        asset = signal.asset
        direction = signal.direction
        now = signal.timestamp or time.time()
        
        # Initialize history for this asset
        if asset not in self._signal_history:
            self._signal_history[asset] = []
        
        # Clean old signals (older than 10 minutes)
        self._signal_history[asset] = [
            (ts, d) for ts, d in self._signal_history[asset]
            if now - ts < 600
        ]
        
        # Add current signal
        self._signal_history[asset].append((now, direction))
        
        # Count consecutive signals in the same direction (most recent)
        consecutive = 0
        for ts, d in reversed(self._signal_history[asset]):
            if d == direction:
                consecutive += 1
            else:
                break
        
        signal.persistence_count = consecutive
        
        if consecutive < 2:
            signal.passed_all_filters = False
            signal.filter_blocked_by = "persistence"
            self.stats.blocked_persistence += 1
            self.stats.signals_blocked += 1
            
            logger.debug(
                f"BLOCKED (persistence): {signal.asset} {signal.direction} "
                f"only {consecutive} consecutive (need 2+)"
            )
        
        return signal
    
    # ═══════════════════════════════════════════════════════════
    #  FILTER 3: Correlation Blocking
    # ═══════════════════════════════════════════════════════════
    
    def _filter_correlation(
        self, signal: EnhancedSignal, open_positions: dict
    ) -> EnhancedSignal:
        """
        Before opening a new position, check if we already have an open
        position in a highly correlated asset going the same direction.
        
        Prevents: Long BTC + Long ETH (0.92 correlation = duplicate exposure)
        Allows: Long BTC + Short TLT (negative correlation = hedge)
        
        Stress test: Blocked 0-1 trades per simulation (positions rarely overlap
        temporally), but critical insurance for live trading with concurrent positions.
        """
        try:
            from config.markets import get_correlation, CORRELATION_BLOCK_THRESHOLD
        except ImportError:
            return signal  # Can't check without config
        
        for pos_id, pos in open_positions.items():
            # Get the position's symbol and side
            pos_symbol = getattr(pos, 'symbol', '')
            pos_side = getattr(pos, 'side', '')
            if hasattr(pos_side, 'value'):
                pos_side = pos_side.value  # Handle enum
            
            # Map side to direction
            pos_direction = "bullish" if pos_side in ("buy", "BUY") else "bearish"
            
            if pos_direction != signal.direction:
                continue  # Different directions = potentially good hedge
            
            corr = get_correlation(signal.asset, pos_symbol)
            
            if corr >= CORRELATION_BLOCK_THRESHOLD:
                signal.passed_all_filters = False
                signal.filter_blocked_by = f"correlation ({signal.asset}↔{pos_symbol}: {corr:.2f})"
                self.stats.blocked_correlation += 1
                self.stats.signals_blocked += 1
                
                logger.info(
                    f"BLOCKED (correlation): {signal.asset} {signal.direction} "
                    f"correlates {corr:.2f} with open {pos_symbol} {pos_direction}"
                )
                break
        
        return signal
    
    # ═══════════════════════════════════════════════════════════
    #  Utility Methods
    # ═══════════════════════════════════════════════════════════
    
    def get_stats(self) -> SignalIntelligenceStats:
        """Get current stats."""
        return self.stats
    
    def get_stats_summary(self) -> str:
        """Get human-readable stats for Telegram/reporting."""
        s = self.stats
        return (
            f"🧠 *Signal Intelligence*\n"
            f"Processed: {s.signals_received} | Passed: {s.signals_passed} | Blocked: {s.signals_blocked}\n"
            f"Stacked: {s.stacked_signals} | Mean-Rev: {s.mean_reversion_signals}\n"
            f"Blocked by: CTrend={s.blocked_counter_trend} Persist={s.blocked_persistence} Corr={s.blocked_correlation}\n"
            f"TF penalties: {s.timeframe_penalties} | Avg boost: {s.avg_confidence_boost:.2f}"
        )
    
    def reset_stats(self):
        """Reset stats (e.g., daily reset)."""
        self.stats = SignalIntelligenceStats()
    
    def clear_history(self):
        """Clear signal history (e.g., on regime change)."""
        self._signal_history.clear()
