"""
Trading & Market Research Agent

Capabilities:
- Fetch crypto/stock prices
- Analyze market data
- Check prediction market odds
- Screen SEC filings (Edgar)
- Generate trade signals and reports
"""
import json
import subprocess
from agents.base_agent import BaseAgent


class TradingAgent(BaseAgent):

    @property
    def name(self) -> str:
        return "trading"

    @property
    def description(self) -> str:
        return (
            "Handles trading research, market analysis, price lookups, "
            "prediction market data, SEC filing analysis, technical analysis, "
            "and trade signal generation."
        )

    @property
    def system_prompt(self) -> str:
        return """You are a quantitative trading research agent. You have tools to:
- Fetch real-time crypto and stock prices
- Run Python code for technical analysis and backtesting
- Search the web for market news and data
- Analyze data and generate trade signals

When given a task:
1. Break it down into concrete steps
2. Use your tools to gather data
3. Analyze the data thoroughly
4. Present clear, actionable findings with specific numbers

Always include risk warnings for any trade recommendations.
Format responses for Telegram (use markdown sparingly, keep it readable).
Be concise but thorough. Numbers matter more than narrative."""

    def get_tools(self) -> list[dict]:
        return [
            {
                "name": "fetch_price",
                "description": "Fetch current price for a crypto token or stock ticker. Supports CoinGecko for crypto and Yahoo Finance for stocks.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "symbol": {
                            "type": "string",
                            "description": "Ticker symbol (e.g., 'BTC', 'ETH', 'AAPL', 'SPY')"
                        },
                        "asset_type": {
                            "type": "string",
                            "enum": ["crypto", "stock"],
                            "description": "Whether this is crypto or stock"
                        }
                    },
                    "required": ["symbol", "asset_type"]
                }
            },
            {
                "name": "run_python",
                "description": "Execute Python code for analysis, backtesting, or data processing. Has access to pandas, numpy, requests, ta (technical analysis).",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "code": {
                            "type": "string",
                            "description": "Python code to execute"
                        }
                    },
                    "required": ["code"]
                }
            },
            {
                "name": "web_search",
                "description": "Search the web for market news, data, or research.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query"
                        }
                    },
                    "required": ["query"]
                }
            },
        ]

    def handle_tool_call(self, tool_name: str, tool_input: dict):
        if tool_name == "fetch_price":
            return self._fetch_price(tool_input["symbol"], tool_input["asset_type"])
        elif tool_name == "run_python":
            return self._run_python(tool_input["code"])
        elif tool_name == "web_search":
            return self._web_search(tool_input["query"])
        else:
            raise ValueError(f"Unknown tool: {tool_name}")

    def _fetch_price(self, symbol: str, asset_type: str) -> dict:
        """Fetch price via CoinGecko (crypto) or yfinance (stock)."""
        if asset_type == "crypto":
            code = f"""
import requests
# Map common symbols to CoinGecko IDs
SYMBOL_MAP = {{
    'BTC': 'bitcoin', 'ETH': 'ethereum', 'SOL': 'solana',
    'XRP': 'ripple', 'DOGE': 'dogecoin', 'ADA': 'cardano',
    'AVAX': 'avalanche-2', 'LINK': 'chainlink', 'DOT': 'polkadot',
}}
cg_id = SYMBOL_MAP.get('{symbol}'.upper(), '{symbol}'.lower())
r = requests.get(
    f'https://api.coingecko.com/api/v3/simple/price',
    params={{'ids': cg_id, 'vs_currencies': 'usd', 'include_24hr_change': 'true', 'include_market_cap': 'true'}},
    timeout=10
)
data = r.json()
if cg_id in data:
    d = data[cg_id]
    print(f'{{"symbol": "{symbol}", "price": {{d["usd"]}}, "change_24h": {{d.get("usd_24h_change", "N/A")}}, "market_cap": {{d.get("usd_market_cap", "N/A")}}}}')
else:
    print(f'{{"error": "Symbol {symbol} not found"}}')
"""
        else:
            code = f"""
import yfinance as yf
ticker = yf.Ticker('{symbol}')
info = ticker.fast_info
hist = ticker.history(period='1d')
price = hist['Close'].iloc[-1] if len(hist) > 0 else info.get('lastPrice', 'N/A')
print(f'{{"symbol": "{symbol}", "price": {{price}}, "day_high": {{info.get("dayHigh", "N/A")}}, "day_low": {{info.get("dayLow", "N/A")}}}}')
"""
        return self._run_python(code)

    def _run_python(self, code: str) -> str:
        """Execute Python code in a subprocess."""
        try:
            result = subprocess.run(
                ["python3", "-c", code],
                capture_output=True,
                text=True,
                timeout=60,
                cwd="/tmp"
            )
            output = result.stdout.strip()
            if result.returncode != 0:
                output += f"\nSTDERR: {result.stderr.strip()}"
            return output if output else "(no output)"
        except subprocess.TimeoutExpired:
            return "Error: Code execution timed out (60s limit)"
        except Exception as e:
            return f"Error: {str(e)}"

    def _web_search(self, query: str) -> str:
        """Web search via a simple approach. Replace with your preferred search API."""
        # Using DuckDuckGo lite as a fallback - replace with SerpAPI/Tavily for production
        code = f"""
import requests
from urllib.parse import quote_plus
headers = {{'User-Agent': 'Mozilla/5.0'}}
url = f'https://lite.duckduckgo.com/lite/?q={{quote_plus("{query}")}}'
r = requests.get(url, headers=headers, timeout=10)
# Extract text snippets (basic parsing)
from html.parser import HTMLParser
class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.texts = []
        self.in_result = False
    def handle_data(self, data):
        text = data.strip()
        if text and len(text) > 20:
            self.texts.append(text)
parser = TextExtractor()
parser.feed(r.text)
for t in parser.texts[:10]:
    print(t)
"""
        return self._run_python(code)
