"""
Execution Engine - The Gut of the Fund

Actually places, tracks, and manages trades across exchanges.

Architecture:
                    ┌─────────────────────┐
                    │  Execution Engine    │
                    │  (Order Manager)     │
                    └─────┬───────────────┘
                          │
         ┌────────────────┼────────────────┐
         ▼                ▼                ▼
  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
  │ TradersPost │ │  Coinbase   │ │   Paper     │
  │  Connector  │ │  Connector  │ │  Connector  │
  └─────────────┘ └─────────────┘ └─────────────┘

Supports:
  - Paper trading (simulated fills)
  - TradersPost webhooks (your existing infra)
  - Coinbase Advanced Trade API (US-compliant crypto)
  - Extensible for Hyperliquid, Alpaca, etc.

Features:
  - Order lifecycle management (pending → open → filled → closed)
  - Position tracking with real-time P&L
  - Stop loss / take profit monitoring
  - Fill tracking and slippage measurement
  - Fee calculation
  - All persisted to database
"""
import json
import time
import hmac
import hashlib
import logging
import requests
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime, timezone
from enum import Enum

from execution.profit_progression import ProfitProgressionEngine, ProgressionState, ExitDecision

logger = logging.getLogger("ExecutionEngine")


class OrderSide(str, Enum):
    BUY = "buy"
    SELL = "sell"


class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    STOP_LIMIT = "stop_limit"


class OrderStatus(str, Enum):
    PENDING = "pending"       # Created, not yet sent
    SUBMITTED = "submitted"   # Sent to exchange
    OPEN = "open"            # Partially or fully on order book
    FILLED = "filled"        # Fully executed
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    FAILED = "failed"


class PositionStatus(str, Enum):
    OPEN = "open"
    CLOSED = "closed"
    PARTIAL = "partial"      # Partially closed


@dataclass
class Order:
    """Represents a single order."""
    id: str = ""
    strategy_id: str = ""
    symbol: str = ""
    market: str = "crypto"
    side: OrderSide = OrderSide.BUY
    order_type: OrderType = OrderType.MARKET
    quantity: float = 0.0
    price: float = 0.0            # For limit orders
    stop_price: float = 0.0       # For stop orders
    status: OrderStatus = OrderStatus.PENDING
    
    # Fill info
    filled_quantity: float = 0.0
    filled_price: float = 0.0     # Average fill price
    fees: float = 0.0
    slippage: float = 0.0         # Difference from expected price
    
    # Exchange info
    exchange_order_id: str = ""
    exchange: str = ""
    
    # Metadata
    signal_id: str = ""
    created_at: float = field(default_factory=time.time)
    filled_at: float = 0.0
    
    def to_trade_dict(self) -> dict:
        """Convert to trade dict for database storage."""
        return {
            "strategy_id": self.strategy_id,
            "trade_type": self.order_type.value,
            "side": self.side.value,
            "symbol": self.symbol,
            "market": self.market,
            "quantity": self.filled_quantity or self.quantity,
            "entry_price": self.filled_price or self.price,
            "status": "open" if self.side == OrderSide.BUY else "closed",
            "fees": self.fees,
            "order_id": self.exchange_order_id or self.id,
            "exchange": self.exchange,
            "signal_id": self.signal_id,
            "opened_at": datetime.fromtimestamp(self.created_at, tz=timezone.utc).isoformat(),
            "metadata": {
                "slippage": self.slippage,
                "order_type": self.order_type.value,
            },
        }


@dataclass
class Position:
    """Tracks an open position with real-time P&L and profit progression state."""
    id: str = ""
    strategy_id: str = ""
    symbol: str = ""
    market: str = "crypto"
    side: OrderSide = OrderSide.BUY
    quantity: float = 0.0
    entry_price: float = 0.0
    current_price: float = 0.0
    stop_loss: float = 0.0
    take_profit: float = 0.0
    status: PositionStatus = PositionStatus.OPEN
    
    # P&L
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    fees_paid: float = 0.0
    
    # Trade IDs
    entry_trade_id: int = 0
    exit_trade_id: int = 0
    entry_order_id: str = ""
    
    # Timing
    opened_at: float = field(default_factory=time.time)
    closed_at: float = 0.0
    
    # ══ Profit Progression State ══
    progression_state: Optional[object] = None  # ProgressionState from profit_progression.py
    signal_confidence: float = 0.0
    signal_type: str = ""
    price_history: list = field(default_factory=list)  # Last 20 prices for ATR/momentum

    def update_pnl(self, current_price: float):
        """Recalculate unrealized P&L and track price history."""
        self.current_price = current_price
        if self.side == OrderSide.BUY:
            self.unrealized_pnl = (current_price - self.entry_price) * self.quantity - self.fees_paid
        else:
            self.unrealized_pnl = (self.entry_price - current_price) * self.quantity - self.fees_paid
        # Maintain rolling price history for ATR/momentum calculations
        self.price_history.append(current_price)
        if len(self.price_history) > 30:
            self.price_history = self.price_history[-30:]

    def should_stop_loss(self, current_price: float) -> bool:
        if self.stop_loss <= 0:
            return False
        if self.side == OrderSide.BUY:
            return current_price <= self.stop_loss
        return current_price >= self.stop_loss

    def should_take_profit(self, current_price: float) -> bool:
        if self.take_profit <= 0:
            return False
        if self.side == OrderSide.BUY:
            return current_price >= self.take_profit
        return current_price <= self.take_profit


# ════════════════════════════════════════════════════════════════
#  EXCHANGE CONNECTORS
# ════════════════════════════════════════════════════════════════

class BaseConnector(ABC):
    """Abstract exchange connector."""

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    def place_order(self, order: Order) -> Order: ...

    @abstractmethod
    def cancel_order(self, exchange_order_id: str) -> bool: ...

    @abstractmethod
    def get_order_status(self, exchange_order_id: str) -> OrderStatus: ...

    @abstractmethod
    def get_current_price(self, symbol: str) -> float: ...

    @abstractmethod
    def get_balance(self) -> dict: ...


class PaperConnector(BaseConnector):
    """
    Simulated exchange for paper trading.
    Fills instantly at current market price with simulated slippage.
    """

    def __init__(self, initial_balance: float = 10000.0, fee_rate: float = 0.001):
        self.balance = {"USD": initial_balance}
        self.fee_rate = fee_rate
        self._order_counter = 0
        self._price_cache: dict[str, float] = {}

    @property
    def name(self) -> str:
        return "paper"

    def place_order(self, order: Order) -> Order:
        self._order_counter += 1
        order.exchange = "paper"
        order.exchange_order_id = f"paper_{self._order_counter}"

        # Get current price
        current_price = self.get_current_price(order.symbol)
        if current_price <= 0:
            order.status = OrderStatus.REJECTED
            return order

        # Simulate slippage (0.01% - 0.05%)
        import random
        slippage_pct = random.uniform(0.0001, 0.0005)
        if order.side == OrderSide.BUY:
            fill_price = current_price * (1 + slippage_pct)
        else:
            fill_price = current_price * (1 - slippage_pct)

        # Calculate fees
        trade_value = fill_price * order.quantity
        fees = trade_value * self.fee_rate

        # Check balance for buys
        if order.side == OrderSide.BUY:
            required = trade_value + fees
            if self.balance.get("USD", 0) < required:
                order.status = OrderStatus.REJECTED
                logger.warning(f"Paper: Insufficient balance. Need ${required:.2f}, have ${self.balance.get('USD', 0):.2f}")
                return order
            self.balance["USD"] -= required
            self.balance[order.symbol] = self.balance.get(order.symbol, 0) + order.quantity
        else:
            # Sell
            if self.balance.get(order.symbol, 0) < order.quantity:
                order.status = OrderStatus.REJECTED
                return order
            self.balance[order.symbol] -= order.quantity
            self.balance["USD"] += trade_value - fees

        order.filled_price = fill_price
        order.filled_quantity = order.quantity
        order.fees = fees
        order.slippage = abs(fill_price - current_price)
        order.status = OrderStatus.FILLED
        order.filled_at = time.time()

        logger.info(
            f"Paper {order.side.value}: {order.quantity} {order.symbol} "
            f"@ ${fill_price:.4f} (fees: ${fees:.4f})"
        )
        return order

    def cancel_order(self, exchange_order_id: str) -> bool:
        return True  # Paper orders fill instantly, nothing to cancel

    def get_order_status(self, exchange_order_id: str) -> OrderStatus:
        return OrderStatus.FILLED

    def get_current_price(self, symbol: str) -> float:
        """Fetch real price from CoinGecko."""
        try:
            symbol_map = {
                "BTC": "bitcoin", "ETH": "ethereum", "SOL": "solana",
                "XRP": "ripple", "DOGE": "dogecoin", "AVAX": "avalanche-2",
                "LINK": "chainlink", "ADA": "cardano", "DOT": "polkadot",
                "PEPE": "pepe", "MATIC": "matic-network",
            }
            cg_id = symbol_map.get(symbol.upper(), symbol.lower())
            r = requests.get(
                "https://api.coingecko.com/api/v3/simple/price",
                params={"ids": cg_id, "vs_currencies": "usd"},
                timeout=10,
            )
            data = r.json()
            price = data.get(cg_id, {}).get("usd", 0)
            self._price_cache[symbol.upper()] = price
            return price
        except Exception as e:
            logger.error(f"Price fetch failed for {symbol}: {e}")
            return self._price_cache.get(symbol.upper(), 0)

    def get_balance(self) -> dict:
        return self.balance.copy()


class TradersPostConnector(BaseConnector):
    """
    Connects to TradersPost via webhooks.
    TradersPost then routes to your broker (Alpaca, Tradovate, etc.)
    """

    def __init__(self, webhook_url: str, api_key: str = ""):
        self.webhook_url = webhook_url
        self.api_key = api_key
        self._paper = PaperConnector()  # Fallback for price data

    @property
    def name(self) -> str:
        return "traderspost"

    def place_order(self, order: Order) -> Order:
        """Send order via TradersPost webhook."""
        payload = {
            "ticker": order.symbol,
            "action": order.side.value,
            "quantity": order.quantity,
            "price": order.price if order.order_type == OrderType.LIMIT else 0,
            "orderType": order.order_type.value,
        }

        # Add sentiment for TradersPost format
        if order.side == OrderSide.BUY:
            payload["sentiment"] = "bullish"
        else:
            payload["sentiment"] = "bearish"

        try:
            headers = {"Content-Type": "application/json"}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"

            r = requests.post(
                self.webhook_url,
                json=payload,
                headers=headers,
                timeout=10,
            )

            if r.status_code == 200:
                resp = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
                order.exchange = "traderspost"
                order.exchange_order_id = resp.get("orderId", f"tp_{int(time.time())}")
                order.status = OrderStatus.SUBMITTED
                logger.info(f"TradersPost order submitted: {order.side.value} {order.quantity} {order.symbol}")
            else:
                order.status = OrderStatus.FAILED
                logger.error(f"TradersPost webhook failed: {r.status_code} {r.text}")
        except Exception as e:
            order.status = OrderStatus.FAILED
            logger.error(f"TradersPost error: {e}")

        return order

    def cancel_order(self, exchange_order_id: str) -> bool:
        # TradersPost cancellation would need their API
        logger.warning("TradersPost cancel not implemented - manage via TP dashboard")
        return False

    def get_order_status(self, exchange_order_id: str) -> OrderStatus:
        # Would need TradersPost API polling
        return OrderStatus.SUBMITTED

    def get_current_price(self, symbol: str) -> float:
        return self._paper.get_current_price(symbol)

    def get_balance(self) -> dict:
        return {"note": "Check balance via TradersPost dashboard"}


class CoinbaseConnector(BaseConnector):
    """
    Coinbase Advanced Trade API for US-compliant crypto trading.
    """

    def __init__(self, api_key: str, api_secret: str):
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = "https://api.coinbase.com/api/v3/brokerage"
        self._paper = PaperConnector()

    @property
    def name(self) -> str:
        return "coinbase"

    def _sign_request(self, method: str, path: str, body: str = "") -> dict:
        timestamp = str(int(time.time()))
        message = f"{timestamp}{method.upper()}{path}{body}"
        signature = hmac.new(
            self.api_secret.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        return {
            "CB-ACCESS-KEY": self.api_key,
            "CB-ACCESS-SIGN": signature,
            "CB-ACCESS-TIMESTAMP": timestamp,
            "Content-Type": "application/json",
        }

    def place_order(self, order: Order) -> Order:
        path = "/orders"
        product_id = f"{order.symbol}-USD"

        body_dict = {
            "client_order_id": order.id or f"fund_{int(time.time())}",
            "product_id": product_id,
            "side": order.side.value.upper(),
            "order_configuration": {},
        }

        if order.order_type == OrderType.MARKET:
            if order.side == OrderSide.BUY:
                body_dict["order_configuration"]["market_market_ioc"] = {
                    "quote_size": str(round(order.quantity * order.price, 2))
                }
            else:
                body_dict["order_configuration"]["market_market_ioc"] = {
                    "base_size": str(order.quantity)
                }
        elif order.order_type == OrderType.LIMIT:
            body_dict["order_configuration"]["limit_limit_gtc"] = {
                "base_size": str(order.quantity),
                "limit_price": str(order.price),
            }

        body = json.dumps(body_dict)
        headers = self._sign_request("POST", f"/api/v3/brokerage{path}", body)

        try:
            r = requests.post(
                f"{self.base_url}{path}",
                data=body,
                headers=headers,
                timeout=10,
            )
            if r.status_code in (200, 201):
                data = r.json()
                order.exchange = "coinbase"
                order.exchange_order_id = data.get("order_id", "")
                order.status = OrderStatus.SUBMITTED
                logger.info(f"Coinbase order submitted: {order.exchange_order_id}")
            else:
                order.status = OrderStatus.FAILED
                logger.error(f"Coinbase order failed: {r.status_code} {r.text}")
        except Exception as e:
            order.status = OrderStatus.FAILED
            logger.error(f"Coinbase error: {e}")

        return order

    def cancel_order(self, exchange_order_id: str) -> bool:
        path = f"/orders/batch_cancel"
        body = json.dumps({"order_ids": [exchange_order_id]})
        headers = self._sign_request("POST", f"/api/v3/brokerage{path}", body)
        try:
            r = requests.post(f"{self.base_url}{path}", data=body, headers=headers, timeout=10)
            return r.status_code == 200
        except Exception:
            return False

    def get_order_status(self, exchange_order_id: str) -> OrderStatus:
        path = f"/orders/historical/{exchange_order_id}"
        headers = self._sign_request("GET", f"/api/v3/brokerage{path}")
        try:
            r = requests.get(f"{self.base_url}{path}", headers=headers, timeout=10)
            if r.status_code == 200:
                data = r.json().get("order", {})
                status_map = {
                    "FILLED": OrderStatus.FILLED,
                    "CANCELLED": OrderStatus.CANCELLED,
                    "OPEN": OrderStatus.OPEN,
                    "PENDING": OrderStatus.SUBMITTED,
                }
                return status_map.get(data.get("status", ""), OrderStatus.SUBMITTED)
        except Exception:
            pass
        return OrderStatus.SUBMITTED

    def get_current_price(self, symbol: str) -> float:
        return self._paper.get_current_price(symbol)

    def get_balance(self) -> dict:
        path = "/accounts"
        headers = self._sign_request("GET", f"/api/v3/brokerage{path}")
        try:
            r = requests.get(f"{self.base_url}{path}", headers=headers, timeout=10)
            if r.status_code == 200:
                accounts = r.json().get("accounts", [])
                balances = {}
                for acc in accounts:
                    currency = acc.get("currency", "")
                    available = float(acc.get("available_balance", {}).get("value", 0))
                    if available > 0:
                        balances[currency] = available
                return balances
        except Exception as e:
            logger.error(f"Coinbase balance error: {e}")
        return {}


# ════════════════════════════════════════════════════════════════
#  EXECUTION ENGINE (Order Manager)
# ════════════════════════════════════════════════════════════════

class ExecutionEngine:
    """
    Central order management system.
    
    Manages the full lifecycle:
      Signal → Order → Submission → Fill → Position → Monitor → Close
    
    All state persisted to database.
    """

    def __init__(self, db, connector: BaseConnector, notify_fn=None):
        self.db = db
        self.connector = connector
        self.notify = notify_fn
        self.positions: dict[str, Position] = {}
        self._order_counter = 0
        
        # ══ Profit Progression Engine (replaces simple SL/TP) ══
        self.profit_progression = ProfitProgressionEngine()
        
        # Per-asset exit configs (self-tuning via learning system)
        # Initialize with defaults, learning system overrides per asset
        self._exit_configs: dict[str, dict] = {}
        try:
            from config.markets import ASSETS, ExitConfig
            for sym in ASSETS:
                ec = ExitConfig()
                self._exit_configs[sym] = {
                    "trail_mult": ec.trail_mult,
                    "breakeven_at": ec.breakeven_at,
                    "partial_at": ec.partial_at,
                    "partial_pct": ec.partial_pct,
                    "extend_tp": ec.extend_tp,
                    "behavior": ec.behavior,
                }
        except ImportError:
            pass  # Will use defaults from profit_progression
        
        # Current regime (updated by adaptive config)
        self.current_regime: str = "RANGING"
        
        # Load open positions from database on startup
        self._restore_positions()

    def _restore_positions(self):
        """Restore open positions from database on restart."""
        open_trades = self.db.get_open_positions()
        for trade in open_trades:
            pos_id = f"pos_{trade['strategy_id']}_{trade['symbol']}"
            self.positions[pos_id] = Position(
                id=pos_id,
                strategy_id=trade["strategy_id"],
                symbol=trade["symbol"],
                market=trade.get("market", "crypto"),
                side=OrderSide(trade["side"]),
                quantity=trade["quantity"],
                entry_price=trade["entry_price"],
                stop_loss=trade.get("stop_loss", 0),
                take_profit=trade.get("take_profit", 0),
                entry_trade_id=trade["id"],
                opened_at=time.time(),
            )
        if self.positions:
            logger.info(f"Restored {len(self.positions)} open positions from database")

    # ── Order Placement ─────────────────────────────────────────

    async def open_position(
        self,
        strategy_id: str,
        symbol: str,
        side: str,
        quantity: float,
        stop_loss: float = 0,
        take_profit: float = 0,
        order_type: str = "market",
        limit_price: float = 0,
        signal_id: str = "",
        market: str = "crypto",
    ) -> Optional[Position]:
        """Open a new position with ATR-based stops and profit progression."""
        
        self._order_counter += 1
        order = Order(
            id=f"ord_{int(time.time())}_{self._order_counter}",
            strategy_id=strategy_id,
            symbol=symbol.upper(),
            market=market,
            side=OrderSide(side),
            order_type=OrderType(order_type),
            quantity=quantity,
            price=limit_price,
            signal_id=signal_id,
        )

        # ══ ATR-based stops (Steroid A): Auto-compute if not provided ══
        if stop_loss == 0 or take_profit == 0:
            try:
                from execution.atr_stops import calculate_stops, compute_atr
                from config.markets import ASSETS
                
                entry = limit_price or self.connector.get_current_price(symbol.upper())
                atr_pct = ASSETS[symbol.upper()].vol if symbol.upper() in ASSETS else 0.02
                
                # Get regime-adaptive SL multiplier
                sl_regime_mult = 1.0
                try:
                    from config.markets import REGIMES
                    if self.current_regime in REGIMES:
                        sl_regime_mult = REGIMES[self.current_regime].sl_mult
                except ImportError:
                    pass
                
                computed_sl, computed_tp = calculate_stops(
                    entry_price=entry,
                    side=side,
                    atr_pct=atr_pct,
                    regime=self.current_regime,
                    sl_regime_mult=sl_regime_mult,
                )
                if stop_loss == 0:
                    stop_loss = computed_sl
                if take_profit == 0:
                    take_profit = computed_tp
                    
                logger.info(
                    f"ATR stops computed for {symbol}: "
                    f"SL=${stop_loss:.4f} TP=${take_profit:.4f} "
                    f"(regime={self.current_regime}, ATR={atr_pct:.3f})"
                )
            except (ImportError, Exception) as e:
                logger.warning(f"ATR stop computation failed, using provided values: {e}")

        # ══ Correlation filter (Steroid B): Block duplicate exposure ══
        try:
            from execution.capital_allocator import CapitalAllocator
            # Quick check — are we already exposed to a highly correlated asset?
            open_pos = self.get_all_positions()
            from config.markets import get_correlation, CORRELATION_BLOCK_THRESHOLD
            for pos_data in open_pos:
                if pos_data.get("side") == side:
                    corr = get_correlation(symbol.upper(), pos_data.get("symbol", ""))
                    if corr >= CORRELATION_BLOCK_THRESHOLD:
                        logger.warning(
                            f"CORR FILTER: Blocking {symbol} ({side}) — "
                            f"correlated {corr:.2f} with open {pos_data['symbol']}"
                        )
                        self.db.log_audit(
                            agent="execution_engine",
                            action="order_blocked_correlation",
                            details=f"Blocked {symbol} — correlated {corr:.2f} with {pos_data['symbol']}",
                            strategy_id=strategy_id,
                        )
                        return None
        except ImportError:
            pass

        # Log the decision
        self.db.log_audit(
            agent="execution_engine",
            action="order_placed",
            details=f"{side} {quantity} {symbol} via {self.connector.name}",
            strategy_id=strategy_id,
            reasoning=f"Signal: {signal_id}" if signal_id else "Strategy entry",
        )

        # Place the order
        order = self.connector.place_order(order)

        if order.status in (OrderStatus.FILLED, OrderStatus.SUBMITTED):
            # Record trade in database
            trade_dict = order.to_trade_dict()
            trade_dict["stop_loss"] = stop_loss
            trade_dict["take_profit"] = take_profit
            trade_id = self.db.record_trade(trade_dict)

            # Create position object
            pos_id = f"pos_{strategy_id}_{symbol}_{int(time.time())}"
            position = Position(
                id=pos_id,
                strategy_id=strategy_id,
                symbol=symbol.upper(),
                market=market,
                side=OrderSide(side),
                quantity=order.filled_quantity or quantity,
                entry_price=order.filled_price or limit_price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                entry_trade_id=trade_id,
                entry_order_id=order.exchange_order_id,
                fees_paid=order.fees,
                signal_confidence=float(signal_id.split("_")[-1]) if signal_id and "_" in signal_id else 0.0,
                signal_type=signal_id,
            )
            
            # ══ Initialize profit progression state ══
            # Calculate ATR from recent prices if available
            atr_pct = 0.02  # Default
            try:
                from config.markets import ASSETS
                if symbol.upper() in ASSETS:
                    atr_pct = ASSETS[symbol.upper()].vol  # Use configured vol as ATR proxy
            except ImportError:
                pass
            
            position.progression_state = self.profit_progression.init_state(
                entry_price=position.entry_price,
                quantity=position.quantity,
                stop_loss=stop_loss,
                take_profit=take_profit,
                position_usd=position.quantity * position.entry_price,
                atr_pct=atr_pct,
            )
            position.price_history = [position.entry_price]
            
            self.positions[pos_id] = position

            await self._notify_trade(
                f"📥 *Position Opened*\n"
                f"{side.upper()} {quantity} {symbol}\n"
                f"Entry: ${order.filled_price:,.4f}\n"
                f"SL: ${stop_loss:,.4f} | TP: ${take_profit:,.4f}\n"
                f"Fees: ${order.fees:.4f}\n"
                f"Via: {self.connector.name}"
            )

            self.db.log_audit(
                agent="execution_engine",
                action="position_opened",
                details=f"Filled at ${order.filled_price:.4f}, slippage: ${order.slippage:.4f}",
                strategy_id=strategy_id,
                trade_id=trade_id,
            )

            return position
        else:
            self.db.log_audit(
                agent="execution_engine",
                action="order_failed",
                details=f"Status: {order.status.value}",
                strategy_id=strategy_id,
            )
            await self._notify_trade(
                f"❌ *Order Failed*\n{side} {quantity} {symbol}\nStatus: {order.status.value}"
            )
            return None

    async def close_position(self, position_id: str, reason: str = "manual") -> Optional[dict]:
        """Close an open position."""
        if position_id not in self.positions:
            logger.warning(f"Position {position_id} not found")
            return None

        pos = self.positions[position_id]
        
        # Place exit order (opposite side)
        exit_side = OrderSide.SELL if pos.side == OrderSide.BUY else OrderSide.BUY
        self._order_counter += 1
        order = Order(
            id=f"ord_{int(time.time())}_{self._order_counter}",
            strategy_id=pos.strategy_id,
            symbol=pos.symbol,
            market=pos.market,
            side=exit_side,
            order_type=OrderType.MARKET,
            quantity=pos.quantity,
        )

        order = self.connector.place_order(order)

        if order.status in (OrderStatus.FILLED, OrderStatus.SUBMITTED):
            exit_price = order.filled_price or self.connector.get_current_price(pos.symbol)
            
            # Calculate P&L
            if pos.side == OrderSide.BUY:
                pnl = (exit_price - pos.entry_price) * pos.quantity - pos.fees_paid - order.fees
            else:
                pnl = (pos.entry_price - exit_price) * pos.quantity - pos.fees_paid - order.fees
            
            pnl_pct = pnl / (pos.entry_price * pos.quantity) * 100

            # Update entry trade as closed
            self.db.update_trade(pos.entry_trade_id, {
                "status": "closed",
                "exit_price": exit_price,
                "pnl": pnl,
                "pnl_pct": pnl_pct,
                "fees": pos.fees_paid + order.fees,
                "closed_at": datetime.now(timezone.utc).isoformat(),
            })

            # Record exit trade
            exit_trade = order.to_trade_dict()
            exit_trade["status"] = "closed"
            exit_trade["pnl"] = pnl
            exit_trade["exit_price"] = exit_price
            self.db.record_trade(exit_trade)

            # Mark position closed
            pos.status = PositionStatus.CLOSED
            pos.realized_pnl = pnl
            pos.closed_at = time.time()
            del self.positions[position_id]

            pnl_icon = "🟢" if pnl > 0 else "🔴"
            await self._notify_trade(
                f"📤 *Position Closed* {pnl_icon}\n"
                f"{pos.symbol} | {reason}\n"
                f"Entry: ${pos.entry_price:,.4f} → Exit: ${exit_price:,.4f}\n"
                f"P&L: ${pnl:,.2f} ({pnl_pct:+.2f}%)\n"
                f"Fees: ${pos.fees_paid + order.fees:.4f}"
            )

            self.db.log_audit(
                agent="execution_engine",
                action="position_closed",
                details=f"P&L: ${pnl:.2f} ({pnl_pct:+.2f}%), reason: {reason}",
                strategy_id=pos.strategy_id,
            )

            return {
                "position_id": position_id,
                "symbol": pos.symbol,
                "pnl": pnl,
                "pnl_pct": pnl_pct,
                "exit_price": exit_price,
                "reason": reason,
            }

        return None

    # ── Position Monitoring ─────────────────────────────────────

    async def check_positions(self) -> list[dict]:
        """
        Check all open positions through the 4-stage profit progression system.
        Called by the priority engine on Tier 1 (every 30s).
        
        Replaces the old binary SL/TP with:
          Stage 1: Breakeven stop (move SL to entry after +1x ATR)
          Stage 2: Partial exit (close 50% at +1.5x ATR)
          Stage 3: Trailing stop (ratchet SL behind price)
          Stage 4: Dynamic TP extension (extend target if momentum continues)
        """
        actions = []
        for pos_id, pos in list(self.positions.items()):
            try:
                current_price = self.connector.get_current_price(pos.symbol)
                if current_price <= 0:
                    continue

                pos.update_pnl(current_price)
                
                # ══ Run profit progression evaluation ══
                if pos.progression_state is not None:
                    exit_config = self._exit_configs.get(
                        pos.symbol.upper(),
                        {"trail_mult": 1.5, "breakeven_at": 1.0, "partial_at": 1.5,
                         "partial_pct": 0.50, "extend_tp": True, "behavior": "neutral"}
                    )
                    
                    decision = self.profit_progression.evaluate(
                        state=pos.progression_state,
                        current_price=current_price,
                        entry_price=pos.entry_price,
                        side=pos.side.value,
                        current_qty=pos.quantity,
                        position_usd=pos.quantity * pos.entry_price,
                        current_sl=pos.stop_loss,
                        current_tp=pos.take_profit,
                        exit_config=exit_config,
                        regime=self.current_regime,
                        price_history=pos.price_history,
                    )
                    
                    # Apply SL/TP moves (even if no close)
                    if decision.sl_moved:
                        old_sl = pos.stop_loss
                        pos.stop_loss = decision.new_stop_loss
                        if decision.progression_event in ("breakeven_set", "trail_activated"):
                            await self._notify_trade(
                                f"🏃 *{decision.progression_event.replace('_', ' ').title()}*\n"
                                f"{pos.symbol} | SL: ${old_sl:,.4f} → ${pos.stop_loss:,.4f}\n"
                                f"P&L: ${pos.unrealized_pnl:,.2f}"
                            )
                    
                    if decision.tp_moved:
                        pos.take_profit = decision.new_take_profit
                        await self._notify_trade(
                            f"🎯 *TP Extended*\n{pos.symbol} | New TP: ${pos.take_profit:,.4f}"
                        )
                    
                    # Handle close decisions
                    if decision.should_close:
                        if decision.close_reason == "partial":
                            # ── Partial exit: close portion, keep remainder ──
                            result = await self._close_partial(pos_id, decision.close_qty, decision.close_reason)
                            if result:
                                actions.append(result)
                        else:
                            # ── Full exit (SL, TP, trail, breakeven) ──
                            result = await self.close_position(pos_id, reason=decision.close_reason)
                            if result:
                                result["profit_saved_pct"] = decision.profit_saved_pct
                                result["peak_pnl_pct"] = pos.progression_state.peak_pnl_pct if pos.progression_state else 0
                                actions.append(result)
                else:
                    # ══ Fallback: Simple SL/TP for positions without progression state ══
                    if pos.should_stop_loss(current_price):
                        result = await self.close_position(pos_id, reason="stop_loss")
                        if result:
                            actions.append(result)
                        continue

                    if pos.should_take_profit(current_price):
                        result = await self.close_position(pos_id, reason="take_profit")
                        if result:
                            actions.append(result)
                        continue

            except Exception as e:
                logger.error(f"Position check error for {pos_id}: {e}")

        return actions

    async def _close_partial(self, position_id: str, close_qty: float, reason: str = "partial") -> Optional[dict]:
        """Close a portion of an open position (for partial profit-taking)."""
        if position_id not in self.positions:
            return None
        
        pos = self.positions[position_id]
        
        # Place exit order for the partial quantity
        exit_side = OrderSide.SELL if pos.side == OrderSide.BUY else OrderSide.BUY
        self._order_counter += 1
        order = Order(
            id=f"ord_{int(time.time())}_{self._order_counter}",
            strategy_id=pos.strategy_id,
            symbol=pos.symbol,
            market=pos.market,
            side=exit_side,
            order_type=OrderType.MARKET,
            quantity=close_qty,
        )
        
        order = self.connector.place_order(order)
        
        if order.status in (OrderStatus.FILLED, OrderStatus.SUBMITTED):
            exit_price = order.filled_price or self.connector.get_current_price(pos.symbol)
            
            # Calculate P&L on the closed portion
            if pos.side == OrderSide.BUY:
                partial_pnl = (exit_price - pos.entry_price) * close_qty - order.fees
            else:
                partial_pnl = (pos.entry_price - exit_price) * close_qty - order.fees
            
            pnl_pct = partial_pnl / (pos.entry_price * close_qty) * 100 if close_qty > 0 else 0
            
            # Record partial trade in database
            self.db.record_trade({
                "strategy_id": pos.strategy_id,
                "trade_type": "market",
                "side": exit_side.value,
                "symbol": pos.symbol,
                "market": pos.market,
                "quantity": close_qty,
                "entry_price": pos.entry_price,
                "exit_price": exit_price,
                "status": "closed",
                "pnl": partial_pnl,
                "pnl_pct": pnl_pct,
                "fees": order.fees,
                "order_id": order.exchange_order_id,
                "exchange": order.exchange,
                "metadata": {"reason": reason, "partial": True},
            })
            
            # Reduce position size (keep remaining open)
            pos.quantity -= close_qty
            pos.realized_pnl += partial_pnl
            pos.fees_paid += order.fees
            
            # If qty is zero or near-zero, close fully
            if pos.quantity < 0.000001:
                pos.status = PositionStatus.CLOSED
                del self.positions[position_id]
            else:
                pos.status = PositionStatus.PARTIAL
            
            pnl_icon = "🟢" if partial_pnl > 0 else "🔴"
            await self._notify_trade(
                f"💰 *Partial Exit* {pnl_icon}\n"
                f"{pos.symbol} | Closed {close_qty:.6f} ({reason})\n"
                f"P&L: ${partial_pnl:,.2f} ({pnl_pct:+.1f}%)\n"
                f"Remaining: {pos.quantity:.6f}"
            )
            
            self.db.log_audit(
                agent="execution_engine",
                action="partial_exit",
                details=f"Closed {close_qty:.6f} at ${exit_price:.4f}, P&L: ${partial_pnl:.2f}",
                strategy_id=pos.strategy_id,
            )
            
            return {
                "position_id": position_id,
                "symbol": pos.symbol,
                "pnl": partial_pnl,
                "pnl_pct": pnl_pct,
                "exit_price": exit_price,
                "reason": reason,
                "partial": True,
                "qty_closed": close_qty,
                "qty_remaining": pos.quantity,
            }
        
        return None
    
    def update_exit_config(self, symbol: str, config: dict):
        """Update exit config for an asset (called by learning system)."""
        self._exit_configs[symbol.upper()] = config
        logger.info(f"Exit config updated for {symbol}: {config}")
    
    def set_regime(self, regime: str):
        """Update current regime (called by adaptive config)."""
        if regime != self.current_regime:
            logger.info(f"Regime changed: {self.current_regime} → {regime}")
            self.current_regime = regime

    def get_all_positions(self) -> list[dict]:
        """Get all open positions with current P&L."""
        result = []
        for pos in self.positions.values():
            try:
                price = self.connector.get_current_price(pos.symbol)
                pos.update_pnl(price)
            except Exception:
                pass
            result.append({
                "id": pos.id,
                "strategy_id": pos.strategy_id,
                "symbol": pos.symbol,
                "side": pos.side.value,
                "quantity": pos.quantity,
                "entry_price": pos.entry_price,
                "current_price": pos.current_price,
                "unrealized_pnl": pos.unrealized_pnl,
                "stop_loss": pos.stop_loss,
                "take_profit": pos.take_profit,
            })
        return result

    def get_total_exposure(self) -> float:
        """Total USD value of all open positions."""
        total = 0
        for pos in self.positions.values():
            total += pos.quantity * (pos.current_price or pos.entry_price)
        return total

    def get_position_for_strategy(self, strategy_id: str, symbol: str) -> Optional[Position]:
        """Check if a strategy already has a position in this symbol."""
        for pos in self.positions.values():
            if pos.strategy_id == strategy_id and pos.symbol == symbol.upper():
                return pos
        return None

    # ── Helpers ─────────────────────────────────────────────────

    async def _notify_trade(self, message: str):
        if self.notify:
            try:
                await self.notify(message)
            except Exception as e:
                logger.error(f"Trade notification failed: {e}")

    def get_execution_summary(self) -> str:
        """Telegram-friendly execution summary with profit progression stats."""
        positions = self.get_all_positions()
        trade_stats = self.db.get_trade_stats()
        
        lines = [
            f"⚙️ *Execution Engine* ({self.connector.name})\n",
            f"Open positions: {len(positions)}",
            f"Total exposure: ${self.get_total_exposure():,.2f}",
            f"Regime: {self.current_regime}",
        ]

        if positions:
            lines.append("\n*Positions:*")
            for p in positions:
                pnl_icon = "🟢" if p["unrealized_pnl"] >= 0 else "🔴"
                prog = ""
                pos_obj = self.positions.get(p["id"])
                if pos_obj and pos_obj.progression_state:
                    ps = pos_obj.progression_state
                    flags = []
                    if ps.breakeven_set: flags.append("BE")
                    if ps.partial_taken: flags.append("P")
                    if ps.trail_active: flags.append("T")
                    if ps.tp_extended: flags.append("TP+")
                    if flags:
                        prog = f" [{'/'.join(flags)}]"
                
                lines.append(
                    f"  {pnl_icon} {p['symbol']} {p['side']} "
                    f"${p['entry_price']:,.2f} → ${p['current_price']:,.2f} "
                    f"({p['unrealized_pnl']:+,.2f}){prog}"
                )

        if trade_stats:
            total = trade_stats.get("total_trades", 0)
            if total > 0:
                winners = trade_stats.get("winners", 0)
                lines.extend([
                    f"\n*Trade History:*",
                    f"Total: {total} | Win: {winners} | Loss: {trade_stats.get('losers', 0)}",
                    f"Win rate: {winners/total*100:.1f}%",
                    f"Total P&L: ${trade_stats.get('total_pnl', 0):,.2f}",
                    f"Best: ${trade_stats.get('best_trade', 0):,.2f} | "
                    f"Worst: ${trade_stats.get('worst_trade', 0):,.2f}",
                ])
        
        # Profit progression stats
        pp_stats = self.profit_progression.get_stats_summary()
        lines.append(f"\n{pp_stats}")

        return "\n".join(lines)
