"""
Security System - The Skin

Protects the fund from external threats and internal mistakes.

Layers:
  1. Secrets Management  - Encrypted storage for API keys
  2. Input Sanitization  - Prevents injection via agent prompts
  3. Code Sandboxing     - Restricts subprocess execution
  4. Rate Limiting       - Prevents API abuse
  5. Audit Defense       - Detects anomalous behavior
  6. Key Rotation        - Reminds/assists with key rotation
"""
import os
import re
import json
import time
import hashlib
import base64
import logging
import secrets as stdlib_secrets
from typing import Optional
from dataclasses import dataclass, field
from functools import wraps

logger = logging.getLogger("Security")

# ════════════════════════════════════════════════════════════════
#  SECRETS MANAGEMENT
# ════════════════════════════════════════════════════════════════

class SecretsManager:
    """
    Encrypted-at-rest secrets storage using Fernet-like XOR encryption.
    For production, swap to: AWS Secrets Manager, HashiCorp Vault, or keyring.
    
    This provides basic protection against:
    - Secrets appearing in logs
    - Secrets in memory dumps
    - Secrets in error tracebacks
    """

    def __init__(self, master_key: str = None):
        # Derive encryption key from master password or env
        self._key = self._derive_key(
            master_key or os.getenv("FUND_MASTER_KEY", "change-me-in-production")
        )
        self._store: dict[str, str] = {}
        self._loaded = False

    def _derive_key(self, password: str) -> bytes:
        """Derive a fixed-length key from password."""
        return hashlib.sha256(password.encode()).digest()

    def _encrypt(self, plaintext: str) -> str:
        """Simple XOR encryption (use Fernet in production)."""
        data = plaintext.encode()
        key = self._key
        encrypted = bytes(d ^ key[i % len(key)] for i, d in enumerate(data))
        return base64.b64encode(encrypted).decode()

    def _decrypt(self, ciphertext: str) -> str:
        """Decrypt XOR encrypted data."""
        encrypted = base64.b64decode(ciphertext.encode())
        key = self._key
        decrypted = bytes(d ^ key[i % len(key)] for i, d in enumerate(encrypted))
        return decrypted.decode()

    def set_secret(self, name: str, value: str):
        """Store an encrypted secret."""
        self._store[name] = self._encrypt(value)

    def get_secret(self, name: str) -> Optional[str]:
        """Retrieve and decrypt a secret."""
        encrypted = self._store.get(name)
        if encrypted:
            return self._decrypt(encrypted)
        # Fallback to env var
        return os.getenv(name)

    def load_from_env(self):
        """Load all sensitive env vars into encrypted store."""
        sensitive_keys = [
            "ANTHROPIC_API_KEY", "TELEGRAM_BOT_TOKEN",
            "COINBASE_API_KEY", "COINBASE_API_SECRET",
            "TRADERSPOST_WEBHOOK_URL", "FUND_MASTER_KEY",
        ]
        for key in sensitive_keys:
            val = os.getenv(key, "")
            if val:
                self.set_secret(key, val)
                # Optionally clear from env (uncomment for production)
                # os.environ.pop(key, None)
        self._loaded = True
        logger.info(f"Loaded {len(self._store)} secrets into encrypted store")

    def mask(self, value: str) -> str:
        """Mask a secret for safe logging."""
        if not value or len(value) < 8:
            return "***"
        return value[:4] + "*" * (len(value) - 8) + value[-4:]

    def get_rotation_status(self) -> dict:
        """Check which secrets need rotation."""
        # In production, track last rotation date per key
        return {
            "keys_stored": len(self._store),
            "recommendation": "Rotate API keys every 90 days. Use /rotate command for guidance.",
        }


# ════════════════════════════════════════════════════════════════
#  INPUT SANITIZATION
# ════════════════════════════════════════════════════════════════

class InputSanitizer:
    """
    Prevents prompt injection and malicious input.
    Agents receive user input and external data - we need to sanitize both.
    """

    # Patterns that might indicate prompt injection
    INJECTION_PATTERNS = [
        r"ignore\s+(previous|above|all)\s+instructions",
        r"you\s+are\s+now\s+(?:a|an)\s+(?:evil|bad|harmful)",
        r"system\s*prompt\s*:",
        r"<\s*system\s*>",
        r"<\s*/?\s*anthropic",
        r"forget\s+(?:everything|all|your)\s+(?:instructions|rules)",
        r"pretend\s+(?:you|to)\s+(?:are|be)\s+(?:a|an)",
        r"jailbreak",
        r"DAN\s+mode",
    ]

    # Dangerous shell commands
    DANGEROUS_COMMANDS = [
        r"rm\s+-rf\s+/",
        r":()\s*{\s*:\|:&\s*}",  # fork bomb
        r"dd\s+if=/dev",
        r"mkfs\.",
        r">\s*/dev/sd",
        r"chmod\s+-R\s+777\s+/",
        r"curl.*\|\s*(?:sh|bash)",
        r"wget.*\|\s*(?:sh|bash)",
        r"eval\s*\(",
        r"exec\s*\(",
        r"__import__\s*\(",
        r"subprocess\.call.*shell\s*=\s*True",
    ]

    @classmethod
    def sanitize_prompt(cls, text: str) -> tuple[str, list[str]]:
        """
        Sanitize user/external input before passing to agents.
        Returns (sanitized_text, warnings).
        """
        warnings = []
        
        # Check for injection attempts
        for pattern in cls.INJECTION_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                warnings.append(f"Possible prompt injection detected: {pattern}")
                # Don't block, but flag it
                text = re.sub(pattern, "[FILTERED]", text, flags=re.IGNORECASE)

        # Remove potential system-level tags
        text = re.sub(r"</?system[^>]*>", "", text, flags=re.IGNORECASE)

        return text, warnings

    @classmethod
    def sanitize_code(cls, code: str) -> tuple[str, list[str]]:
        """
        Sanitize code before execution in subprocesses.
        Returns (sanitized_code, warnings).
        """
        warnings = []

        for pattern in cls.DANGEROUS_COMMANDS:
            if re.search(pattern, code, re.IGNORECASE):
                warnings.append(f"Dangerous command blocked: {pattern}")
                code = re.sub(pattern, "# BLOCKED: dangerous command", code, flags=re.IGNORECASE)

        # Block file system access outside allowed dirs
        if re.search(r"open\s*\(\s*['\"]\/(?!tmp|home)", code):
            warnings.append("File access outside /tmp and /home blocked")

        return code, warnings

    @classmethod
    def sanitize_api_response(cls, response: str, max_length: int = 50000) -> str:
        """Truncate and clean API responses to prevent memory issues."""
        if len(response) > max_length:
            response = response[:max_length] + "\n... [truncated]"
        return response


# ════════════════════════════════════════════════════════════════
#  RATE LIMITER
# ════════════════════════════════════════════════════════════════

@dataclass
class RateLimitBucket:
    max_calls: int
    window_seconds: float
    calls: list[float] = field(default_factory=list)

    def allow(self) -> bool:
        now = time.time()
        self.calls = [t for t in self.calls if now - t < self.window_seconds]
        if len(self.calls) >= self.max_calls:
            return False
        self.calls.append(now)
        return True

    @property
    def remaining(self) -> int:
        now = time.time()
        active = [t for t in self.calls if now - t < self.window_seconds]
        return max(0, self.max_calls - len(active))


class RateLimiter:
    """
    Rate limiting for external API calls to prevent bans and excessive costs.
    """

    def __init__(self):
        self.buckets: dict[str, RateLimitBucket] = {
            # CoinGecko free tier: 10-30 calls/min
            "coingecko": RateLimitBucket(max_calls=25, window_seconds=60),
            # Claude API: be reasonable
            "anthropic": RateLimitBucket(max_calls=30, window_seconds=60),
            # Yahoo Finance
            "yfinance": RateLimitBucket(max_calls=20, window_seconds=60),
            # TradersPost webhooks
            "traderspost": RateLimitBucket(max_calls=10, window_seconds=60),
            # Coinbase
            "coinbase": RateLimitBucket(max_calls=15, window_seconds=60),
            # General HTTP
            "http": RateLimitBucket(max_calls=60, window_seconds=60),
        }

    def check(self, service: str) -> bool:
        """Check if a call is allowed. Returns True if allowed."""
        bucket = self.buckets.get(service, self.buckets.get("http"))
        if bucket is None:
            return True
        return bucket.allow()

    def remaining(self, service: str) -> int:
        bucket = self.buckets.get(service)
        return bucket.remaining if bucket else 999

    def wait_time(self, service: str) -> float:
        """How long to wait before next call is allowed."""
        bucket = self.buckets.get(service)
        if not bucket or bucket.allow():
            return 0
        if bucket.calls:
            oldest = min(bucket.calls)
            return max(0, bucket.window_seconds - (time.time() - oldest))
        return 0

    def get_status(self) -> dict:
        return {
            name: {"remaining": b.remaining, "max": b.max_calls, "window": b.window_seconds}
            for name, b in self.buckets.items()
        }


# ════════════════════════════════════════════════════════════════
#  ANOMALY DETECTION
# ════════════════════════════════════════════════════════════════

class AnomalyDetector:
    """
    Detects anomalous behavior that might indicate bugs or attacks.
    """

    def __init__(self, db=None):
        self.db = db
        self._alerts: list[dict] = []

    def check_trade_anomaly(self, trade: dict) -> list[str]:
        """Check if a trade looks anomalous."""
        alerts = []

        quantity = trade.get("quantity", 0)
        price = trade.get("entry_price", 0)
        value = quantity * price

        # Unusually large trade
        if value > 5000:  # Configurable threshold
            alerts.append(f"Large trade: ${value:,.2f} ({trade.get('symbol', '?')})")

        # Trade in blocked market
        market = trade.get("market", "")
        if market in ("futures", "options", "derivatives"):
            alerts.append(f"Trade in blocked market: {market}")

        # Rapid successive trades (potential runaway)
        # Would check database for trades in last minute

        if alerts:
            self._alerts.extend([{"alert": a, "timestamp": time.time()} for a in alerts])
        return alerts

    def check_api_anomaly(self, agent: str, tokens: int) -> list[str]:
        """Check if API usage is anomalous."""
        alerts = []

        # Single call using too many tokens
        if tokens > 100000:
            alerts.append(f"Agent {agent}: excessive token usage ({tokens:,} tokens)")

        return alerts

    def get_recent_alerts(self, limit: int = 20) -> list[dict]:
        return self._alerts[-limit:]


# ════════════════════════════════════════════════════════════════
#  SECURITY MANAGER (ties everything together)
# ════════════════════════════════════════════════════════════════

class SecurityManager:
    """
    Central security orchestrator.
    """

    def __init__(self, db=None):
        self.secrets = SecretsManager()
        self.sanitizer = InputSanitizer()
        self.rate_limiter = RateLimiter()
        self.anomaly_detector = AnomalyDetector(db=db)
        self.db = db

        # Load secrets from env on init
        self.secrets.load_from_env()

    def check_and_sanitize_prompt(self, text: str) -> tuple[str, list[str]]:
        """Full sanitization pipeline for user/external input."""
        text, warnings = self.sanitizer.sanitize_prompt(text)
        if warnings and self.db:
            for w in warnings:
                self.db.log_audit("security", "sanitization_warning", w)
        return text, warnings

    def check_and_sanitize_code(self, code: str) -> tuple[str, list[str]]:
        """Full sanitization pipeline for code execution."""
        code, warnings = self.sanitizer.sanitize_code(code)
        if warnings and self.db:
            for w in warnings:
                self.db.log_audit("security", "code_blocked", w)
        return code, warnings

    def check_rate_limit(self, service: str) -> bool:
        return self.rate_limiter.check(service)

    def validate_trade(self, trade: dict) -> tuple[bool, list[str]]:
        """Validate a trade before execution."""
        alerts = self.anomaly_detector.check_trade_anomaly(trade)
        return len(alerts) == 0, alerts

    def get_telegram_summary(self) -> str:
        lines = [
            "🧱 *Security Status*\n",
            f"Secrets: {self.secrets.get_rotation_status()['keys_stored']} encrypted",
        ]

        rl_status = self.rate_limiter.get_status()
        lines.append("\n*Rate Limits:*")
        for service, info in rl_status.items():
            lines.append(f"  {service}: {info['remaining']}/{info['max']} remaining")

        alerts = self.anomaly_detector.get_recent_alerts(5)
        if alerts:
            lines.append(f"\n⚠️ *Recent Alerts ({len(alerts)}):*")
            for a in alerts:
                lines.append(f"  • {a['alert']}")

        return "\n".join(lines)
