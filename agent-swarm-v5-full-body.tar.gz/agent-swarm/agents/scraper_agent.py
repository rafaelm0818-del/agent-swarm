"""
Web Scraping & Data Gathering Agent

Capabilities:
- Scrape web pages (requests + BeautifulSoup)
- Extract structured data from HTML
- Download files
- Parse APIs and JSON endpoints
- Search the web
"""
import os
import subprocess
from agents.base_agent import BaseAgent
from config.settings import settings


class ScraperAgent(BaseAgent):

    def __init__(self):
        super().__init__()
        os.makedirs(settings.SCRAPE_CACHE_DIR, exist_ok=True)

    @property
    def name(self) -> str:
        return "scraper"

    @property
    def description(self) -> str:
        return (
            "Scrapes websites, extracts data from web pages, hits APIs, "
            "downloads files, searches the web, and structures gathered data."
        )

    @property
    def system_prompt(self) -> str:
        return f"""You are a web scraping and data gathering agent. You can:
- Fetch and parse any web page
- Extract structured data from HTML
- Hit APIs and parse JSON responses
- Search the web
- Run Python code for data processing
- Save gathered data to files

When given a scraping task:
1. Identify the target URLs or data sources
2. Fetch the content using the appropriate tool
3. Parse and extract the relevant data
4. Structure it cleanly (JSON, CSV, etc.)
5. Present a summary of what was found

Cache dir: {settings.SCRAPE_CACHE_DIR}
Always respect robots.txt and rate limits.
Use proper User-Agent headers.
Format responses for Telegram - summarize findings concisely."""

    def get_tools(self) -> list[dict]:
        return [
            {
                "name": "fetch_url",
                "description": "Fetch a URL and return the page content (HTML or JSON).",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "URL to fetch"
                        },
                        "extract_text": {
                            "type": "boolean",
                            "description": "If true, extract readable text only (strip HTML). Default: false",
                            "default": False
                        }
                    },
                    "required": ["url"]
                }
            },
            {
                "name": "run_python",
                "description": "Execute Python code for scraping, parsing, or data processing. Has access to requests, beautifulsoup4, lxml, pandas, json.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "code": {
                            "type": "string",
                            "description": "Python code to execute"
                        }
                    },
                    "required": ["code"]
                }
            },
            {
                "name": "web_search",
                "description": "Search the web to find relevant URLs or information.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query"
                        }
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "save_data",
                "description": "Save scraped data to a file in the cache directory.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "filename": {
                            "type": "string",
                            "description": "Filename to save (e.g., 'results.json', 'data.csv')"
                        },
                        "content": {
                            "type": "string",
                            "description": "Data content to save"
                        }
                    },
                    "required": ["filename", "content"]
                }
            },
        ]

    def handle_tool_call(self, tool_name: str, tool_input: dict):
        if tool_name == "fetch_url":
            return self._fetch_url(tool_input["url"], tool_input.get("extract_text", False))
        elif tool_name == "run_python":
            return self._run_python(tool_input["code"])
        elif tool_name == "web_search":
            return self._web_search(tool_input["query"])
        elif tool_name == "save_data":
            return self._save_data(tool_input["filename"], tool_input["content"])
        else:
            raise ValueError(f"Unknown tool: {tool_name}")

    def _fetch_url(self, url: str, extract_text: bool = False) -> str:
        if extract_text:
            code = f"""
import requests
from bs4 import BeautifulSoup
headers = {{'User-Agent': 'Mozilla/5.0 (compatible; DataBot/1.0)'}}
r = requests.get('{url}', headers=headers, timeout=15)
r.raise_for_status()
soup = BeautifulSoup(r.text, 'html.parser')
for tag in soup(['script', 'style', 'nav', 'footer', 'header']):
    tag.decompose()
text = soup.get_text(separator='\\n', strip=True)
# Truncate if massive
print(text[:8000])
"""
        else:
            code = f"""
import requests
headers = {{'User-Agent': 'Mozilla/5.0 (compatible; DataBot/1.0)'}}
r = requests.get('{url}', headers=headers, timeout=15)
r.raise_for_status()
content_type = r.headers.get('content-type', '')
if 'json' in content_type:
    import json
    print(json.dumps(r.json(), indent=2)[:8000])
else:
    print(r.text[:8000])
"""
        return self._run_python(code)

    def _run_python(self, code: str) -> str:
        try:
            result = subprocess.run(
                ["python3", "-c", code],
                capture_output=True, text=True,
                timeout=60,
                cwd=settings.SCRAPE_CACHE_DIR
            )
            output = result.stdout.strip()
            if result.returncode != 0:
                output += f"\nSTDERR: {result.stderr.strip()}"
            return output[:8000] if output else "(no output)"
        except subprocess.TimeoutExpired:
            return "Error: Execution timed out (60s limit)"

    def _web_search(self, query: str) -> str:
        code = f"""
import requests
from urllib.parse import quote_plus
headers = {{'User-Agent': 'Mozilla/5.0'}}
url = f'https://lite.duckduckgo.com/lite/?q={{quote_plus("{query}")}}'
r = requests.get(url, headers=headers, timeout=10)
from html.parser import HTMLParser
class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.texts = []
    def handle_data(self, data):
        text = data.strip()
        if text and len(text) > 20:
            self.texts.append(text)
parser = TextExtractor()
parser.feed(r.text)
for t in parser.texts[:10]:
    print(t)
"""
        return self._run_python(code)

    def _save_data(self, filename: str, content: str) -> str:
        filepath = os.path.join(settings.SCRAPE_CACHE_DIR, filename)
        with open(filepath, "w") as f:
            f.write(content)
        return f"Saved {len(content)} bytes to {filepath}"
