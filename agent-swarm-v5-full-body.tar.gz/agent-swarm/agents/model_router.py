"""
Model Router — The Cost Optimizer

Routes tasks to the cheapest model that can handle them.
This is the single biggest cost lever in the system.

Before:  All tasks → Sonnet ($3/$15 per M tokens) = ~$15-25/day
After:   Simple → Haiku ($0.80/$4) + Complex → Sonnet = ~$5-8/day

Savings: ~$300-500/month = the difference between bleeding money and self-sustaining.

Routing logic:
  HAIKU  — Fast, cheap, good enough for pattern matching and classification
    • Fast scan (signal detection from structured data)
    • Signal classification (bullish/bearish/neutral)
    • Data parsing and formatting
    • Input validation
    • Simple summarization
    • Watchlist management decisions

  SONNET — Smart, expensive, needed for reasoning and creativity
    • Deep scan (multi-timeframe analysis)
    • Research (strategy ideation from market context)
    • Strategy design and hypothesis generation
    • Risk analysis (portfolio-level reasoning)
    • Backtest review (interpreting complex results)
    • Code generation (strategy implementation)
"""
import re
import logging
from dataclasses import dataclass

logger = logging.getLogger("ModelRouter")

HAIKU = "claude-haiku-4-5-20251001"
SONNET = "claude-sonnet-4-20250514"

# Pricing per million tokens
PRICING = {
    HAIKU: {"input": 0.80, "output": 4.00},
    SONNET: {"input": 3.00, "output": 15.00},
}


@dataclass
class RouteDecision:
    model: str
    reason: str
    estimated_cost_per_call: float  # rough USD estimate


# Keywords/patterns that indicate complexity requiring Sonnet
SONNET_PATTERNS = [
    # Research & strategy
    r"research|hypothesis|strategy design|generate.*strateg|propose.*approach",
    r"cross.?market|correlat|macro.*analys|fundamental",
    r"what.*should.*we|recommend|novel|creative|unconventional",
    # Deep analysis
    r"deep.?scan|multi.?timeframe|comprehensive.*analys",
    r"risk.*analys|portfolio.*review|drawdown.*analys",
    r"backtest.*review|interpret.*results|evaluate.*performance",
    # Code generation
    r"write.*code|implement|generate.*script|create.*function",
    r"pine.?script|python.*strategy|trading.*algorithm",
    # Complex reasoning
    r"compare.*and.*contrast|trade.?off|pros.*cons",
    r"regime.*shift.*implications|structural.*change",
]

# Keywords that are definitely simple enough for Haiku
HAIKU_PATTERNS = [
    r"fast.?scan|quick.*check|scan.*for.*signals",
    r"classify|categorize|label|tag",
    r"parse|extract|format|summarize.*data",
    r"validate|verify|check.*if",
    r"current.*price|latest.*data|what.*is.*the",
    r"watchlist.*(add|remove|update|cleanup)",
    r"signal.*(strength|type|direction)",
]

# Task name → model mapping (explicit overrides)
TASK_MODEL_MAP = {
    # Haiku tasks (cheap, fast)
    "fast_scan": HAIKU,
    "classify_signal": HAIKU,
    "parse_data": HAIKU,
    "format_output": HAIKU,
    "validate_input": HAIKU,
    "watchlist_cleanup": HAIKU,
    "watchlist_sync": HAIKU,
    "signal_classification": HAIKU,
    "data_fetch": HAIKU,
    "position_check": HAIKU,  # Simple: check price vs SL/TP
    "budget_check": HAIKU,
    "regime_classify": HAIKU,

    # Sonnet tasks (complex reasoning)
    "research": SONNET,
    "deep_scan": SONNET,
    "strategy_design": SONNET,
    "risk_analysis": SONNET,
    "backtest_review": SONNET,
    "code_generation": SONNET,
    "portfolio_review": SONNET,
    "learning_refresh": SONNET,
    "rebalance_check": SONNET,
}


class ModelRouter:
    """
    Decides which model to use for each task.
    
    Usage:
        router = ModelRouter()
        decision = router.route("fast_scan", task_prompt)
        # decision.model = "claude-haiku-4-5-20251001"
        # decision.reason = "Task 'fast_scan' mapped to Haiku"
    """

    def __init__(self, default_model: str = HAIKU, force_model: str = None):
        self.default_model = default_model
        self.force_model = force_model  # Override for testing
        self._stats = {"haiku": 0, "sonnet": 0}

    def route(self, task_name: str = "", prompt: str = "") -> RouteDecision:
        """
        Decide which model to use.
        
        Priority:
          1. Force override (for testing/debugging)
          2. Explicit task name mapping
          3. Prompt content analysis
          4. Default (Haiku — cheaper is better when uncertain)
        """
        # 1. Force override
        if self.force_model:
            return RouteDecision(
                model=self.force_model,
                reason=f"Forced to {self.force_model}",
                estimated_cost_per_call=self._estimate_cost(self.force_model),
            )

        # 2. Explicit task mapping
        task_lower = task_name.lower().strip()
        if task_lower in TASK_MODEL_MAP:
            model = TASK_MODEL_MAP[task_lower]
            self._track(model)
            return RouteDecision(
                model=model,
                reason=f"Task '{task_lower}' → {'Haiku' if model == HAIKU else 'Sonnet'}",
                estimated_cost_per_call=self._estimate_cost(model),
            )

        # 3. Prompt analysis
        prompt_lower = prompt.lower()

        # Check Sonnet patterns first (complex tasks)
        for pattern in SONNET_PATTERNS:
            if re.search(pattern, prompt_lower):
                self._track(SONNET)
                return RouteDecision(
                    model=SONNET,
                    reason=f"Complex task detected (pattern: {pattern[:30]}...)",
                    estimated_cost_per_call=self._estimate_cost(SONNET),
                )

        # Check Haiku patterns (simple tasks)
        for pattern in HAIKU_PATTERNS:
            if re.search(pattern, prompt_lower):
                self._track(HAIKU)
                return RouteDecision(
                    model=HAIKU,
                    reason=f"Simple task detected (pattern: {pattern[:30]}...)",
                    estimated_cost_per_call=self._estimate_cost(HAIKU),
                )

        # 4. Default — use token count as heuristic
        # Long prompts = probably complex = Sonnet
        # Short prompts = probably simple = Haiku
        if len(prompt) > 3000:
            self._track(SONNET)
            return RouteDecision(
                model=SONNET,
                reason="Long prompt (>3000 chars) → likely complex",
                estimated_cost_per_call=self._estimate_cost(SONNET),
            )

        # Default to Haiku (save money)
        self._track(HAIKU)
        return RouteDecision(
            model=self.default_model,
            reason="Default → Haiku (cost optimization)",
            estimated_cost_per_call=self._estimate_cost(self.default_model),
        )

    def _track(self, model: str):
        key = "haiku" if model == HAIKU else "sonnet"
        self._stats[key] += 1

    def _estimate_cost(self, model: str) -> float:
        """Rough cost estimate per call (assumes ~2K input, ~1K output tokens)."""
        p = PRICING.get(model, PRICING[HAIKU])
        return (2000 * p["input"] + 1000 * p["output"]) / 1_000_000

    def get_stats(self) -> dict:
        total = self._stats["haiku"] + self._stats["sonnet"]
        haiku_pct = self._stats["haiku"] / total * 100 if total > 0 else 0
        return {
            "haiku_calls": self._stats["haiku"],
            "sonnet_calls": self._stats["sonnet"],
            "total_calls": total,
            "haiku_pct": f"{haiku_pct:.0f}%",
            "estimated_savings": f"~{haiku_pct * 0.7:.0f}% vs all-Sonnet",
        }

    def get_telegram_summary(self) -> str:
        s = self.get_stats()
        return (
            f"🔀 *Model Router*\n"
            f"Haiku: {s['haiku_calls']} ({s['haiku_pct']}) | "
            f"Sonnet: {s['sonnet_calls']}\n"
            f"Savings: {s['estimated_savings']}"
        )
