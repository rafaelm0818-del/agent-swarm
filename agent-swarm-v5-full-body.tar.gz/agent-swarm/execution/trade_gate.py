"""
Trade Gate — Human-in-the-Loop Approval System

Before real money touches the market, you approve it via Telegram.

Flow:
  Strategy signals entry → Execution Engine → Trade Gate → [waits for /approve] → Execute
                                                         → [/reject or timeout] → Cancel

Three modes:
  PAPER:      No gate needed. All trades auto-execute on paper.
  SUPERVISED: ALL trades require /approve via Telegram. Default for micro-live.
  THRESHOLD:  Trades under $X auto-execute. Above $X require approval. For semi-autonomous.
  AUTONOMOUS: No gate. All trades auto-execute. Only after proven track record.

The gate stores pending trades with full context so you can make informed decisions
from your phone in 5 seconds.
"""
import time
import asyncio
import logging
from dataclasses import dataclass, field
from typing import Optional, Callable, Awaitable
from enum import Enum

logger = logging.getLogger("TradeGate")


class GateMode(str, Enum):
    PAPER = "paper"               # No gate, paper trades
    SUPERVISED = "supervised"     # All trades need approval
    THRESHOLD = "threshold"       # Auto-execute below threshold
    AUTONOMOUS = "autonomous"     # No gate, live trades


@dataclass
class PendingTrade:
    """A trade waiting for human approval."""
    id: str
    strategy_id: str
    strategy_name: str
    symbol: str
    market: str
    side: str           # "buy" or "sell"
    quantity: float
    entry_price: float
    stop_loss: float
    take_profit: float
    position_usd: float
    risk_usd: float     # Max loss if stop loss hit
    signal_confidence: float
    reasoning: str
    
    # State
    status: str = "pending"  # pending, approved, rejected, expired
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0    # Auto-reject after this time
    decided_at: float = 0
    decided_by: str = ""     # "human", "auto", "timeout"

    def to_telegram(self) -> str:
        """Format for Telegram approval message."""
        risk_pct = (self.risk_usd / self.position_usd * 100) if self.position_usd > 0 else 0
        pnl_icon = "🟢" if self.side == "buy" else "🔴"
        
        lines = [
            f"🔔 *TRADE PROPOSAL* #{self.id[-6:]}\n",
            f"{pnl_icon} *{self.side.upper()} {self.quantity} {self.symbol}*",
            f"Market: {self.market}",
            f"Strategy: {self.strategy_name}",
            f"Confidence: {self.signal_confidence:.0%}\n",
            f"Entry: ${self.entry_price:,.4f}",
            f"Stop Loss: ${self.stop_loss:,.4f}",
            f"Take Profit: ${self.take_profit:,.4f}\n",
            f"Position: ${self.position_usd:,.2f}",
            f"Max Risk: ${self.risk_usd:,.2f} ({risk_pct:.1f}%)\n",
            f"Reason: _{self.reasoning[:150]}_\n",
            f"⏱ Expires in {int((self.expires_at - time.time()) / 60)}m\n",
            f"`/approve {self.id}`",
            f"`/reject {self.id}`",
        ]
        return "\n".join(lines)


class TradeGate:
    """
    Controls whether trades execute automatically or require human approval.
    
    Usage:
        gate = TradeGate(mode=GateMode.SUPERVISED, notify_fn=send_telegram)
        
        # In execution engine:
        approved = await gate.request_approval(trade_details)
        if approved:
            execute_trade()
        else:
            cancel_trade()
    """

    def __init__(
        self,
        mode: GateMode = GateMode.PAPER,
        auto_threshold_usd: float = 500.0,
        approval_timeout_seconds: int = 300,  # 5 minutes
        notify_fn: Optional[Callable] = None,
    ):
        self.mode = mode
        self.auto_threshold_usd = auto_threshold_usd
        self.approval_timeout_seconds = approval_timeout_seconds
        self.notify = notify_fn
        
        self.pending: dict[str, PendingTrade] = {}
        self._approval_events: dict[str, asyncio.Event] = {}
        
        # Stats
        self._stats = {
            "proposed": 0,
            "approved": 0,
            "rejected": 0,
            "auto_approved": 0,
            "expired": 0,
        }

    async def request_approval(
        self,
        trade_id: str,
        strategy_id: str,
        strategy_name: str,
        symbol: str,
        market: str,
        side: str,
        quantity: float,
        entry_price: float,
        stop_loss: float = 0,
        take_profit: float = 0,
        signal_confidence: float = 0.5,
        reasoning: str = "",
    ) -> bool:
        """
        Request approval for a trade. Returns True if approved.
        
        In PAPER/AUTONOMOUS mode: always returns True immediately.
        In SUPERVISED mode: waits for human /approve or timeout.
        In THRESHOLD mode: auto-approves below threshold, waits above.
        """
        position_usd = quantity * entry_price
        risk_usd = abs(entry_price - stop_loss) * quantity if stop_loss > 0 else position_usd * 0.05

        self._stats["proposed"] += 1

        # ── PAPER mode: always approve ──
        if self.mode == GateMode.PAPER:
            self._stats["auto_approved"] += 1
            return True

        # ── AUTONOMOUS mode: always approve ──
        if self.mode == GateMode.AUTONOMOUS:
            self._stats["auto_approved"] += 1
            logger.info(f"Auto-approved: {side} {quantity} {symbol} (${position_usd:,.2f})")
            return True

        # ── THRESHOLD mode: auto-approve below threshold ──
        if self.mode == GateMode.THRESHOLD and position_usd <= self.auto_threshold_usd:
            self._stats["auto_approved"] += 1
            logger.info(f"Auto-approved (below ${self.auto_threshold_usd}): {side} {quantity} {symbol}")
            if self.notify:
                await self.notify(
                    f"✅ *Auto-approved* (${position_usd:,.0f} < ${self.auto_threshold_usd:,.0f} threshold)\n"
                    f"{side.upper()} {quantity} {symbol} @ ${entry_price:,.4f}"
                )
            return True

        # ── Need human approval ──
        pending = PendingTrade(
            id=trade_id,
            strategy_id=strategy_id,
            strategy_name=strategy_name,
            symbol=symbol,
            market=market,
            side=side,
            quantity=quantity,
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            position_usd=position_usd,
            risk_usd=risk_usd,
            signal_confidence=signal_confidence,
            reasoning=reasoning,
            expires_at=time.time() + self.approval_timeout_seconds,
        )

        self.pending[trade_id] = pending
        event = asyncio.Event()
        self._approval_events[trade_id] = event

        # Send notification
        if self.notify:
            await self.notify(pending.to_telegram())

        logger.info(f"Awaiting approval: {side} {quantity} {symbol} (${position_usd:,.2f})")

        # Wait for approval or timeout
        try:
            await asyncio.wait_for(event.wait(), timeout=self.approval_timeout_seconds)
        except asyncio.TimeoutError:
            pending.status = "expired"
            pending.decided_at = time.time()
            pending.decided_by = "timeout"
            self._stats["expired"] += 1

            if self.notify:
                await self.notify(
                    f"⏰ *Trade Expired* #{trade_id[-6:]}\n"
                    f"{side.upper()} {symbol} — no response in "
                    f"{self.approval_timeout_seconds // 60}m"
                )
            self._cleanup(trade_id)
            return False

        # Check result
        result = pending.status == "approved"
        self._cleanup(trade_id)
        return result

    def approve(self, trade_id: str) -> Optional[PendingTrade]:
        """Called when user sends /approve <id>."""
        # Support partial ID matching
        matched_id = self._resolve_id(trade_id)
        if not matched_id:
            return None

        pending = self.pending.get(matched_id)
        if not pending or pending.status != "pending":
            return None

        pending.status = "approved"
        pending.decided_at = time.time()
        pending.decided_by = "human"
        self._stats["approved"] += 1

        event = self._approval_events.get(matched_id)
        if event:
            event.set()

        logger.info(f"Approved: {pending.side} {pending.quantity} {pending.symbol}")
        return pending

    def reject(self, trade_id: str, reason: str = "") -> Optional[PendingTrade]:
        """Called when user sends /reject <id>."""
        matched_id = self._resolve_id(trade_id)
        if not matched_id:
            return None

        pending = self.pending.get(matched_id)
        if not pending or pending.status != "pending":
            return None

        pending.status = "rejected"
        pending.decided_at = time.time()
        pending.decided_by = "human"
        pending.reasoning += f" | REJECTED: {reason}" if reason else ""
        self._stats["rejected"] += 1

        event = self._approval_events.get(matched_id)
        if event:
            event.set()

        logger.info(f"Rejected: {pending.side} {pending.quantity} {pending.symbol}")
        return pending

    def _resolve_id(self, partial_id: str) -> Optional[str]:
        """Match full or partial trade ID."""
        if partial_id in self.pending:
            return partial_id
        # Try matching last 6 chars
        for full_id in self.pending:
            if full_id.endswith(partial_id) or partial_id in full_id:
                return full_id
        return None

    def _cleanup(self, trade_id: str):
        """Remove resolved trade from pending."""
        self.pending.pop(trade_id, None)
        self._approval_events.pop(trade_id, None)

    def get_pending(self) -> list[PendingTrade]:
        """Get all pending trades."""
        return [p for p in self.pending.values() if p.status == "pending"]

    def set_mode(self, mode: str, threshold: float = None):
        """Change gate mode. Returns previous mode."""
        prev = self.mode
        self.mode = GateMode(mode)
        if threshold is not None:
            self.auto_threshold_usd = threshold
        logger.info(f"Gate mode: {prev} → {self.mode}")
        return prev

    def get_stats(self) -> dict:
        return {
            **self._stats,
            "mode": self.mode.value,
            "threshold": self.auto_threshold_usd,
            "timeout": self.approval_timeout_seconds,
            "pending_count": len(self.get_pending()),
        }

    def get_telegram_summary(self) -> str:
        s = self.get_stats()
        mode_icons = {
            "paper": "📝", "supervised": "👁️",
            "threshold": "📊", "autonomous": "🤖",
        }
        icon = mode_icons.get(s["mode"], "❓")

        lines = [
            f"🚦 *Trade Gate* {icon} {s['mode'].upper()}\n",
            f"Proposed: {s['proposed']} | Approved: {s['approved']} | "
            f"Rejected: {s['rejected']}",
            f"Auto: {s['auto_approved']} | Expired: {s['expired']}",
        ]

        if s["mode"] == "threshold":
            lines.append(f"Auto-approve below: ${s['threshold']:,.0f}")

        pending = self.get_pending()
        if pending:
            lines.append(f"\n⏳ *Pending ({len(pending)}):*")
            for p in pending:
                remaining = int((p.expires_at - time.time()) / 60)
                lines.append(
                    f"  #{p.id[-6:]} {p.side.upper()} {p.symbol} "
                    f"${p.position_usd:,.0f} ({remaining}m left)"
                )

        return "\n".join(lines)
