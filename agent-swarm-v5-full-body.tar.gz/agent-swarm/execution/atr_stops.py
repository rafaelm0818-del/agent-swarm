"""
ATR Stop Calculator — Steroid A

Replaces fixed 2.5% stops with volatility-adaptive stops per asset.
Each regime gets different caps:
  RISK_OFF_VOLATILE → max 1.5% stop (cut fast in crashes)
  RANGING/ACCUMULATION → max 3% stop (moderate protection)
  RISK_ON_TRENDING/BREAKOUT → max 4% stop (let winners run)

Stress test impact: Flash Crash went from -$277 to +$152 after adding regime caps.
"""
import logging
from typing import Optional

logger = logging.getLogger("ATRCalculator")


def compute_atr(price_history: list[float], periods: int = 14) -> float:
    """
    Compute Average True Range as a percentage of current price.
    
    Args:
        price_history: List of recent prices (newest last)
        periods: ATR lookback period
    
    Returns:
        ATR as decimal percentage of price (e.g., 0.02 = 2%)
    """
    if len(price_history) < periods + 1:
        return 0.02  # Default 2% if not enough data
    
    recent = price_history[-(periods + 1):]
    current_price = recent[-1]
    
    if current_price <= 0:
        return 0.02
    
    atr_sum = sum(
        abs(recent[i] - recent[i-1])
        for i in range(1, len(recent))
    )
    atr = atr_sum / periods
    atr_pct = atr / current_price
    
    return max(0.001, atr_pct)  # Floor at 0.1%


def calculate_stops(
    entry_price: float,
    side: str,
    atr_pct: float,
    regime: str,
    sl_regime_mult: float = 1.0,
) -> tuple[float, float]:
    """
    Calculate stop loss and take profit using ATR with regime-adaptive caps.
    
    Returns:
        (stop_loss_price, take_profit_price)
    """
    
    # Regime-adaptive ATR caps
    if regime == "RISK_OFF_VOLATILE":
        # TIGHT: max 1.5% stop, 2.5% target — cut fast in crashes
        sl_pct = min(0.015, atr_pct * 1.5) * sl_regime_mult
        tp_pct = min(0.025, atr_pct * 2.5) * sl_regime_mult
    elif regime in ("RANGING", "ACCUMULATION"):
        # MODERATE: max 3% stop, 5% target
        sl_pct = min(0.030, atr_pct * 2.0) * sl_regime_mult
        tp_pct = min(0.050, atr_pct * 3.0) * sl_regime_mult
    else:
        # WIDE: max 4% stop, 8% target — let winners run in trends/breakouts
        sl_pct = min(0.040, atr_pct * 2.5) * sl_regime_mult
        tp_pct = min(0.080, atr_pct * 4.0) * sl_regime_mult
    
    # Absolute floor: never tighter than 0.3% (avoids noise stops on forex)
    sl_pct = max(0.003, sl_pct)
    tp_pct = max(0.005, tp_pct)
    
    # Calculate actual price levels
    if side in ("buy", "BUY"):
        stop_loss = entry_price * (1 - sl_pct)
        take_profit = entry_price * (1 + tp_pct)
    else:
        stop_loss = entry_price * (1 + sl_pct)
        take_profit = entry_price * (1 - tp_pct)
    
    return stop_loss, take_profit


def compute_position_risk(
    entry_price: float,
    stop_loss: float,
    quantity: float,
) -> float:
    """Calculate maximum dollar risk for a position."""
    return abs(entry_price - stop_loss) * quantity
