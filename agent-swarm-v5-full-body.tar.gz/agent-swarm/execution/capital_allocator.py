"""
Capital Allocator - The Heart

Pumps capital through the system intelligently.
Decides how much money each strategy gets based on:

  1. Kelly Criterion      - optimal bet sizing from win rate + payoff ratio
  2. Correlation Matrix   - reduce allocation when strategies are correlated
  3. Risk Parity          - equalize risk contribution across strategies
  4. Performance Momentum - allocate more to recently profitable strategies
  5. Regime Adjustment    - scale total deployment by regime profile

This replaces the static "25% max per strategy" with dynamic,
mathematically-grounded allocation.
"""
import math
import json
import time
import logging
from typing import Optional
from dataclasses import dataclass, field

logger = logging.getLogger("CapitalAllocator")


@dataclass
class StrategyAllocation:
    """Allocation decision for a single strategy."""
    strategy_id: str
    strategy_name: str
    raw_kelly: float = 0.0         # Kelly criterion suggestion
    correlation_adj: float = 1.0   # Correlation penalty (0-1)
    momentum_adj: float = 1.0      # Performance momentum (0.5-1.5)
    regime_adj: float = 1.0        # Regime multiplier
    final_allocation: float = 0.0  # Final % of capital
    dollar_amount: float = 0.0     # Actual USD
    reasoning: str = ""


class CapitalAllocator:
    """
    Dynamic capital allocation engine.
    """

    def __init__(self, total_capital: float, max_per_strategy: float = 0.25,
                 max_total_deployed: float = 0.80, kelly_fraction: float = 0.5):
        self.total_capital = total_capital
        self.max_per_strategy = max_per_strategy  # Hard cap per strategy
        self.max_total_deployed = max_total_deployed
        self.kelly_fraction = kelly_fraction  # Half-Kelly for safety
        
        self.allocations: dict[str, StrategyAllocation] = {}
        self._correlation_matrix: dict[tuple, float] = {}

    # ── Kelly Criterion ─────────────────────────────────────────

    def kelly_criterion(self, win_rate: float, avg_win: float, avg_loss: float) -> float:
        """
        Calculate Kelly fraction: f* = (p * b - q) / b
        where p = win probability, q = loss probability, b = win/loss ratio
        
        Returns fraction of capital to risk (0.0 - 1.0).
        We use half-Kelly for safety.
        """
        if avg_loss == 0 or win_rate <= 0 or win_rate >= 1:
            return 0.0

        p = win_rate
        q = 1 - win_rate
        b = abs(avg_win / avg_loss)

        kelly = (p * b - q) / b

        # Cap at reasonable levels and apply fraction
        kelly = max(0.0, min(kelly, 0.5))  # Never suggest more than 50%
        return kelly * self.kelly_fraction

    # ── Correlation Adjustment ──────────────────────────────────

    def estimate_correlation(self, strategy_a: dict, strategy_b: dict) -> float:
        """
        Estimate correlation between two strategies using:
        - Stress-tested correlation map (Steroid B) for cross-asset correlations
        - Asset overlap
        - Timeframe similarity
        - Strategy type similarity
        
        Returns 0.0 (uncorrelated) to 1.0 (perfectly correlated).
        """
        score = 0.0

        assets_a = set(strategy_a.get("assets", []))
        assets_b = set(strategy_b.get("assets", []))
        
        if assets_a and assets_b:
            # Direct overlap (same assets)
            overlap = len(assets_a & assets_b) / max(len(assets_a | assets_b), 1)
            score += overlap * 0.4
            
            # ══ Steroid B: Use stress-tested correlation map ══
            # Even non-overlapping assets may be highly correlated (e.g., BTC-ETH: 0.92)
            try:
                from config.markets import get_correlation, CORRELATION_BLOCK_THRESHOLD
                max_cross_corr = 0.0
                for sym_a in assets_a:
                    for sym_b in assets_b:
                        if sym_a != sym_b:
                            c = get_correlation(sym_a, sym_b)
                            max_cross_corr = max(max_cross_corr, abs(c))
                score += max_cross_corr * 0.3  # 30% weight from market correlation
            except ImportError:
                # Fallback: just use overlap
                score += overlap * 0.1

        # Same timeframe
        if strategy_a.get("timeframe") == strategy_b.get("timeframe"):
            score += 0.15

        # Same direction/hypothesis
        hyp_a = strategy_a.get("hypothesis", "").lower()
        hyp_b = strategy_b.get("hypothesis", "").lower()
        common_words = {"momentum", "breakout", "mean_reversion", "trend", "range", "scalp"}
        type_a = {w for w in common_words if w in hyp_a}
        type_b = {w for w in common_words if w in hyp_b}
        if type_a and type_b:
            type_overlap = len(type_a & type_b) / max(len(type_a | type_b), 1)
            score += type_overlap * 0.15

        return min(1.0, score)
    
    def should_block_correlated(self, symbol: str, side: str, open_positions: list) -> bool:
        """
        Steroid B: Block duplicate correlated exposure.
        Before opening a position, check if we already have a correlated position
        in the same direction. Returns True if trade should be blocked.
        """
        try:
            from config.markets import get_correlation, CORRELATION_BLOCK_THRESHOLD
        except ImportError:
            return False
        
        for pos in open_positions:
            if pos.get("side") != side:
                continue  # Opposite direction = hedge, not duplicate
            corr = get_correlation(symbol, pos.get("symbol", ""))
            if corr >= CORRELATION_BLOCK_THRESHOLD:
                logger.info(
                    f"CORR FILTER: Blocking {symbol} ({side}) — "
                    f"correlated {corr:.2f} with open {pos['symbol']}"
                )
                return True
        return False

    def correlation_penalty(self, strategy: dict, all_strategies: list[dict]) -> float:
        """
        Calculate allocation penalty based on correlation with other active strategies.
        High correlation with existing positions → reduce allocation.
        Returns multiplier (0.3 - 1.0).
        """
        if not all_strategies:
            return 1.0

        max_corr = 0.0
        avg_corr = 0.0
        count = 0

        for other in all_strategies:
            if other.get("id") == strategy.get("id"):
                continue
            corr = self.estimate_correlation(strategy, other)
            max_corr = max(max_corr, corr)
            avg_corr += corr
            count += 1

        avg_corr = avg_corr / max(count, 1)

        # Penalty: high correlation → lower allocation
        # 0 correlation → 1.0 multiplier (no penalty)
        # 0.8+ correlation → 0.3 multiplier (heavy penalty)
        penalty = 1.0 - (max_corr * 0.7)
        return max(0.3, penalty)

    # ── Performance Momentum ────────────────────────────────────

    def momentum_score(self, strategy: dict) -> float:
        """
        Adjust allocation based on recent performance.
        Winning strategies get more, losing get less.
        Returns multiplier (0.5 - 1.5).
        """
        pnl = strategy.get("live_pnl", 0)
        trades = strategy.get("live_trades", 0)

        if trades < 5:
            return 1.0  # Not enough data

        avg_pnl = pnl / trades
        win_rate = strategy.get("win_rate", 0.5)

        # Scale: -0.5 to +0.5 around 1.0
        if avg_pnl > 0:
            momentum = 1.0 + min(0.5, avg_pnl / 100)  # Cap at 1.5x
        else:
            momentum = 1.0 + max(-0.5, avg_pnl / 100)  # Floor at 0.5x

        # Boost/penalize based on win rate deviation from 50%
        wr_adj = (win_rate - 0.5) * 0.5  # -0.25 to +0.25
        momentum += wr_adj

        return max(0.5, min(1.5, momentum))

    # ── Main Allocation Engine ──────────────────────────────────

    def allocate(self, strategies: list[dict], regime_max_deployed: float = None) -> dict[str, StrategyAllocation]:
        """
        Calculate optimal allocation for all active strategies.
        
        Input: list of strategy dicts with:
          id, name, win_rate, profit_factor, sharpe_ratio,
          assets, timeframe, hypothesis, live_pnl, live_trades
        
        Returns: dict of strategy_id → StrategyAllocation
        """
        max_deployed = regime_max_deployed or self.max_total_deployed
        available_capital = self.total_capital * max_deployed
        
        allocations = {}

        for strategy in strategies:
            sid = strategy.get("id", "")
            win_rate = strategy.get("win_rate", 0.5)
            pf = strategy.get("profit_factor", 1.0)

            # Step 1: Kelly criterion
            avg_win = pf  # Approximate: profit factor ≈ avg_win/avg_loss
            avg_loss = 1.0
            raw_kelly = self.kelly_criterion(win_rate, avg_win, avg_loss)

            # Step 2: Correlation adjustment
            corr_adj = self.correlation_penalty(strategy, strategies)

            # Step 3: Performance momentum
            mom_adj = self.momentum_score(strategy)

            # Step 4: Combined allocation
            combined = raw_kelly * corr_adj * mom_adj

            # Step 5: Apply hard cap
            combined = min(combined, self.max_per_strategy)

            # Step 6: Sharpe-based quality adjustment
            sharpe = strategy.get("sharpe_ratio", 0)
            if sharpe > 2.0:
                combined *= 1.15  # Bonus for high Sharpe
            elif sharpe < 1.0:
                combined *= 0.75  # Penalty for low Sharpe

            combined = min(combined, self.max_per_strategy)
            dollar_amount = combined * self.total_capital

            alloc = StrategyAllocation(
                strategy_id=sid,
                strategy_name=strategy.get("name", ""),
                raw_kelly=round(raw_kelly, 4),
                correlation_adj=round(corr_adj, 3),
                momentum_adj=round(mom_adj, 3),
                final_allocation=round(combined, 4),
                dollar_amount=round(dollar_amount, 2),
                reasoning=(
                    f"Kelly: {raw_kelly:.1%} × Corr: {corr_adj:.2f} × "
                    f"Mom: {mom_adj:.2f} = {combined:.1%} "
                    f"(${dollar_amount:,.0f})"
                ),
            )
            allocations[sid] = alloc

        # Step 7: Normalize if total exceeds budget
        total_allocated = sum(a.final_allocation for a in allocations.values())
        if total_allocated > max_deployed:
            scale = max_deployed / total_allocated
            for alloc in allocations.values():
                alloc.final_allocation *= scale
                alloc.dollar_amount = alloc.final_allocation * self.total_capital
                alloc.reasoning += f" [scaled {scale:.2f}x to fit budget]"

        self.allocations = allocations
        return allocations

    def get_rebalance_actions(self, current_positions: dict[str, float]) -> list[dict]:
        """
        Compare current positions to target allocations.
        Returns list of actions needed to rebalance.
        
        current_positions: {strategy_id: current_dollar_exposure}
        """
        actions = []

        for sid, alloc in self.allocations.items():
            current = current_positions.get(sid, 0)
            target = alloc.dollar_amount
            diff = target - current

            if abs(diff) < 50:  # Skip tiny adjustments
                continue

            actions.append({
                "strategy_id": sid,
                "strategy_name": alloc.strategy_name,
                "action": "increase" if diff > 0 else "decrease",
                "current": current,
                "target": target,
                "change": diff,
                "reason": alloc.reasoning,
            })

        return sorted(actions, key=lambda a: abs(a["change"]), reverse=True)

    def update_capital(self, new_total: float):
        """Update total capital (e.g., after deposits/withdrawals/PnL)."""
        self.total_capital = new_total

    def get_telegram_summary(self) -> str:
        if not self.allocations:
            return "❤️ *Capital Allocator*: No active allocations."

        total_allocated = sum(a.final_allocation for a in self.allocations.values())
        total_dollars = sum(a.dollar_amount for a in self.allocations.values())

        lines = [
            f"❤️ *Capital Allocator*\n",
            f"Total capital: ${self.total_capital:,.2f}",
            f"Allocated: {total_allocated:.1%} (${total_dollars:,.2f})",
            f"Cash reserve: ${self.total_capital - total_dollars:,.2f}\n",
            "*Allocations:*",
        ]

        for alloc in sorted(self.allocations.values(), key=lambda a: -a.final_allocation):
            bar = "█" * int(alloc.final_allocation * 20) + "░" * (5 - int(alloc.final_allocation * 20))
            lines.append(
                f"  [{bar}] {alloc.strategy_name}\n"
                f"    {alloc.final_allocation:.1%} (${alloc.dollar_amount:,.0f}) "
                f"Kelly:{alloc.raw_kelly:.1%} Corr:{alloc.correlation_adj:.2f} Mom:{alloc.momentum_adj:.2f}"
            )

        return "\n".join(lines)
