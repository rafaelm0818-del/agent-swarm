# Tools module - extend with custom tool implementations
