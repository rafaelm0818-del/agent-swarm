"""
API Cost Tracker - The Lungs

Wraps every Claude API call to track token usage and cost.
Also enforces daily budget limits to prevent runaway spending.

Pricing (Sonnet 4):
  Input:  $3.00 per million tokens
  Output: $15.00 per million tokens
"""
import time
import logging
from typing import Optional
from database.models import Database

logger = logging.getLogger("CostTracker")

# Claude pricing per million tokens (update as needed)
PRICING = {
    "claude-sonnet-4-20250514": {"input": 3.00, "output": 15.00},
    "claude-opus-4-20250514": {"input": 15.00, "output": 75.00},
    "claude-haiku-4-5-20251001": {"input": 0.80, "output": 4.00},
    # Fallback
    "default": {"input": 3.00, "output": 15.00},
}


class CostTracker:
    """
    Tracks API costs across all agents and enforces budget limits.
    """

    def __init__(self, db: Database, daily_budget: float = 25.0):
        self.db = db
        self.daily_budget = daily_budget  # USD per day
        self._session_cost = 0.0
        self._session_start = time.time()

    def record(self, agent: str, model: str,
               input_tokens: int, output_tokens: int,
               task_name: str = ""):
        """Record an API call and its cost."""
        pricing = PRICING.get(model, PRICING["default"])
        cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000
        
        self._session_cost += cost
        
        self.db.record_api_usage(
            agent=agent,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost,
            task_name=task_name,
        )
        return cost

    def check_budget(self) -> tuple[bool, float]:
        """Check if we're within daily budget. Returns (within_budget, remaining)."""
        daily_cost = self.db.get_daily_cost()
        remaining = self.daily_budget - daily_cost
        return remaining > 0, remaining

    def get_summary(self, hours: int = 24) -> dict:
        """Get cost summary."""
        costs = self.db.get_api_costs(hours=hours)
        costs["daily_budget"] = self.daily_budget
        costs["session_cost"] = round(self._session_cost, 4)
        within, remaining = self.check_budget()
        costs["within_budget"] = within
        costs["remaining_budget"] = round(remaining, 4)
        return costs

    def get_telegram_summary(self) -> str:
        """Telegram-friendly cost report."""
        summary = self.get_summary(hours=24)
        within, remaining = summary["within_budget"], summary["remaining_budget"]
        
        budget_icon = "🟢" if remaining > self.daily_budget * 0.5 else "🟡" if within else "🔴"
        
        lines = [
            f"🫁 *API Costs (24h)*\n",
            f"{budget_icon} Budget: ${summary['total_cost_usd']:.2f} / ${self.daily_budget:.2f} "
            f"(${remaining:.2f} remaining)",
        ]
        
        for agent_data in summary.get("by_agent", []):
            lines.append(
                f"  {agent_data['agent']}: ${agent_data['total_cost']:.3f} "
                f"({agent_data['call_count']} calls, "
                f"{agent_data['total_input'] + agent_data['total_output']:,} tokens)"
            )
        
        lines.append(f"\nSession cost: ${summary['session_cost']:.3f}")
        
        return "\n".join(lines)
