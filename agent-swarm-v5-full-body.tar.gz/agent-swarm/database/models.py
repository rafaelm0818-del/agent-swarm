"""
Database Models - Long-Term Memory

Every important event, decision, trade, and metric gets persisted here.
Uses SQLite by default (zero config), can swap to PostgreSQL for production.

Tables:
  strategies       - Full strategy lifecycle with all backtest/live data
  trades           - Every trade placed, filled, cancelled
  signals          - Screener signal history
  watchlist_assets  - Watchlist state with change history
  audit_log        - Every agent decision with reasoning
  performance      - Hourly/daily P&L snapshots
  api_usage        - Token/cost tracking per agent (the "lungs")
  fund_state       - Portfolio state snapshots
"""
import os
import json
import time
import sqlite3
import logging
from datetime import datetime, timezone
from dataclasses import dataclass, asdict
from typing import Optional
from contextlib import contextmanager

logger = logging.getLogger("Database")

DB_PATH = os.getenv("DB_PATH", "./data/fund.db")


def _ensure_dir(path: str):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


class Database:
    """
    SQLite-backed persistent storage for the entire fund.
    
    Thread-safe via connection-per-call pattern.
    For production with multiple workers, swap to PostgreSQL.
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        _ensure_dir(db_path)
        self._init_db()
        logger.info(f"Database initialized at {db_path}")

    @contextmanager
    def _conn(self):
        """Get a database connection with WAL mode for concurrent reads."""
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self):
        """Create all tables if they don't exist."""
        with self._conn() as conn:
            conn.executescript(SCHEMA)
            logger.info("Database schema initialized")

    # ════════════════════════════════════════════════════════════
    #  STRATEGIES
    # ════════════════════════════════════════════════════════════

    def save_strategy(self, strategy_data: dict) -> str:
        """Insert or update a strategy."""
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO strategies (
                    id, name, status, description, hypothesis, 
                    assets, market, timeframe, market_regime,
                    sharpe_ratio, max_drawdown, win_rate, profit_factor, total_trades,
                    backtest_results, strategy_code, config_json,
                    max_position_size, max_daily_loss, stop_loss_pct, take_profit_pct,
                    live_pnl, live_trades, paper_trade_days,
                    live_start_date, created_at, updated_at
                ) VALUES (
                    :id, :name, :status, :description, :hypothesis,
                    :assets, :market, :timeframe, :market_regime,
                    :sharpe_ratio, :max_drawdown, :win_rate, :profit_factor, :total_trades,
                    :backtest_results, :strategy_code, :config_json,
                    :max_position_size, :max_daily_loss, :stop_loss_pct, :take_profit_pct,
                    :live_pnl, :live_trades, :paper_trade_days,
                    :live_start_date, :created_at, :updated_at
                )
                ON CONFLICT(id) DO UPDATE SET
                    status=excluded.status, sharpe_ratio=excluded.sharpe_ratio,
                    max_drawdown=excluded.max_drawdown, win_rate=excluded.win_rate,
                    profit_factor=excluded.profit_factor, total_trades=excluded.total_trades,
                    backtest_results=excluded.backtest_results, strategy_code=excluded.strategy_code,
                    max_position_size=excluded.max_position_size, max_daily_loss=excluded.max_daily_loss,
                    stop_loss_pct=excluded.stop_loss_pct, take_profit_pct=excluded.take_profit_pct,
                    live_pnl=excluded.live_pnl, live_trades=excluded.live_trades,
                    paper_trade_days=excluded.paper_trade_days,
                    updated_at=excluded.updated_at
            """, {
                "id": strategy_data.get("id", ""),
                "name": strategy_data.get("name", ""),
                "status": strategy_data.get("status", "researching"),
                "description": strategy_data.get("description", ""),
                "hypothesis": strategy_data.get("hypothesis", ""),
                "assets": json.dumps(strategy_data.get("assets", [])),
                "market": strategy_data.get("market", "crypto"),
                "timeframe": strategy_data.get("timeframe", ""),
                "market_regime": strategy_data.get("market_regime", ""),
                "sharpe_ratio": strategy_data.get("sharpe_ratio", 0),
                "max_drawdown": strategy_data.get("max_drawdown", 0),
                "win_rate": strategy_data.get("win_rate", 0),
                "profit_factor": strategy_data.get("profit_factor", 0),
                "total_trades": strategy_data.get("total_trades", 0),
                "backtest_results": json.dumps(strategy_data.get("backtest_results", {})),
                "strategy_code": strategy_data.get("strategy_code", ""),
                "config_json": json.dumps(strategy_data.get("config_json", {})),
                "max_position_size": strategy_data.get("max_position_size", 0),
                "max_daily_loss": strategy_data.get("max_daily_loss", 0),
                "stop_loss_pct": strategy_data.get("stop_loss_pct", 0),
                "take_profit_pct": strategy_data.get("take_profit_pct", 0),
                "live_pnl": strategy_data.get("live_pnl", 0),
                "live_trades": strategy_data.get("live_trades", 0),
                "paper_trade_days": strategy_data.get("paper_trade_days", 0),
                "live_start_date": strategy_data.get("live_start_date", ""),
                "created_at": strategy_data.get("created_at", datetime.now(timezone.utc).isoformat()),
                "updated_at": datetime.now(timezone.utc).isoformat(),
            })
        return strategy_data.get("id", "")

    def get_strategy(self, strategy_id: str) -> Optional[dict]:
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM strategies WHERE id = ?", (strategy_id,)).fetchone()
            return self._row_to_dict(row) if row else None

    def get_strategies(self, status: str = None, limit: int = 50) -> list[dict]:
        with self._conn() as conn:
            if status:
                rows = conn.execute(
                    "SELECT * FROM strategies WHERE status = ? ORDER BY updated_at DESC LIMIT ?",
                    (status, limit)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM strategies ORDER BY updated_at DESC LIMIT ?",
                    (limit,)
                ).fetchall()
            return [self._row_to_dict(r) for r in rows]

    def get_strategy_stats(self) -> dict:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT status, COUNT(*) as cnt FROM strategies GROUP BY status"
            ).fetchall()
            stats = {r["status"]: r["cnt"] for r in rows}
            totals = conn.execute(
                "SELECT SUM(live_pnl) as total_pnl, SUM(live_trades) as total_trades FROM strategies WHERE status = 'live'"
            ).fetchone()
            return {
                "by_status": stats,
                "total_live_pnl": totals["total_pnl"] or 0 if totals else 0,
                "total_live_trades": totals["total_trades"] or 0 if totals else 0,
            }

    # ════════════════════════════════════════════════════════════
    #  TRADES
    # ════════════════════════════════════════════════════════════

    def record_trade(self, trade: dict) -> int:
        """Record a trade (open, close, or update)."""
        with self._conn() as conn:
            cursor = conn.execute("""
                INSERT INTO trades (
                    strategy_id, trade_type, side, symbol, market,
                    quantity, entry_price, exit_price, stop_loss, take_profit,
                    status, pnl, pnl_pct, fees,
                    order_id, exchange, signal_id,
                    opened_at, closed_at, metadata
                ) VALUES (
                    :strategy_id, :trade_type, :side, :symbol, :market,
                    :quantity, :entry_price, :exit_price, :stop_loss, :take_profit,
                    :status, :pnl, :pnl_pct, :fees,
                    :order_id, :exchange, :signal_id,
                    :opened_at, :closed_at, :metadata
                )
            """, {
                "strategy_id": trade.get("strategy_id", ""),
                "trade_type": trade.get("trade_type", "market"),
                "side": trade.get("side", "buy"),
                "symbol": trade.get("symbol", ""),
                "market": trade.get("market", "crypto"),
                "quantity": trade.get("quantity", 0),
                "entry_price": trade.get("entry_price", 0),
                "exit_price": trade.get("exit_price"),
                "stop_loss": trade.get("stop_loss"),
                "take_profit": trade.get("take_profit"),
                "status": trade.get("status", "pending"),
                "pnl": trade.get("pnl"),
                "pnl_pct": trade.get("pnl_pct"),
                "fees": trade.get("fees", 0),
                "order_id": trade.get("order_id", ""),
                "exchange": trade.get("exchange", ""),
                "signal_id": trade.get("signal_id", ""),
                "opened_at": trade.get("opened_at", datetime.now(timezone.utc).isoformat()),
                "closed_at": trade.get("closed_at"),
                "metadata": json.dumps(trade.get("metadata", {})),
            })
            return cursor.lastrowid

    def update_trade(self, trade_id: int, updates: dict):
        """Update trade fields (e.g., fill, close, PnL)."""
        allowed = ["status", "exit_price", "pnl", "pnl_pct", "fees", "closed_at", "order_id"]
        sets = []
        params = {"id": trade_id}
        for key in allowed:
            if key in updates:
                sets.append(f"{key} = :{key}")
                params[key] = updates[key]
        if not sets:
            return
        with self._conn() as conn:
            conn.execute(f"UPDATE trades SET {', '.join(sets)} WHERE id = :id", params)

    def get_trades(self, strategy_id: str = None, status: str = None, limit: int = 100) -> list[dict]:
        with self._conn() as conn:
            query = "SELECT * FROM trades WHERE 1=1"
            params = []
            if strategy_id:
                query += " AND strategy_id = ?"
                params.append(strategy_id)
            if status:
                query += " AND status = ?"
                params.append(status)
            query += " ORDER BY opened_at DESC LIMIT ?"
            params.append(limit)
            rows = conn.execute(query, params).fetchall()
            return [self._row_to_dict(r) for r in rows]

    def get_open_positions(self) -> list[dict]:
        """Get all currently open trades."""
        return self.get_trades(status="open")

    def get_trade_stats(self, days: int = 30) -> dict:
        """Get trading statistics."""
        with self._conn() as conn:
            cutoff = datetime.now(timezone.utc).isoformat()[:10]  # simplify
            rows = conn.execute("""
                SELECT 
                    COUNT(*) as total_trades,
                    SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as winners,
                    SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as losers,
                    SUM(CASE WHEN pnl = 0 OR pnl IS NULL THEN 1 ELSE 0 END) as breakeven,
                    SUM(pnl) as total_pnl,
                    AVG(pnl) as avg_pnl,
                    MAX(pnl) as best_trade,
                    MIN(pnl) as worst_trade,
                    SUM(fees) as total_fees
                FROM trades WHERE status = 'closed'
            """).fetchone()
            return self._row_to_dict(rows) if rows else {}

    # ════════════════════════════════════════════════════════════
    #  SIGNALS
    # ════════════════════════════════════════════════════════════

    def record_signal(self, signal: dict):
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO signals (
                    signal_id, signal_type, asset, market, timeframe,
                    direction, strength, confidence, price_at_signal,
                    details, expires_at, consumed_by, created_at
                ) VALUES (
                    :signal_id, :signal_type, :asset, :market, :timeframe,
                    :direction, :strength, :confidence, :price_at_signal,
                    :details, :expires_at, :consumed_by, :created_at
                )
            """, {
                "signal_id": signal.get("signal_id", ""),
                "signal_type": signal.get("signal_type", ""),
                "asset": signal.get("asset", ""),
                "market": signal.get("market", "crypto"),
                "timeframe": signal.get("timeframe", ""),
                "direction": signal.get("direction", ""),
                "strength": signal.get("strength", 0),
                "confidence": signal.get("confidence", 0),
                "price_at_signal": signal.get("price_at_signal", 0),
                "details": json.dumps(signal.get("details", {})),
                "expires_at": signal.get("expires_at", 0),
                "consumed_by": json.dumps(signal.get("consumed_by", [])),
                "created_at": datetime.now(timezone.utc).isoformat(),
            })

    def get_signals(self, hours: int = 24, asset: str = None, limit: int = 100) -> list[dict]:
        with self._conn() as conn:
            query = "SELECT * FROM signals WHERE created_at > datetime('now', ?)"
            params = [f"-{hours} hours"]
            if asset:
                query += " AND asset = ?"
                params.append(asset.upper())
            query += " ORDER BY created_at DESC LIMIT ?"
            params.append(limit)
            rows = conn.execute(query, params).fetchall()
            return [self._row_to_dict(r) for r in rows]

    # ════════════════════════════════════════════════════════════
    #  AUDIT LOG
    # ════════════════════════════════════════════════════════════

    def log_audit(self, agent: str, action: str, details: str,
                  strategy_id: str = "", trade_id: int = None,
                  reasoning: str = "", data: dict = None):
        """Record an agent decision for audit trail."""
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO audit_log (
                    agent, action, details, reasoning,
                    strategy_id, trade_id, data, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                agent, action, details, reasoning,
                strategy_id, trade_id,
                json.dumps(data) if data else "{}",
                datetime.now(timezone.utc).isoformat(),
            ))

    def get_audit_log(self, agent: str = None, strategy_id: str = None,
                      limit: int = 50) -> list[dict]:
        with self._conn() as conn:
            query = "SELECT * FROM audit_log WHERE 1=1"
            params = []
            if agent:
                query += " AND agent = ?"
                params.append(agent)
            if strategy_id:
                query += " AND strategy_id = ?"
                params.append(strategy_id)
            query += " ORDER BY created_at DESC LIMIT ?"
            params.append(limit)
            rows = conn.execute(query, params).fetchall()
            return [self._row_to_dict(r) for r in rows]

    # ════════════════════════════════════════════════════════════
    #  PERFORMANCE SNAPSHOTS
    # ════════════════════════════════════════════════════════════

    def snapshot_performance(self, portfolio_state: dict):
        """Take a point-in-time snapshot of fund performance."""
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO performance (
                    total_capital, cash, deployed, total_pnl,
                    daily_pnl, weekly_pnl, open_positions,
                    active_strategies, snapshot_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                portfolio_state.get("total_capital", 0),
                portfolio_state.get("cash", 0),
                portfolio_state.get("deployed", 0),
                portfolio_state.get("total_pnl", 0),
                portfolio_state.get("daily_pnl", 0),
                portfolio_state.get("weekly_pnl", 0),
                portfolio_state.get("open_positions", 0),
                portfolio_state.get("active_strategies", 0),
                datetime.now(timezone.utc).isoformat(),
            ))

    def get_performance_history(self, hours: int = 168) -> list[dict]:
        """Get performance snapshots (default: last 7 days)."""
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT * FROM performance 
                WHERE snapshot_at > datetime('now', ?)
                ORDER BY snapshot_at ASC
            """, (f"-{hours} hours",)).fetchall()
            return [self._row_to_dict(r) for r in rows]

    # ════════════════════════════════════════════════════════════
    #  API USAGE / COST TRACKING (the "lungs")
    # ════════════════════════════════════════════════════════════

    def record_api_usage(self, agent: str, model: str,
                         input_tokens: int, output_tokens: int,
                         cost_usd: float, task_name: str = ""):
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO api_usage (
                    agent, model, input_tokens, output_tokens,
                    cost_usd, task_name, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                agent, model, input_tokens, output_tokens,
                cost_usd, task_name,
                datetime.now(timezone.utc).isoformat(),
            ))

    def get_api_costs(self, hours: int = 24) -> dict:
        """Get API usage and costs."""
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT 
                    agent,
                    SUM(input_tokens) as total_input,
                    SUM(output_tokens) as total_output,
                    SUM(cost_usd) as total_cost,
                    COUNT(*) as call_count
                FROM api_usage 
                WHERE created_at > datetime('now', ?)
                GROUP BY agent
            """, (f"-{hours} hours",)).fetchall()

            total = conn.execute("""
                SELECT SUM(cost_usd) as total FROM api_usage
                WHERE created_at > datetime('now', ?)
            """, (f"-{hours} hours",)).fetchone()

            return {
                "by_agent": [self._row_to_dict(r) for r in rows],
                "total_cost_usd": total["total"] or 0 if total else 0,
                "period_hours": hours,
            }

    def get_daily_cost(self) -> float:
        """Get today's total API cost."""
        with self._conn() as conn:
            row = conn.execute("""
                SELECT SUM(cost_usd) as cost FROM api_usage
                WHERE date(created_at) = date('now')
            """).fetchone()
            return row["cost"] or 0.0 if row else 0.0

    # ════════════════════════════════════════════════════════════
    #  FUND STATE
    # ════════════════════════════════════════════════════════════

    def save_fund_state(self, state: dict):
        """Save full fund state for recovery on restart."""
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO fund_state (state_json, saved_at)
                VALUES (?, ?)
            """, (json.dumps(state), datetime.now(timezone.utc).isoformat()))

    def load_fund_state(self) -> Optional[dict]:
        """Load most recent fund state."""
        with self._conn() as conn:
            row = conn.execute(
                "SELECT state_json FROM fund_state ORDER BY saved_at DESC LIMIT 1"
            ).fetchone()
            if row:
                return json.loads(row["state_json"])
            return None

    # ════════════════════════════════════════════════════════════
    #  HELPERS
    # ════════════════════════════════════════════════════════════

    def _row_to_dict(self, row) -> dict:
        if row is None:
            return {}
        d = dict(row)
        # Parse JSON fields back
        for key in ["assets", "backtest_results", "details", "consumed_by", "metadata", "data"]:
            if key in d and isinstance(d[key], str):
                try:
                    d[key] = json.loads(d[key])
                except (json.JSONDecodeError, TypeError):
                    pass
        return d

    def get_db_stats(self) -> dict:
        """Get database size and row counts."""
        with self._conn() as conn:
            tables = ["strategies", "trades", "signals", "audit_log", "performance", "api_usage"]
            counts = {}
            for table in tables:
                row = conn.execute(f"SELECT COUNT(*) as cnt FROM {table}").fetchone()
                counts[table] = row["cnt"] if row else 0

            db_size = os.path.getsize(self.db_path) if os.path.exists(self.db_path) else 0
            return {
                "tables": counts,
                "db_size_mb": round(db_size / 1024 / 1024, 2),
                "path": self.db_path,
            }


# ════════════════════════════════════════════════════════════════
#  SCHEMA
# ════════════════════════════════════════════════════════════════

SCHEMA = """
CREATE TABLE IF NOT EXISTS strategies (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'researching',
    description TEXT DEFAULT '',
    hypothesis TEXT DEFAULT '',
    assets TEXT DEFAULT '[]',
    market TEXT DEFAULT 'crypto',
    timeframe TEXT DEFAULT '',
    market_regime TEXT DEFAULT '',
    sharpe_ratio REAL DEFAULT 0,
    max_drawdown REAL DEFAULT 0,
    win_rate REAL DEFAULT 0,
    profit_factor REAL DEFAULT 0,
    total_trades INTEGER DEFAULT 0,
    backtest_results TEXT DEFAULT '{}',
    strategy_code TEXT DEFAULT '',
    config_json TEXT DEFAULT '{}',
    max_position_size REAL DEFAULT 0,
    max_daily_loss REAL DEFAULT 0,
    stop_loss_pct REAL DEFAULT 0,
    take_profit_pct REAL DEFAULT 0,
    live_pnl REAL DEFAULT 0,
    live_trades INTEGER DEFAULT 0,
    paper_trade_days INTEGER DEFAULT 0,
    live_start_date TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id TEXT NOT NULL,
    trade_type TEXT DEFAULT 'market',
    side TEXT NOT NULL,
    symbol TEXT NOT NULL,
    market TEXT DEFAULT 'crypto',
    quantity REAL NOT NULL,
    entry_price REAL NOT NULL,
    exit_price REAL,
    stop_loss REAL,
    take_profit REAL,
    status TEXT DEFAULT 'pending',
    pnl REAL,
    pnl_pct REAL,
    fees REAL DEFAULT 0,
    order_id TEXT DEFAULT '',
    exchange TEXT DEFAULT '',
    signal_id TEXT DEFAULT '',
    opened_at TEXT NOT NULL,
    closed_at TEXT,
    metadata TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signal_id TEXT NOT NULL,
    signal_type TEXT NOT NULL,
    asset TEXT NOT NULL,
    market TEXT DEFAULT 'crypto',
    timeframe TEXT DEFAULT '',
    direction TEXT DEFAULT '',
    strength REAL DEFAULT 0,
    confidence REAL DEFAULT 0,
    price_at_signal REAL DEFAULT 0,
    details TEXT DEFAULT '{}',
    expires_at REAL DEFAULT 0,
    consumed_by TEXT DEFAULT '[]',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent TEXT NOT NULL,
    action TEXT NOT NULL,
    details TEXT DEFAULT '',
    reasoning TEXT DEFAULT '',
    strategy_id TEXT DEFAULT '',
    trade_id INTEGER,
    data TEXT DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS performance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    total_capital REAL DEFAULT 0,
    cash REAL DEFAULT 0,
    deployed REAL DEFAULT 0,
    total_pnl REAL DEFAULT 0,
    daily_pnl REAL DEFAULT 0,
    weekly_pnl REAL DEFAULT 0,
    open_positions INTEGER DEFAULT 0,
    active_strategies INTEGER DEFAULT 0,
    snapshot_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS api_usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent TEXT NOT NULL,
    model TEXT DEFAULT '',
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    cost_usd REAL DEFAULT 0,
    task_name TEXT DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS fund_state (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    state_json TEXT NOT NULL,
    saved_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_trades_strategy ON trades(strategy_id);
CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_signals_asset ON signals(asset);
CREATE INDEX IF NOT EXISTS idx_signals_created ON signals(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_agent ON audit_log(agent);
CREATE INDEX IF NOT EXISTS idx_audit_strategy ON audit_log(strategy_id);
CREATE INDEX IF NOT EXISTS idx_performance_time ON performance(snapshot_at);
CREATE INDEX IF NOT EXISTS idx_api_usage_time ON api_usage(created_at);
CREATE INDEX IF NOT EXISTS idx_api_usage_agent ON api_usage(agent);
"""
