"""
Agent Swarm - Telegram Bot Interface

Commands:
  /start - Welcome message
  /agents - List available agents
  /status - Show running tasks
  /direct <agent> <task> - Send task directly to a specific agent
  /history - Show recent task history
  /clear - Clear agent conversation memory
  
Any other message gets routed automatically by the orchestrator.
"""
import asyncio
import logging
from datetime import datetime
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)
from agents.orchestrator import Orchestrator
from config.settings import settings

# Logging
logging.basicConfig(
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    level=logging.INFO
)
logger = logging.getLogger("AgentSwarm")

# Global orchestrator
orchestrator = Orchestrator()

# Track active tasks per user
active_tasks: dict[int, int] = {}


# ── Auth middleware ──────────────────────────────────────────────
def authorized(func):
    """Decorator to restrict bot to allowed users only."""
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if settings.ALLOWED_USERS and user_id not in settings.ALLOWED_USERS:
            await update.message.reply_text("⛔ Unauthorized. Your user ID is not in the allowlist.")
            logger.warning(f"Unauthorized access attempt from user {user_id}")
            return
        return await func(update, context)
    return wrapper


# ── Command Handlers ────────────────────────────────────────────

@authorized
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome = """🤖 **Agent Swarm Online**

I'm your multi-agent AI system. Just send me a task and I'll route it to the right agent.

**Available Agents:**
🔹 **Trading** - Market research, prices, analysis, signals
🔹 **Code** - Write, test, and deploy code
🔹 **Scraper** - Web scraping and data gathering

**Commands:**
/agents - Agent details
/direct `<agent> <task>` - Bypass auto-routing
/history - Recent tasks
/clear - Reset agent memory

Just type naturally and I'll figure out the rest."""

    await update.message.reply_text(welcome, parse_mode="Markdown")


@authorized
async def cmd_agents(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lines = ["📋 **Agent Details**\n"]
    for key, agent in orchestrator.agents.items():
        tools = agent.get_tools()
        tool_names = [t["name"] for t in tools]
        lines.append(f"**{key.upper()}** - {agent.description}")
        lines.append(f"  Tools: {', '.join(tool_names)}\n")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


@authorized
async def cmd_direct(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a task directly to a specific agent, bypassing the orchestrator."""
    text = update.message.text.replace("/direct", "", 1).strip()
    parts = text.split(" ", 1)

    if len(parts) < 2:
        await update.message.reply_text(
            "Usage: /direct `<agent> <task>`\nAgents: trading, code, scraper",
            parse_mode="Markdown"
        )
        return

    agent_key = parts[0].lower()
    task = parts[1]

    if agent_key not in orchestrator.agents:
        await update.message.reply_text(
            f"Unknown agent: {agent_key}\nAvailable: {', '.join(orchestrator.agents.keys())}"
        )
        return

    agent = orchestrator.agents[agent_key]
    await update.message.reply_text(f"⏳ Sending to **{agent_key.upper()}** agent...", parse_mode="Markdown")

    result = await agent.run(task)
    agent.reset()

    icon = "✅" if result.success else "❌"
    response = f"{icon} **{agent.name.upper()}** ({result.elapsed_seconds:.1f}s)\n\n{result.response}"
    await _send_long_message(update, response)


@authorized
async def cmd_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not orchestrator.task_history:
        await update.message.reply_text("No task history yet.")
        return

    lines = ["📜 **Recent Tasks**\n"]
    for i, task in enumerate(orchestrator.task_history[-5:], 1):
        agents_used = [s["agent"] for s in task["routing"].get("steps", [])]
        lines.append(f"{i}. {task['input'][:80]}")
        lines.append(f"   Agents: {' → '.join(agents_used)}\n")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


@authorized
async def cmd_clear(update: Update, context: ContextTypes.DEFAULT_TYPE):
    for agent in orchestrator.agents.values():
        agent.reset()
    orchestrator.task_history.clear()
    await update.message.reply_text("🧹 All agent memory and history cleared.")


@authorized
async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    count = active_tasks.get(user_id, 0)
    await update.message.reply_text(
        f"📊 Active tasks: {count}/{settings.MAX_CONCURRENT_TASKS}"
    )


# ── Main Message Handler ────────────────────────────────────────

@authorized
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Route any text message through the orchestrator."""
    user_id = update.effective_user.id
    task = update.message.text.strip()

    if not task:
        return

    # Rate limiting
    current_tasks = active_tasks.get(user_id, 0)
    if current_tasks >= settings.MAX_CONCURRENT_TASKS:
        await update.message.reply_text(
            f"⚠️ You have {current_tasks} active tasks. Wait for one to finish."
        )
        return

    active_tasks[user_id] = current_tasks + 1
    await update.message.reply_text("⏳ Processing...")

    try:
        response = await orchestrator.route_and_execute(task)
        await _send_long_message(update, response)
    except Exception as e:
        logger.error(f"Task failed: {e}", exc_info=True)
        await update.message.reply_text(f"❌ Error: {str(e)}")
    finally:
        active_tasks[user_id] = max(0, active_tasks.get(user_id, 1) - 1)


# ── Helpers ─────────────────────────────────────────────────────

async def _send_long_message(update: Update, text: str, chunk_size: int = 4000):
    """Split long messages to stay under Telegram's 4096 char limit."""
    if len(text) <= chunk_size:
        try:
            await update.message.reply_text(text, parse_mode="Markdown")
        except Exception:
            # Fallback without markdown if parsing fails
            await update.message.reply_text(text)
        return

    chunks = []
    while text:
        if len(text) <= chunk_size:
            chunks.append(text)
            break
        # Find a good split point
        split_at = text.rfind("\n", 0, chunk_size)
        if split_at == -1:
            split_at = chunk_size
        chunks.append(text[:split_at])
        text = text[split_at:].lstrip("\n")

    for chunk in chunks:
        try:
            await update.message.reply_text(chunk, parse_mode="Markdown")
        except Exception:
            await update.message.reply_text(chunk)
        await asyncio.sleep(0.3)  # Avoid rate limits


# ── Main ────────────────────────────────────────────────────────

def main():
    if not settings.TELEGRAM_BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN not set!")
        return
    if not settings.ANTHROPIC_API_KEY:
        logger.error("ANTHROPIC_API_KEY not set!")
        return

    logger.info("Starting Agent Swarm Telegram Bot...")
    logger.info(f"Agents loaded: {list(orchestrator.agents.keys())}")
    logger.info(f"Allowed users: {settings.ALLOWED_USERS or 'ALL (no restriction)'}")

    app = Application.builder().token(settings.TELEGRAM_BOT_TOKEN).build()

    # Register handlers
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("agents", cmd_agents))
    app.add_handler(CommandHandler("direct", cmd_direct))
    app.add_handler(CommandHandler("history", cmd_history))
    app.add_handler(CommandHandler("clear", cmd_clear))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Start polling
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
