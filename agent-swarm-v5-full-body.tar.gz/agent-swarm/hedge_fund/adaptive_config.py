"""
Adaptive Configuration - The Endocrine System

Dynamically adjusts fund parameters based on market conditions.
Like hormones regulating body functions, this system tunes:

  - Scan intervals (faster in high-vol, slower in low-vol)
  - Risk thresholds (tighter stops in chop, wider in trends)
  - Position sizing (smaller in uncertainty, larger in clarity)
  - Research frequency (more in transitions, less in stable regimes)
  - Budget allocation (more API spend when markets are active)

Regime Profiles:
  RISK_ON_TRENDING   → ride trends, wider stops, larger positions
  RISK_ON_VOLATILE   → tight stops, quick profits, smaller size
  RISK_OFF_TRENDING  → defensive, reduce exposure, hedge
  RISK_OFF_VOLATILE  → minimal exposure, max cash, preserve capital
  RANGING            → mean reversion, tight ranges, moderate size
  TRANSITIONING      → reduce size, increase scan frequency, gather data
"""
import json
import time
import logging
from dataclasses import dataclass, field, asdict
from typing import Optional

logger = logging.getLogger("AdaptiveConfig")


@dataclass
class RegimeProfile:
    """Configuration profile for a specific market regime."""
    name: str
    
    # Scan intervals (seconds)
    fast_scan_interval: float = 30
    deep_scan_interval: float = 300
    regime_check_interval: float = 900
    
    # Risk parameters
    max_position_pct: float = 0.10     # Max % of capital per position
    stop_loss_multiplier: float = 1.0  # Multiplied by base stop loss
    take_profit_multiplier: float = 1.0
    max_daily_drawdown: float = 0.03   # 3%
    max_concurrent_positions: int = 5
    
    # Strategy parameters
    min_sharpe_for_deploy: float = 1.5
    min_confidence_for_signal: float = 0.65
    min_win_rate: float = 0.45
    
    # Capital allocation
    max_deployed_pct: float = 0.80     # Max % of capital deployed
    cash_reserve_pct: float = 0.20     # Min cash reserve
    
    # Research & API
    research_interval_hours: float = 24
    api_budget_multiplier: float = 1.0  # Multiplied by base budget


# Pre-defined regime profiles
REGIME_PROFILES = {
    "RISK_ON_TRENDING": RegimeProfile(
        name="RISK_ON_TRENDING",
        fast_scan_interval=30,
        deep_scan_interval=300,
        max_position_pct=0.15,           # Larger positions in clear trends
        stop_loss_multiplier=1.5,        # Wider stops to ride the trend
        take_profit_multiplier=2.0,      # Larger targets
        max_daily_drawdown=0.04,         # Slightly more tolerance
        max_concurrent_positions=6,
        min_sharpe_for_deploy=1.3,       # Lower bar - trends are forgiving
        min_confidence_for_signal=0.6,
        max_deployed_pct=0.85,
        cash_reserve_pct=0.15,
        research_interval_hours=24,
        api_budget_multiplier=1.0,
    ),
    "RISK_ON_VOLATILE": RegimeProfile(
        name="RISK_ON_VOLATILE",
        fast_scan_interval=15,           # Scan faster - things move quick
        deep_scan_interval=180,
        max_position_pct=0.08,           # Smaller positions - choppy market
        stop_loss_multiplier=0.7,        # Tighter stops
        take_profit_multiplier=0.8,      # Quick profits
        max_daily_drawdown=0.025,
        max_concurrent_positions=4,
        min_sharpe_for_deploy=1.8,       # Higher bar - harder to trade
        min_confidence_for_signal=0.75,  # Only high conviction
        max_deployed_pct=0.60,
        cash_reserve_pct=0.40,           # More cash buffer
        research_interval_hours=12,      # Research more often
        api_budget_multiplier=1.3,       # Spend more on analysis
    ),
    "RISK_OFF_TRENDING": RegimeProfile(
        name="RISK_OFF_TRENDING",
        fast_scan_interval=60,           # Slower scans - less opportunity
        deep_scan_interval=600,
        max_position_pct=0.05,           # Small positions
        stop_loss_multiplier=0.5,        # Very tight stops
        take_profit_multiplier=0.6,
        max_daily_drawdown=0.02,         # Low tolerance
        max_concurrent_positions=3,
        min_sharpe_for_deploy=2.0,       # Very high bar
        min_confidence_for_signal=0.8,
        max_deployed_pct=0.40,           # Mostly cash
        cash_reserve_pct=0.60,
        research_interval_hours=12,
        api_budget_multiplier=0.8,
    ),
    "RISK_OFF_VOLATILE": RegimeProfile(
        name="RISK_OFF_VOLATILE",
        fast_scan_interval=10,           # Watch closely for exit signals
        deep_scan_interval=120,
        max_position_pct=0.03,           # Minimal positions
        stop_loss_multiplier=0.4,        # Extremely tight
        take_profit_multiplier=0.5,
        max_daily_drawdown=0.015,        # Preservation mode
        max_concurrent_positions=2,
        min_sharpe_for_deploy=2.5,       # Almost nothing passes
        min_confidence_for_signal=0.85,
        max_deployed_pct=0.20,           # Nearly all cash
        cash_reserve_pct=0.80,
        research_interval_hours=6,       # Watch for regime change
        api_budget_multiplier=1.2,
    ),
    "RANGING": RegimeProfile(
        name="RANGING",
        fast_scan_interval=45,
        deep_scan_interval=300,
        max_position_pct=0.08,
        stop_loss_multiplier=0.8,        # Moderate stops
        take_profit_multiplier=0.7,      # Quick scalps
        max_daily_drawdown=0.025,
        max_concurrent_positions=4,
        min_sharpe_for_deploy=1.5,
        min_confidence_for_signal=0.7,
        max_deployed_pct=0.60,
        cash_reserve_pct=0.40,
        research_interval_hours=24,
        api_budget_multiplier=0.9,
    ),
    "TRANSITIONING": RegimeProfile(
        name="TRANSITIONING",
        fast_scan_interval=15,           # Watch closely
        deep_scan_interval=120,          # Frequent deep analysis
        regime_check_interval=300,       # Check regime every 5 min
        max_position_pct=0.05,           # Small until direction clear
        stop_loss_multiplier=0.6,
        take_profit_multiplier=0.6,
        max_daily_drawdown=0.02,
        max_concurrent_positions=3,
        min_sharpe_for_deploy=1.8,
        min_confidence_for_signal=0.75,
        max_deployed_pct=0.40,
        cash_reserve_pct=0.60,
        research_interval_hours=6,       # Research heavily
        api_budget_multiplier=1.5,       # Spend more to understand
    ),
}

# Default/fallback
DEFAULT_PROFILE = RegimeProfile(name="DEFAULT")


class AdaptiveConfig:
    """
    Manages regime-based configuration profiles and applies them
    to the fund's operational parameters in real-time.
    """

    def __init__(self):
        self.current_regime: str = "RANGING"
        self.current_profile: RegimeProfile = REGIME_PROFILES.get("RANGING", DEFAULT_PROFILE)
        self.regime_history: list[dict] = []
        self.override_active: bool = False
        self._volatility_factor: float = 1.0  # Real-time vol adjustment on top of profile

    def update_regime(self, regime: str, confidence: float = 0.5,
                      volatility_level: str = "medium") -> dict:
        """
        Update the current regime and apply the corresponding profile.
        Returns a summary of what changed.
        """
        old_regime = self.current_regime
        old_profile = self.current_profile

        # Don't flip-flop on low confidence
        if confidence < 0.5 and regime != self.current_regime:
            logger.info(f"Regime signal {regime} ignored (confidence {confidence:.2f} < 0.5)")
            return {"changed": False, "reason": "Low confidence"}

        # Apply regime profile
        self.current_regime = regime
        self.current_profile = REGIME_PROFILES.get(regime, DEFAULT_PROFILE)

        # Apply volatility factor on top
        vol_factors = {"low": 0.8, "medium": 1.0, "high": 1.3, "extreme": 1.6}
        self._volatility_factor = vol_factors.get(volatility_level, 1.0)

        # Record history
        self.regime_history.append({
            "from": old_regime,
            "to": regime,
            "confidence": confidence,
            "volatility": volatility_level,
            "timestamp": time.time(),
        })
        if len(self.regime_history) > 100:
            self.regime_history = self.regime_history[-100:]

        changes = {}
        if regime != old_regime:
            changes = self._diff_profiles(old_profile, self.current_profile)
            logger.info(f"Regime changed: {old_regime} → {regime} ({len(changes)} params adjusted)")

        return {
            "changed": regime != old_regime,
            "from": old_regime,
            "to": regime,
            "confidence": confidence,
            "changes": changes,
        }

    def get_param(self, param: str) -> float:
        """Get a current parameter value, adjusted for volatility."""
        base = getattr(self.current_profile, param, None)
        if base is None:
            base = getattr(DEFAULT_PROFILE, param, 0)

        # Apply volatility factor to certain params
        vol_adjusted = {
            "fast_scan_interval", "deep_scan_interval",
            "stop_loss_multiplier", "max_position_pct",
        }
        if param in vol_adjusted:
            if param in ("fast_scan_interval", "deep_scan_interval"):
                # Lower intervals (faster) in high vol
                return base / self._volatility_factor
            elif param == "max_position_pct":
                # Smaller positions in high vol
                return base / self._volatility_factor
            elif param == "stop_loss_multiplier":
                # Tighter stops in high vol
                return base / self._volatility_factor
        return base

    def apply_to_priority_engine(self, engine):
        """Apply current profile to priority engine task intervals."""
        profile = self.current_profile

        task_updates = {
            "fast_scan": self.get_param("fast_scan_interval"),
            "deep_scan": self.get_param("deep_scan_interval"),
            "regime_detection": profile.regime_check_interval,
            "research": profile.research_interval_hours * 3600,
        }

        for task_name, new_interval in task_updates.items():
            if task_name in engine.tasks:
                old = engine.tasks[task_name].interval_seconds
                engine.tasks[task_name].interval_seconds = max(5, new_interval)
                if abs(old - new_interval) > 1:
                    logger.info(f"Task {task_name}: interval {old:.0f}s → {new_interval:.0f}s")

    def apply_to_fund_config(self, config):
        """Apply current profile to fund config."""
        profile = self.current_profile
        config.max_single_strategy_allocation = self.get_param("max_position_pct")
        config.max_total_deployed = profile.max_deployed_pct
        config.min_sharpe_for_deploy = profile.min_sharpe_for_deploy
        config.min_win_rate = profile.min_win_rate
        config.max_daily_drawdown = profile.max_daily_drawdown
        config.research_interval_hours = profile.research_interval_hours

    def apply_to_cost_tracker(self, cost_tracker):
        """Adjust API budget based on regime."""
        base_budget = 25.0  # Store original somewhere
        cost_tracker.daily_budget = base_budget * self.current_profile.api_budget_multiplier

    def set_manual_override(self, profile_name: str) -> bool:
        """Manually override to a specific profile."""
        if profile_name in REGIME_PROFILES:
            self.current_profile = REGIME_PROFILES[profile_name]
            self.current_regime = profile_name
            self.override_active = True
            return True
        return False

    def clear_override(self):
        """Clear manual override, return to auto-detection."""
        self.override_active = False

    def _diff_profiles(self, old: RegimeProfile, new: RegimeProfile) -> dict:
        """Show what changed between profiles."""
        changes = {}
        for field_name in vars(old):
            if field_name == "name":
                continue
            old_val = getattr(old, field_name)
            new_val = getattr(new, field_name)
            if old_val != new_val:
                changes[field_name] = {"from": old_val, "to": new_val}
        return changes

    def get_telegram_summary(self) -> str:
        """Telegram-friendly adaptive config status."""
        p = self.current_profile
        lines = [
            f"💉 *Adaptive Config*\n",
            f"Regime: *{self.current_regime}*"
            + (" (OVERRIDE)" if self.override_active else ""),
            f"Vol factor: {self._volatility_factor:.1f}x\n",
            f"*Scan Intervals:*",
            f"  Fast: {self.get_param('fast_scan_interval'):.0f}s | "
            f"Deep: {self.get_param('deep_scan_interval'):.0f}s",
            f"\n*Risk Params:*",
            f"  Max position: {self.get_param('max_position_pct'):.1%}",
            f"  SL multiplier: {self.get_param('stop_loss_multiplier'):.2f}x",
            f"  TP multiplier: {p.take_profit_multiplier:.2f}x",
            f"  Max daily DD: {p.max_daily_drawdown:.1%}",
            f"  Max positions: {p.max_concurrent_positions}",
            f"\n*Capital:*",
            f"  Max deployed: {p.max_deployed_pct:.0%} | Cash reserve: {p.cash_reserve_pct:.0%}",
            f"\n*Quality Bars:*",
            f"  Min Sharpe: {p.min_sharpe_for_deploy} | Min signal conf: {p.min_confidence_for_signal:.0%}",
        ]

        if self.regime_history:
            last = self.regime_history[-1]
            lines.append(f"\nLast change: {last['from']} → {last['to']} (conf: {last['confidence']:.0%})")

        return "\n".join(lines)
