"""
Fund Bootstrap - Wires DB, Execution Engine, and Cost Tracker into the Fund Manager

This is the single setup point. The bot calls this to create a fully-wired fund.

What gets connected:
  1. Database (SQLite) → all agents persist state
  2. Execution Engine → paper or live trading with position management
  3. Cost Tracker → monitors API spend, enforces daily budget
  4. Performance snapshots → hourly P&L recording
  5. State save/restore → fund survives restarts
"""
import os
import json
import time
import asyncio
import logging
from datetime import datetime, timezone

from database.models import Database
from database.cost_tracker import CostTracker
from database.learning import LearningSystem
from database.data_pipeline import DataPipeline
from execution.engine import (
    ExecutionEngine, PaperConnector, TradersPostConnector, CoinbaseConnector,
)
from execution.capital_allocator import CapitalAllocator
from hedge_fund.fund_manager_v2 import FundManagerV2
from hedge_fund.fund_manager import FundConfig, Strategy, StrategyStatus
from hedge_fund.priority_engine import Priority
from hedge_fund.adaptive_config import AdaptiveConfig
from security.manager import SecurityManager
from agents.orchestrator import Orchestrator

logger = logging.getLogger("FundBootstrap")


class FundBootstrap:
    """
    Creates and wires a fully-functional fund with all systems.
    
    Organs wired:
      🧠 Brain         - Orchestrator + Priority Engine
      👁️ Eyes          - Screener Agent
      🎯 Cortex        - Watchlist Manager
      🛡️ Immune        - Risk + Circuit Breakers
      ⚡ Nerves        - Event Bus
      🤲 Hands         - Code Agent + Engineer
      🦴 Reflexes      - Tier 0 Tasks
      🧠💾 Memory      - SQLite Database
      🔄 Gut           - Execution Engine + OMS
      🫁 Lungs         - Cost Tracker
      🫀 Liver         - Audit Trail
      ❤️ Heart         - Capital Allocator (Kelly + Correlation)
      📚 Cerebellum    - Learning System
      💉 Endocrine     - Adaptive Config
      🧱 Skin          - Security Manager
      👄 Stomach       - Data Pipeline
    """

    def __init__(
        self,
        config: FundConfig,
        orchestrator: Orchestrator,
        telegram_notify=None,
        db_path: str = "./data/fund.db",
        daily_budget: float = 25.0,
    ):
        self.config = config
        self.orchestrator = orchestrator
        self.telegram_notify = telegram_notify

        # ── 🧠💾 Memory: Database ──────────────────────────────
        self.db = Database(db_path=db_path)
        logger.info(f"Database ready: {db_path}")

        # ── 🫁 Lungs: Cost Tracker ─────────────────────────────
        self.cost_tracker = CostTracker(self.db, daily_budget=daily_budget)
        logger.info(f"Cost tracker ready: ${daily_budget}/day budget")

        # ── 🧱 Skin: Security ──────────────────────────────────
        self.security = SecurityManager(db=self.db)
        logger.info(f"Security manager ready: {self.security.secrets.get_rotation_status()['keys_stored']} secrets")

        # ── 👄 Stomach: Data Pipeline ──────────────────────────
        self.data_pipeline = DataPipeline(
            rate_limiter=self.security.rate_limiter,
            db=self.db,
        )
        logger.info("Data pipeline ready")

        # ── 🔄 Gut: Execution Engine ───────────────────────────
        self.connector = self._create_connector()
        self.execution = ExecutionEngine(
            db=self.db,
            connector=self.connector,
            notify_fn=telegram_notify,
        )
        logger.info(f"Execution engine ready: {self.connector.name}")

        # ── ❤️ Heart: Capital Allocator ─────────────────────────
        self.allocator = CapitalAllocator(
            total_capital=config.total_capital,
            max_per_strategy=config.max_single_strategy_allocation,
            max_total_deployed=0.80,
            kelly_fraction=0.5,
        )
        logger.info("Capital allocator ready")

        # ── 📚 Cerebellum: Learning System ─────────────────────
        self.learning = LearningSystem(self.db)
        logger.info("Learning system ready")

        # ── 💉 Endocrine: Adaptive Config ──────────────────────
        self.adaptive_config = AdaptiveConfig()
        logger.info(f"Adaptive config ready: regime={self.adaptive_config.current_regime}")

        # ── 🧠 Brain: Fund Manager ─────────────────────────────
        self.fund_manager = FundManagerV2(
            config=config,
            orchestrator=orchestrator,
            telegram_notify=telegram_notify,
        )

        # ── Wire everything together ────────────────────────────
        self._wire()

    def _create_connector(self):
        """Create the appropriate exchange connector based on config."""
        if self.config.execution_mode == "paper":
            return PaperConnector(
                initial_balance=self.config.total_capital,
                fee_rate=0.001,
            )
        elif self.config.broker == "traderspost":
            webhook_url = os.getenv("TRADERSPOST_WEBHOOK_URL", "")
            if not webhook_url:
                logger.warning("TRADERSPOST_WEBHOOK_URL not set, falling back to paper")
                return PaperConnector(initial_balance=self.config.total_capital)
            return TradersPostConnector(webhook_url=webhook_url)
        elif self.config.broker == "coinbase":
            api_key = os.getenv("COINBASE_API_KEY", "")
            api_secret = os.getenv("COINBASE_API_SECRET", "")
            if not api_key or not api_secret:
                logger.warning("Coinbase credentials not set, falling back to paper")
                return PaperConnector(initial_balance=self.config.total_capital)
            return CoinbaseConnector(api_key=api_key, api_secret=api_secret)
        else:
            return PaperConnector(initial_balance=self.config.total_capital)

    def _wire(self):
        """Connect all 16 organ systems together."""
        fm = self.fund_manager

        # Store references on the fund manager
        fm.db = self.db
        fm.execution = self.execution
        fm.cost_tracker = self.cost_tracker
        fm.learning = self.learning
        fm.adaptive_config = self.adaptive_config
        fm.allocator = self.allocator
        fm.data_pipeline = self.data_pipeline
        fm.security = self.security

        # Monkey-patch the base agent's run method to track costs
        self._patch_agents_for_cost_tracking()

        # Patch agents for input sanitization
        self._patch_agents_for_security()

        # Restore state from database if available
        self._restore_state()

        # Register additional priority tasks for all systems
        self._register_persistence_tasks()
        self._register_learning_tasks()
        self._register_adaptive_tasks()
        self._register_allocator_tasks()

    def _patch_agents_for_cost_tracking(self):
        """Wrap each agent's API calls to track costs."""
        from agents.base_agent import BaseAgent
        original_run = BaseAgent.run
        cost_tracker = self.cost_tracker
        db = self.db

        async def tracked_run(agent_self, task: str):
            # Check budget before making API calls
            within_budget, remaining = cost_tracker.check_budget()
            if not within_budget:
                from agents.base_agent import AgentResult
                logger.warning(f"Daily API budget exceeded! Remaining: ${remaining:.2f}")
                return AgentResult(
                    success=False,
                    response=f"⚠️ Daily API budget exceeded (${cost_tracker.daily_budget}/day). "
                             f"Wait until tomorrow or increase budget.",
                    agent_name=agent_self.name,
                )

            result = await original_run(agent_self, task)
            
            # Track the cost
            if result.tokens_used > 0:
                # Estimate input/output split (rough: 70% input, 30% output)
                input_tokens = int(result.tokens_used * 0.7)
                output_tokens = result.tokens_used - input_tokens
                cost_tracker.record(
                    agent=agent_self.name,
                    model="claude-sonnet-4-20250514",
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    task_name=task[:100],
                )

            return result

        BaseAgent.run = tracked_run

    def _patch_agents_for_security(self):
        """Wrap agent inputs through security sanitization."""
        from agents.base_agent import BaseAgent
        original_run = BaseAgent.run  # Already patched for cost tracking
        security = self.security

        async def secured_run(agent_self, task: str):
            # Sanitize the input
            clean_task, warnings = security.check_and_sanitize_prompt(task)
            if warnings:
                logger.warning(f"Security warnings for {agent_self.name}: {warnings}")
            
            # Check rate limit for anthropic
            if not security.check_rate_limit("anthropic"):
                from agents.base_agent import AgentResult
                return AgentResult(
                    success=False,
                    response="⚠️ Anthropic API rate limit hit. Waiting...",
                    agent_name=agent_self.name,
                )

            return await original_run(agent_self, clean_task)

        BaseAgent.run = secured_run

    def _restore_state(self):
        """Restore fund state from database on startup."""
        state = self.db.load_fund_state()
        if state:
            logger.info("Restoring fund state from database...")
            
            # Restore portfolio state
            if "portfolio_state" in state:
                self.fund_manager.portfolio_state.update(state["portfolio_state"])

            # Restore strategies
            saved_strategies = self.db.get_strategies()
            for s_data in saved_strategies:
                status = s_data.get("status", "retired")
                if status in ("live", "deployed", "approved", "backtesting", "risk_review"):
                    strategy = Strategy(
                        id=s_data["id"],
                        name=s_data["name"],
                        status=StrategyStatus(status),
                        description=s_data.get("description", ""),
                        hypothesis=s_data.get("hypothesis", ""),
                        assets=s_data.get("assets", []),
                        timeframe=s_data.get("timeframe", ""),
                        sharpe_ratio=s_data.get("sharpe_ratio", 0),
                        max_drawdown=s_data.get("max_drawdown", 0),
                        win_rate=s_data.get("win_rate", 0),
                        profit_factor=s_data.get("profit_factor", 0),
                        total_trades=s_data.get("total_trades", 0),
                        max_position_size=s_data.get("max_position_size", 0),
                        stop_loss_pct=s_data.get("stop_loss_pct", 0),
                        take_profit_pct=s_data.get("take_profit_pct", 0),
                        live_pnl=s_data.get("live_pnl", 0),
                        live_trades=s_data.get("live_trades", 0),
                        live_start_date=s_data.get("live_start_date", ""),
                    )
                    self.fund_manager.strategies[strategy.id] = strategy

            logger.info(
                f"Restored: {len(self.fund_manager.strategies)} strategies, "
                f"{len(self.execution.positions)} open positions"
            )

    def _register_persistence_tasks(self):
        """Register database persistence tasks with the priority engine."""
        engine = self.fund_manager.priority_engine

        # Save fund state every 5 minutes (Tier 2)
        engine.register(
            name="save_state",
            priority=Priority.MEDIUM,
            interval_seconds=300,
            callback=self._task_save_state,
            timeout_seconds=10,
        )

        # Performance snapshot every hour (Tier 3)
        engine.register(
            name="performance_snapshot",
            priority=Priority.LOW,
            interval_seconds=3600,
            callback=self._task_performance_snapshot,
            timeout_seconds=10,
        )

        # Position check via execution engine (Tier 1)
        engine.register(
            name="position_check",
            priority=Priority.HIGH,
            interval_seconds=30,
            callback=self._task_position_check,
            timeout_seconds=30,
        )

        # Budget check (Tier 2)
        engine.register(
            name="budget_check",
            priority=Priority.MEDIUM,
            interval_seconds=600,  # Every 10 min
            callback=self._task_budget_check,
            timeout_seconds=5,
        )

    async def _task_save_state(self):
        """Persist fund state to database."""
        fm = self.fund_manager
        
        # Save portfolio state
        state = {
            "portfolio_state": fm.portfolio_state,
            "cycle_count": fm.cycle_count,
            "is_paused": fm.is_paused,
            "metrics": fm._cycle_metrics,
            "saved_at": datetime.now(timezone.utc).isoformat(),
        }
        self.db.save_fund_state(state)

        # Save each strategy
        for sid, strategy in fm.strategies.items():
            self.db.save_strategy({
                "id": strategy.id,
                "name": strategy.name,
                "status": strategy.status.value,
                "description": strategy.description,
                "hypothesis": strategy.hypothesis,
                "assets": strategy.assets,
                "timeframe": strategy.timeframe,
                "market_regime": strategy.market_regime,
                "sharpe_ratio": strategy.sharpe_ratio,
                "max_drawdown": strategy.max_drawdown,
                "win_rate": strategy.win_rate,
                "profit_factor": strategy.profit_factor,
                "total_trades": strategy.total_trades,
                "backtest_results": strategy.backtest_results,
                "strategy_code": strategy.strategy_code,
                "max_position_size": strategy.max_position_size,
                "max_daily_loss": strategy.max_daily_loss,
                "stop_loss_pct": strategy.stop_loss_pct,
                "take_profit_pct": strategy.take_profit_pct,
                "live_pnl": strategy.live_pnl,
                "live_trades": strategy.live_trades,
                "paper_trade_days": strategy.paper_trade_days,
                "live_start_date": strategy.live_start_date,
                "created_at": strategy.created_at,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            })

        return {"saved": True}

    async def _task_performance_snapshot(self):
        """Take hourly performance snapshot."""
        fm = self.fund_manager
        self.db.snapshot_performance({
            "total_capital": fm.config.total_capital,
            "cash": fm.portfolio_state.get("cash", 0),
            "deployed": self.execution.get_total_exposure(),
            "total_pnl": fm.portfolio_state.get("total_pnl", 0),
            "daily_pnl": fm.portfolio_state.get("daily_pnl", 0),
            "weekly_pnl": fm.portfolio_state.get("weekly_pnl", 0),
            "open_positions": len(self.execution.positions),
            "active_strategies": len([
                s for s in fm.strategies.values() 
                if s.status == StrategyStatus.LIVE
            ]),
        })
        return {"snapshot": True}

    async def _task_position_check(self):
        """Check positions for stop loss / take profit."""
        actions = await self.execution.check_positions()
        
        # Update strategy P&L from closed positions
        for action in actions:
            strategy_id = None
            for pos_data in self.execution.get_all_positions():
                if pos_data.get("strategy_id"):
                    strategy_id = pos_data["strategy_id"]
                    break
            
            if action.get("strategy_id") or strategy_id:
                sid = action.get("strategy_id", strategy_id)
                if sid in self.fund_manager.strategies:
                    self.fund_manager.strategies[sid].live_pnl += action.get("pnl", 0)
                    self.fund_manager.strategies[sid].live_trades += 1
        
        return {"checked": len(self.execution.positions), "actions": len(actions)}

    async def _task_budget_check(self):
        """Check API budget and warn if getting close."""
        within, remaining = self.cost_tracker.check_budget()
        if not within:
            for task_name in ["research", "deep_scan", "watchlist_discovery"]:
                self.fund_manager.priority_engine.pause_task(task_name)
            
            if self.telegram_notify:
                await self.telegram_notify(
                    f"🫁 *API Budget Exceeded*\n"
                    f"Daily spend has hit ${self.cost_tracker.daily_budget:.2f}\n"
                    f"Non-critical tasks paused to save budget.\n"
                    f"Critical monitoring and positions still active."
                )
        elif remaining < self.cost_tracker.daily_budget * 0.2:
            if self.telegram_notify:
                await self.telegram_notify(
                    f"🫁 *Budget Warning*: ${remaining:.2f} remaining today"
                )
        return {"within_budget": within, "remaining": remaining}

    # ── Learning System Tasks ───────────────────────────────────

    def _register_learning_tasks(self):
        engine = self.fund_manager.priority_engine

        # Refresh lessons every 2 hours (Tier 3)
        engine.register(
            name="learning_refresh",
            priority=Priority.LOW,
            interval_seconds=7200,
            callback=self._task_learning_refresh,
            timeout_seconds=30,
        )

    async def _task_learning_refresh(self):
        """Refresh learning system insights + self-tune exit configs."""
        self.learning.get_lessons(force_refresh=True)
        lessons = self.learning.get_lessons()
        
        # ══ Self-tune exit configs per asset (Profit Progression) ══
        tuning = self.learning.compute_exit_tuning(execution_engine=self.execution)
        tuned_count = tuning.get("assets_tuned", 0)
        if tuned_count > 0:
            logger.info(f"🧬 Self-tuned exit configs for {tuned_count} assets")
            if self.telegram_notify:
                await self.telegram_notify(
                    f"🧬 *Self-Tuning Complete*\n"
                    f"Assets tuned: {tuned_count}/{tuning.get('total_assets', 0)}\n"
                    f"{tuning.get('lesson', '')}"
                )
        
        # Inject learning context into research agent prompt enrichment
        mistake_count = lessons.get("mistake_patterns", {}).get("total_mistakes", 0)
        if mistake_count > 0 and self.telegram_notify:
            await self.telegram_notify(
                f"📚 Learning system detected {mistake_count} mistake patterns. "
                f"Research agent will adjust."
            )
        return {"refreshed": True, "mistakes": mistake_count, "tuned": tuned_count}

    # ── Adaptive Config Tasks ───────────────────────────────────

    def _register_adaptive_tasks(self):
        engine = self.fund_manager.priority_engine

        # Apply adaptive config after regime detection (Tier 2)
        engine.register(
            name="adaptive_apply",
            priority=Priority.MEDIUM,
            interval_seconds=900,  # Every 15 min
            callback=self._task_adaptive_apply,
            timeout_seconds=15,
        )

        # Subscribe to regime change events
        engine.event_bus.subscribe("regime.update", self._on_regime_for_adaptive)

    async def _task_adaptive_apply(self):
        """Apply current adaptive config to all systems."""
        ac = self.adaptive_config
        ac.apply_to_priority_engine(self.fund_manager.priority_engine)
        ac.apply_to_cost_tracker(self.cost_tracker)
        return {"regime": ac.current_regime, "applied": True}

    async def _on_regime_for_adaptive(self, regime_data):
        """When regime changes, update adaptive config."""
        if not isinstance(regime_data, dict):
            return

        regime = regime_data.get("regime", "RANGING")
        confidence = regime_data.get("confidence", 0.5)
        volatility = regime_data.get("volatility_level", "medium")

        result = self.adaptive_config.update_regime(regime, confidence, volatility)

        if result.get("changed"):
            self.adaptive_config.apply_to_priority_engine(self.fund_manager.priority_engine)
            self.adaptive_config.apply_to_cost_tracker(self.cost_tracker)
            
            # ══ Push regime to execution engine (profit progression uses this) ══
            self.execution.set_regime(regime)

            if self.telegram_notify:
                changes = result.get("changes", {})
                change_count = len(changes)
                await self.telegram_notify(
                    f"💉 *Regime Shift*: {result['from']} → {result['to']}\n"
                    f"Confidence: {confidence:.0%} | {change_count} params adjusted\n"
                    f"Scan: {self.adaptive_config.get_param('fast_scan_interval'):.0f}s | "
                    f"Max pos: {self.adaptive_config.get_param('max_position_pct'):.1%} | "
                    f"SL mult: {self.adaptive_config.get_param('stop_loss_multiplier'):.2f}x"
                )

    # ── Capital Allocator Tasks ─────────────────────────────────

    def _register_allocator_tasks(self):
        engine = self.fund_manager.priority_engine

        # Rebalance check every 30 min (Tier 3)
        engine.register(
            name="rebalance_check",
            priority=Priority.LOW,
            interval_seconds=1800,
            callback=self._task_rebalance_check,
            timeout_seconds=30,
        )

    async def _task_rebalance_check(self):
        """Run capital allocation and check if rebalancing is needed."""
        fm = self.fund_manager
        
        # Get active live strategies
        live_strategies = [
            {
                "id": s.id, "name": s.name,
                "win_rate": s.win_rate, "profit_factor": s.profit_factor,
                "sharpe_ratio": s.sharpe_ratio, "assets": s.assets,
                "timeframe": s.timeframe, "hypothesis": s.hypothesis,
                "live_pnl": s.live_pnl, "live_trades": s.live_trades,
            }
            for s in fm.strategies.values()
            if s.status == StrategyStatus.LIVE
        ]

        if not live_strategies:
            return {"rebalance": False, "reason": "no_live_strategies"}

        # Update capital from current state
        self.allocator.update_capital(fm.config.total_capital + fm.portfolio_state.get("total_pnl", 0))

        # Get regime-adjusted max deployment
        regime_max = self.adaptive_config.current_profile.max_deployed_pct

        # Calculate allocations
        allocations = self.allocator.allocate(live_strategies, regime_max_deployed=regime_max)

        # Get current positions
        current_positions = {}
        for pos in self.execution.positions.values():
            sid = pos.strategy_id
            value = pos.quantity * (pos.current_price or pos.entry_price)
            current_positions[sid] = current_positions.get(sid, 0) + value

        # Check what needs rebalancing
        actions = self.allocator.get_rebalance_actions(current_positions)

        if actions and self.telegram_notify:
            lines = ["❤️ *Rebalance Suggested*\n"]
            for a in actions[:5]:
                icon = "⬆️" if a["action"] == "increase" else "⬇️"
                lines.append(
                    f"{icon} {a['strategy_name']}: "
                    f"${a['current']:,.0f} → ${a['target']:,.0f} "
                    f"({a['change']:+,.0f})"
                )
            await self.telegram_notify("\n".join(lines))

        return {"rebalance": len(actions) > 0, "actions": len(actions)}

    # ── Public Methods ──────────────────────────────────────────

    def get_full_status(self) -> str:
        """Complete system status — all 16 organs."""
        fund_status = self.fund_manager.get_status()
        exec_summary = self.execution.get_execution_summary()
        cost_summary = self.cost_tracker.get_telegram_summary()
        db_stats = self.db.get_db_stats()

        db_line = (
            f"\n💾 *Database*: {db_stats['db_size_mb']}MB | "
            + " | ".join(f"{t}: {c}" for t, c in db_stats["tables"].items())
        )

        # Adaptive config summary (compact)
        ac = self.adaptive_config
        adaptive_line = (
            f"\n💉 *Regime*: {ac.current_regime} | "
            f"Vol: {ac._volatility_factor:.1f}x | "
            f"MaxPos: {ac.get_param('max_position_pct'):.1%} | "
            f"SL: {ac.get_param('stop_loss_multiplier'):.2f}x"
        )

        # Learning summary (compact)
        lessons = self.learning.get_lessons()
        sl = lessons.get("strategy_lessons", {})
        learning_line = (
            f"\n📚 *Learning*: "
            f"{sl.get('total_strategies', 0)} strategies analyzed | "
            f"WR: {sl.get('win_rate', 0):.0%} | "
            f"Mistakes: {lessons.get('mistake_patterns', {}).get('total_mistakes', 0)}"
        )

        # Data pipeline (compact)
        dp_stats = self.data_pipeline.get_stats()
        pipeline_line = (
            f"\n👄 *Data*: {dp_stats['api_requests']} requests | "
            f"{dp_stats['cache_hits']} cached ({dp_stats['cache_hit_rate']})"
        )
        # Security (compact)
        sec_rl = self.security.rate_limiter.get_status()
        alerts = self.security.anomaly_detector.get_recent_alerts(3)
        security_line = (
            f"\n🧱 *Security*: {len(alerts)} alerts | "
            f"CG: {sec_rl['coingecko']['remaining']}/{sec_rl['coingecko']['max']} | "
            f"API: {sec_rl['anthropic']['remaining']}/{sec_rl['anthropic']['max']}"
        )

        return (
            f"{fund_status}\n\n{exec_summary}\n\n{cost_summary}"
            f"{db_line}{adaptive_line}{learning_line}{pipeline_line}{security_line}"
        )
