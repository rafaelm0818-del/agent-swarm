"""
Autonomous Hedge Fund Manager

Runs a continuous loop where specialized agents collaborate:
  1. RESEARCHER   → Finds opportunities, monitors market regime
  2. QUANT        → Builds & backtests strategies
  3. RISK         → Validates strategies, sets position limits
  4. ENGINEER     → Deploys approved strategies to live
  5. MONITOR      → Watches live performance, triggers adaptation

The Fund Manager orchestrates the full cycle and only escalates
to human (you) for high-risk decisions above configurable thresholds.
"""
import asyncio
import json
import time
import logging
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum

logger = logging.getLogger("FundManager")


class StrategyStatus(str, Enum):
    RESEARCHING = "researching"
    BACKTESTING = "backtesting"
    RISK_REVIEW = "risk_review"
    APPROVED = "approved"
    DEPLOYED = "deployed"
    LIVE = "live"
    PAUSED = "paused"
    RETIRED = "retired"


@dataclass
class Strategy:
    """Represents a trading strategy through its full lifecycle."""
    id: str
    name: str
    description: str
    status: StrategyStatus = StrategyStatus.RESEARCHING
    
    # Research phase
    hypothesis: str = ""
    market_regime: str = ""  # trending, mean_reverting, volatile, etc.
    assets: list[str] = field(default_factory=list)
    timeframe: str = ""
    
    # Backtest results
    backtest_results: dict = field(default_factory=dict)
    sharpe_ratio: float = 0.0
    max_drawdown: float = 0.0
    win_rate: float = 0.0
    profit_factor: float = 0.0
    total_trades: int = 0
    
    # Risk parameters (set by Risk Agent)
    max_position_size: float = 0.0
    max_daily_loss: float = 0.0
    stop_loss_pct: float = 0.0
    take_profit_pct: float = 0.0
    max_correlated_positions: int = 1
    
    # Live performance
    live_pnl: float = 0.0
    live_trades: int = 0
    live_start_date: str = ""
    paper_trade_days: int = 0
    
    # Code
    strategy_code: str = ""
    config_file: str = ""
    
    # Audit trail
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = ""
    change_log: list[dict] = field(default_factory=list)

    def log_change(self, agent: str, action: str, details: str):
        self.change_log.append({
            "timestamp": datetime.utcnow().isoformat(),
            "agent": agent,
            "action": action,
            "details": details
        })
        self.updated_at = datetime.utcnow().isoformat()


@dataclass
class FundConfig:
    """Configuration for the autonomous fund."""
    # Capital allocation
    total_capital: float = 10000.0  # Starting capital in USD
    max_single_strategy_allocation: float = 0.25  # 25% max per strategy
    max_total_deployed: float = 0.80  # 80% max deployed, 20% cash reserve
    
    # Risk limits
    max_daily_drawdown: float = 0.03  # 3% daily loss → pause all
    max_weekly_drawdown: float = 0.07  # 7% weekly loss → pause all
    max_total_drawdown: float = 0.15  # 15% total drawdown → stop everything
    min_sharpe_for_deploy: float = 1.5
    min_profit_factor: float = 1.3
    min_backtest_trades: int = 50
    min_win_rate: float = 0.45
    max_correlation_between_strategies: float = 0.6
    
    # Paper trading requirements
    paper_trade_days_required: int = 7  # Must paper trade X days before live
    paper_trade_min_trades: int = 10
    
    # Cycle timing
    research_interval_hours: int = 24  # How often to look for new opportunities
    monitor_interval_minutes: int = 5  # How often to check live strategies
    rebalance_interval_hours: int = 12  # How often to rebalance/re-evaluate
    
    # Human escalation thresholds
    human_approval_above_usd: float = 1000.0  # Positions above this need your OK
    alert_on_new_strategy: bool = True
    alert_on_strategy_pause: bool = True
    
    # Execution
    execution_mode: str = "paper"  # "paper" or "live"
    broker: str = "traderspost"  # traderspost, coinbase, hyperliquid, etc.


class FundManager:
    """
    The autonomous fund manager that orchestrates all agents.
    
    Think of this as the 'CEO' of your hedge fund. It:
    1. Sets the research agenda
    2. Reviews strategy proposals from the Quant agent
    3. Enforces risk limits via the Risk agent
    4. Deploys approved strategies via the Engineer agent
    5. Monitors everything and adapts
    """

    def __init__(self, config: FundConfig, orchestrator, telegram_notify=None):
        self.config = config
        self.orchestrator = orchestrator
        self.notify = telegram_notify  # async function to send Telegram messages
        
        self.strategies: dict[str, Strategy] = {}
        self.portfolio_state = {
            "cash": config.total_capital,
            "deployed": 0.0,
            "total_pnl": 0.0,
            "daily_pnl": 0.0,
            "weekly_pnl": 0.0,
            "positions": [],
        }
        self.is_running = False
        self.is_paused = False
        self.cycle_count = 0

    # ── Main Loop ───────────────────────────────────────────────

    async def run(self):
        """Main autonomous loop."""
        self.is_running = True
        logger.info("🚀 Fund Manager starting autonomous loop")
        await self._notify("🚀 *Hedge Fund Online*\n"
                          f"Capital: ${self.config.total_capital:,.2f}\n"
                          f"Mode: {self.config.execution_mode}\n"
                          f"Research every {self.config.research_interval_hours}h\n"
                          f"Monitoring every {self.config.monitor_interval_minutes}m")

        last_research = datetime.min
        last_rebalance = datetime.min

        while self.is_running:
            try:
                now = datetime.utcnow()
                self.cycle_count += 1

                # ── Always: Monitor live strategies ──
                if not self.is_paused:
                    await self._monitor_cycle()

                # ── Check circuit breakers ──
                if self._check_circuit_breakers():
                    continue

                # ── Periodic: Research new opportunities ──
                if (now - last_research) > timedelta(hours=self.config.research_interval_hours):
                    if not self.is_paused:
                        await self._research_cycle()
                        last_research = now

                # ── Periodic: Rebalance and adapt ──
                if (now - last_rebalance) > timedelta(hours=self.config.rebalance_interval_hours):
                    if not self.is_paused:
                        await self._rebalance_cycle()
                        last_rebalance = now

                # ── Process pipeline: move strategies through stages ──
                await self._process_pipeline()

                # Sleep until next monitor cycle
                await asyncio.sleep(self.config.monitor_interval_minutes * 60)

            except Exception as e:
                logger.error(f"Fund Manager error: {e}", exc_info=True)
                await self._notify(f"⚠️ *Fund Manager Error*\n{str(e)[:500]}")
                await asyncio.sleep(60)

    async def stop(self):
        """Graceful shutdown."""
        self.is_running = False
        await self._notify("🛑 *Hedge Fund Shutting Down*\n"
                          f"Total P&L: ${self.portfolio_state['total_pnl']:,.2f}")

    # ── Research Cycle ──────────────────────────────────────────

    async def _research_cycle(self):
        """Use agents to find new trading opportunities."""
        logger.info("🔬 Starting research cycle")

        # Determine what to research based on current portfolio
        active_assets = set()
        for s in self.strategies.values():
            if s.status in (StrategyStatus.LIVE, StrategyStatus.DEPLOYED):
                active_assets.update(s.assets)

        research_prompt = f"""You are the research arm of an autonomous hedge fund.

Current portfolio state:
- Capital: ${self.portfolio_state['cash']:,.2f} available
- Active strategies: {len([s for s in self.strategies.values() if s.status == StrategyStatus.LIVE])}
- Assets already traded: {list(active_assets) if active_assets else 'None yet'}
- Total P&L: ${self.portfolio_state['total_pnl']:,.2f}

Your job:
1. Search for current market conditions and identify the dominant regime (trending/ranging/volatile)
2. Look for 2-3 actionable trading opportunities that FIT the current regime
3. For each opportunity, provide:
   - Asset(s) and timeframe
   - Clear hypothesis (why this trade works now)
   - Entry/exit logic in plain English
   - What data we need to backtest it

Focus on:
- Crypto (BTC, ETH, SOL, major alts) on 1h-4h-1d timeframes
- Mean reversion and momentum strategies
- Avoid opportunities that overlap with existing strategies

Be specific with numbers and conditions, not vague narratives.
Return your findings as JSON with this structure:
{{
  "market_regime": "trending_bullish|trending_bearish|ranging|volatile",
  "regime_confidence": 0.0-1.0,
  "opportunities": [
    {{
      "name": "strategy name",
      "assets": ["BTC"],
      "timeframe": "4h",
      "hypothesis": "...",
      "entry_logic": "...",
      "exit_logic": "...",
      "data_needed": "..."
    }}
  ]
}}"""

        # Route to scraper + trading agents for research
        result = await self.orchestrator.route_and_execute(research_prompt)
        
        # Parse opportunities and create strategy objects
        try:
            opportunities = self._parse_research_results(result)
            for opp in opportunities:
                strategy_id = f"strat_{int(time.time())}_{opp['name'][:10].replace(' ', '_').lower()}"
                strategy = Strategy(
                    id=strategy_id,
                    name=opp["name"],
                    description=opp.get("hypothesis", ""),
                    hypothesis=opp.get("hypothesis", ""),
                    assets=opp.get("assets", []),
                    timeframe=opp.get("timeframe", "4h"),
                    market_regime=opp.get("market_regime", "unknown"),
                )
                strategy.log_change("researcher", "created", f"New opportunity: {opp['name']}")
                strategy.status = StrategyStatus.BACKTESTING
                self.strategies[strategy_id] = strategy

                if self.config.alert_on_new_strategy:
                    await self._notify(
                        f"🔬 *New Strategy Found*\n"
                        f"Name: {strategy.name}\n"
                        f"Assets: {', '.join(strategy.assets)}\n"
                        f"Timeframe: {strategy.timeframe}\n"
                        f"Hypothesis: {strategy.hypothesis[:200]}"
                    )
        except Exception as e:
            logger.error(f"Failed to parse research results: {e}")

    # ── Backtest Cycle ──────────────────────────────────────────

    async def _backtest_strategy(self, strategy: Strategy):
        """Have the Quant agent build and backtest a strategy."""
        logger.info(f"📊 Backtesting strategy: {strategy.name}")

        backtest_prompt = f"""You are a quantitative developer for an autonomous hedge fund.

Build and backtest this strategy:
- Name: {strategy.name}
- Assets: {', '.join(strategy.assets)}
- Timeframe: {strategy.timeframe}
- Hypothesis: {strategy.hypothesis}

Requirements:
1. Write a complete Python backtest using pandas and ta (technical analysis library)
2. Fetch historical data (at least 6 months) using yfinance or CoinGecko
3. Implement the entry/exit logic
4. Calculate these metrics:
   - Sharpe Ratio
   - Max Drawdown (%)
   - Win Rate (%)
   - Profit Factor
   - Total Trades
   - Average trade duration
   - Monthly returns
5. Run the backtest and output results as JSON:

{{
  "sharpe_ratio": float,
  "max_drawdown": float (as decimal, e.g. 0.15 = 15%),
  "win_rate": float (as decimal),
  "profit_factor": float,
  "total_trades": int,
  "avg_trade_duration_hours": float,
  "total_return_pct": float,
  "monthly_returns": [float, ...],
  "strategy_code": "the full Python strategy code as a string"
}}

The strategy code should be a standalone Python class that can be imported and run.
Include proper risk management (stop loss, position sizing) in the code.
Use realistic assumptions: 0.1% commission per trade for crypto, no slippage model needed for now."""

        result = await self.orchestrator.route_and_execute(backtest_prompt)
        
        try:
            backtest_data = self._parse_json_from_response(result)
            if backtest_data:
                strategy.sharpe_ratio = backtest_data.get("sharpe_ratio", 0)
                strategy.max_drawdown = backtest_data.get("max_drawdown", 1.0)
                strategy.win_rate = backtest_data.get("win_rate", 0)
                strategy.profit_factor = backtest_data.get("profit_factor", 0)
                strategy.total_trades = backtest_data.get("total_trades", 0)
                strategy.backtest_results = backtest_data
                strategy.strategy_code = backtest_data.get("strategy_code", "")
                strategy.status = StrategyStatus.RISK_REVIEW
                strategy.log_change("quant", "backtested", 
                    f"Sharpe: {strategy.sharpe_ratio:.2f}, "
                    f"MaxDD: {strategy.max_drawdown:.1%}, "
                    f"WR: {strategy.win_rate:.1%}, "
                    f"PF: {strategy.profit_factor:.2f}, "
                    f"Trades: {strategy.total_trades}")
            else:
                strategy.log_change("quant", "backtest_failed", "Could not parse results")
                strategy.status = StrategyStatus.RETIRED
        except Exception as e:
            logger.error(f"Backtest parsing failed: {e}")
            strategy.status = StrategyStatus.RETIRED

    # ── Risk Review ─────────────────────────────────────────────

    async def _risk_review(self, strategy: Strategy):
        """Have the Risk agent validate and set constraints."""
        logger.info(f"🛡️ Risk review for: {strategy.name}")

        # First: automated rule-based checks
        fails = []
        if strategy.sharpe_ratio < self.config.min_sharpe_for_deploy:
            fails.append(f"Sharpe {strategy.sharpe_ratio:.2f} < {self.config.min_sharpe_for_deploy}")
        if strategy.profit_factor < self.config.min_profit_factor:
            fails.append(f"PF {strategy.profit_factor:.2f} < {self.config.min_profit_factor}")
        if strategy.total_trades < self.config.min_backtest_trades:
            fails.append(f"Trades {strategy.total_trades} < {self.config.min_backtest_trades}")
        if strategy.win_rate < self.config.min_win_rate:
            fails.append(f"Win rate {strategy.win_rate:.1%} < {self.config.min_win_rate:.1%}")
        if strategy.max_drawdown > self.config.max_total_drawdown:
            fails.append(f"MaxDD {strategy.max_drawdown:.1%} > {self.config.max_total_drawdown:.1%}")

        if fails:
            strategy.status = StrategyStatus.RETIRED
            strategy.log_change("risk", "rejected", f"Failed checks: {'; '.join(fails)}")
            await self._notify(
                f"🛡️ *Strategy Rejected*\n"
                f"Name: {strategy.name}\n"
                f"Reasons:\n" + "\n".join(f"  ❌ {f}" for f in fails)
            )
            return

        # Then: AI-based deeper risk analysis
        risk_prompt = f"""You are the risk manager of an autonomous hedge fund.

Review this strategy for deployment:
- Name: {strategy.name}
- Assets: {', '.join(strategy.assets)}
- Sharpe: {strategy.sharpe_ratio:.2f}
- Max Drawdown: {strategy.max_drawdown:.1%}
- Win Rate: {strategy.win_rate:.1%}
- Profit Factor: {strategy.profit_factor:.2f}
- Total Trades: {strategy.total_trades}
- Backtest Data: {json.dumps(strategy.backtest_results, default=str)[:2000]}

Current portfolio:
- Available capital: ${self.portfolio_state['cash']:,.2f}
- Active strategies: {len([s for s in self.strategies.values() if s.status == StrategyStatus.LIVE])}
- Max allocation per strategy: {self.config.max_single_strategy_allocation:.0%}

Determine:
1. Recommended position size (% of capital)
2. Stop loss level (%)
3. Take profit level (%)
4. Max daily loss for this strategy ($)
5. Any concerns or red flags
6. APPROVE or REJECT

Return as JSON:
{{
  "decision": "approve" or "reject",
  "position_size_pct": float,
  "stop_loss_pct": float,
  "take_profit_pct": float,
  "max_daily_loss_usd": float,
  "concerns": ["..."],
  "reasoning": "..."
}}"""

        result = await self.orchestrator.route_and_execute(risk_prompt)
        
        try:
            risk_data = self._parse_json_from_response(result)
            if risk_data and risk_data.get("decision") == "approve":
                strategy.max_position_size = min(
                    risk_data.get("position_size_pct", 0.1),
                    self.config.max_single_strategy_allocation
                )
                strategy.stop_loss_pct = risk_data.get("stop_loss_pct", 0.05)
                strategy.take_profit_pct = risk_data.get("take_profit_pct", 0.10)
                strategy.max_daily_loss = risk_data.get("max_daily_loss_usd", 100)
                strategy.status = StrategyStatus.APPROVED
                strategy.log_change("risk", "approved", 
                    f"Position: {strategy.max_position_size:.1%}, "
                    f"SL: {strategy.stop_loss_pct:.1%}, "
                    f"TP: {strategy.take_profit_pct:.1%}")

                await self._notify(
                    f"✅ *Strategy Approved*\n"
                    f"Name: {strategy.name}\n"
                    f"Position size: {strategy.max_position_size:.1%}\n"
                    f"Stop loss: {strategy.stop_loss_pct:.1%}\n"
                    f"Sharpe: {strategy.sharpe_ratio:.2f}"
                )
            else:
                strategy.status = StrategyStatus.RETIRED
                concerns = risk_data.get("concerns", []) if risk_data else ["Failed risk review"]
                strategy.log_change("risk", "rejected", str(concerns))
        except Exception as e:
            logger.error(f"Risk review parsing failed: {e}")

    # ── Deploy Strategy ─────────────────────────────────────────

    async def _deploy_strategy(self, strategy: Strategy):
        """Have the Engineer agent deploy an approved strategy."""
        logger.info(f"🚀 Deploying strategy: {strategy.name}")

        deploy_prompt = f"""You are the deployment engineer for an autonomous hedge fund.

Deploy this approved strategy:
- Name: {strategy.name}
- Assets: {', '.join(strategy.assets)}
- Timeframe: {strategy.timeframe}
- Position Size: {strategy.max_position_size:.1%} of ${self.config.total_capital:,.2f}
- Stop Loss: {strategy.stop_loss_pct:.1%}
- Take Profit: {strategy.take_profit_pct:.1%}
- Max Daily Loss: ${strategy.max_daily_loss:,.2f}
- Execution Mode: {self.config.execution_mode}
- Broker: {self.config.broker}

Strategy code from backtest:
{strategy.strategy_code[:3000]}

Tasks:
1. Adapt the backtest code into a LIVE strategy runner that:
   - Connects to the {self.config.broker} API (use webhook for TradersPost)
   - Runs on a {strategy.timeframe} loop
   - Implements the exact entry/exit logic from the backtest
   - Enforces the risk limits above
   - Logs every trade and decision
   - Sends Telegram notifications on trades
   {"- Starts in PAPER TRADE mode (log trades but don't execute)" if self.config.execution_mode == "paper" else "- Executes LIVE trades"}

2. Write the strategy as a standalone Python file that can be run with:
   `python strategies/{strategy.id}.py`

3. Write a config JSON file for the strategy parameters

Save both files to the workspace. Return the filenames."""

        result = await self.orchestrator.route_and_execute(deploy_prompt)
        
        strategy.status = StrategyStatus.DEPLOYED
        strategy.paper_trade_days = 0
        strategy.live_start_date = datetime.utcnow().isoformat()
        strategy.log_change("engineer", "deployed", f"Mode: {self.config.execution_mode}")

        await self._notify(
            f"🚀 *Strategy Deployed*\n"
            f"Name: {strategy.name}\n"
            f"Mode: {self.config.execution_mode}\n"
            f"Paper trade period: {self.config.paper_trade_days_required} days"
        )

    # ── Monitor Cycle ───────────────────────────────────────────

    async def _monitor_cycle(self):
        """Check all live/deployed strategies and adapt if needed."""
        live_strategies = [
            s for s in self.strategies.values()
            if s.status in (StrategyStatus.LIVE, StrategyStatus.DEPLOYED)
        ]

        if not live_strategies:
            return

        for strategy in live_strategies:
            # Check if paper trade period is complete
            if strategy.status == StrategyStatus.DEPLOYED:
                if strategy.live_start_date:
                    start = datetime.fromisoformat(strategy.live_start_date)
                    days_elapsed = (datetime.utcnow() - start).days
                    strategy.paper_trade_days = days_elapsed

                    if days_elapsed >= self.config.paper_trade_days_required:
                        strategy.status = StrategyStatus.LIVE
                        strategy.log_change("monitor", "promoted_to_live",
                            f"Paper traded for {days_elapsed} days")
                        await self._notify(
                            f"📈 *Strategy Going Live*\n"
                            f"Name: {strategy.name}\n"
                            f"Paper trade P&L: ${strategy.live_pnl:,.2f}")

        # Get performance report from trading agent
        monitor_prompt = f"""Check the current performance of these live strategies and provide a status update:

{json.dumps([{
    'name': s.name,
    'assets': s.assets,
    'status': s.status.value,
    'live_pnl': s.live_pnl,
    'live_trades': s.live_trades,
} for s in live_strategies], indent=2)}

For each strategy, check:
1. Current price of the assets
2. Whether any stop losses or take profits should have triggered
3. Overall health of the strategy given current market conditions

If a strategy is underperforming (negative Sharpe in live), flag it for review."""

        await self.orchestrator.route_and_execute(monitor_prompt)

    # ── Rebalance Cycle ─────────────────────────────────────────

    async def _rebalance_cycle(self):
        """Re-evaluate all strategies and adjust allocations."""
        logger.info("⚖️ Starting rebalance cycle")

        live = [s for s in self.strategies.values() if s.status == StrategyStatus.LIVE]
        if not live:
            return

        rebalance_prompt = f"""You are the portfolio manager of an autonomous hedge fund.

Current portfolio:
- Total capital: ${self.config.total_capital:,.2f}
- Cash available: ${self.portfolio_state['cash']:,.2f}
- Daily P&L: ${self.portfolio_state['daily_pnl']:,.2f}
- Weekly P&L: ${self.portfolio_state['weekly_pnl']:,.2f}

Active strategies:
{json.dumps([{
    'name': s.name,
    'assets': s.assets,
    'allocation': s.max_position_size,
    'live_pnl': s.live_pnl,
    'sharpe': s.sharpe_ratio,
    'max_drawdown': s.max_drawdown,
    'live_trades': s.live_trades,
} for s in live], indent=2)}

Tasks:
1. Should any strategies be paused or retired based on live performance?
2. Should allocations be adjusted?
3. Are any strategies too correlated (trading similar assets/patterns)?
4. Recommend changes.

Return as JSON:
{{
  "changes": [
    {{"strategy_name": "...", "action": "keep|pause|retire|adjust_allocation", "new_allocation": float, "reason": "..."}}
  ],
  "portfolio_health": "healthy|caution|critical",
  "notes": "..."
}}"""

        result = await self.orchestrator.route_and_execute(rebalance_prompt)
        
        try:
            rebalance_data = self._parse_json_from_response(result)
            if rebalance_data:
                for change in rebalance_data.get("changes", []):
                    action = change.get("action", "keep")
                    name = change.get("strategy_name", "")
                    
                    for s in live:
                        if s.name == name:
                            if action == "pause":
                                s.status = StrategyStatus.PAUSED
                                s.log_change("portfolio_manager", "paused", change.get("reason", ""))
                                await self._notify(f"⏸️ *Strategy Paused*: {s.name}\nReason: {change.get('reason', 'N/A')}")
                            elif action == "retire":
                                s.status = StrategyStatus.RETIRED
                                s.log_change("portfolio_manager", "retired", change.get("reason", ""))
                                await self._notify(f"🏁 *Strategy Retired*: {s.name}\nReason: {change.get('reason', 'N/A')}")
                            elif action == "adjust_allocation":
                                old_alloc = s.max_position_size
                                s.max_position_size = change.get("new_allocation", s.max_position_size)
                                s.log_change("portfolio_manager", "rebalanced",
                                    f"Allocation: {old_alloc:.1%} → {s.max_position_size:.1%}")
        except Exception as e:
            logger.error(f"Rebalance parsing failed: {e}")

    # ── Pipeline Processor ──────────────────────────────────────

    async def _process_pipeline(self):
        """Move strategies through the pipeline stages."""
        for strategy in list(self.strategies.values()):
            if strategy.status == StrategyStatus.BACKTESTING:
                await self._backtest_strategy(strategy)
            elif strategy.status == StrategyStatus.RISK_REVIEW:
                await self._risk_review(strategy)
            elif strategy.status == StrategyStatus.APPROVED:
                await self._deploy_strategy(strategy)

    # ── Circuit Breakers ────────────────────────────────────────

    def _check_circuit_breakers(self) -> bool:
        """Emergency stop checks. Returns True if fund should be paused."""
        daily_pnl_pct = self.portfolio_state["daily_pnl"] / self.config.total_capital
        weekly_pnl_pct = self.portfolio_state["weekly_pnl"] / self.config.total_capital
        total_pnl_pct = self.portfolio_state["total_pnl"] / self.config.total_capital

        if daily_pnl_pct < -self.config.max_daily_drawdown:
            self._trigger_circuit_breaker("daily", daily_pnl_pct)
            return True
        if weekly_pnl_pct < -self.config.max_weekly_drawdown:
            self._trigger_circuit_breaker("weekly", weekly_pnl_pct)
            return True
        if total_pnl_pct < -self.config.max_total_drawdown:
            self._trigger_circuit_breaker("total", total_pnl_pct)
            return True
        return False

    def _trigger_circuit_breaker(self, timeframe: str, loss_pct: float):
        """Pause all strategies and alert human."""
        logger.critical(f"🚨 CIRCUIT BREAKER: {timeframe} loss {loss_pct:.1%}")
        self.is_paused = True
        for s in self.strategies.values():
            if s.status == StrategyStatus.LIVE:
                s.status = StrategyStatus.PAUSED
                s.log_change("circuit_breaker", "emergency_pause",
                    f"{timeframe} drawdown limit hit: {loss_pct:.1%}")
        # This MUST notify immediately
        asyncio.create_task(self._notify(
            f"🚨🚨🚨 *CIRCUIT BREAKER TRIGGERED*\n"
            f"Timeframe: {timeframe}\n"
            f"Loss: {loss_pct:.1%}\n"
            f"ALL strategies PAUSED\n"
            f"Manual intervention required.\n"
            f"Use /resume to restart or /kill to shut down."
        ))

    # ── Helpers ─────────────────────────────────────────────────

    def _parse_research_results(self, response: str) -> list[dict]:
        """Extract opportunity list from agent response."""
        data = self._parse_json_from_response(response)
        if data and "opportunities" in data:
            return data["opportunities"]
        return []

    def _parse_json_from_response(self, response: str) -> Optional[dict]:
        """Try to extract JSON from an agent response."""
        # Try direct parse first
        try:
            return json.loads(response)
        except (json.JSONDecodeError, TypeError):
            pass

        # Try to find JSON block in the text
        if not isinstance(response, str):
            return None
            
        for start_marker in ["{", "```json\n", "```\n"]:
            idx = response.find(start_marker)
            if idx != -1:
                json_str = response[idx:]
                if json_str.startswith("```"):
                    json_str = json_str.split("\n", 1)[1].rsplit("```", 1)[0]
                # Find matching closing brace
                depth = 0
                for i, c in enumerate(json_str):
                    if c == "{":
                        depth += 1
                    elif c == "}":
                        depth -= 1
                        if depth == 0:
                            try:
                                return json.loads(json_str[:i+1])
                            except json.JSONDecodeError:
                                continue
        return None

    async def _notify(self, message: str):
        """Send notification via Telegram."""
        if self.notify:
            try:
                await self.notify(message)
            except Exception as e:
                logger.error(f"Notification failed: {e}")
        logger.info(f"NOTIFY: {message}")

    # ── Status / Control ────────────────────────────────────────

    def get_status(self) -> str:
        """Generate a status report."""
        lines = [
            "📊 *Fund Status Report*\n",
            f"Capital: ${self.config.total_capital:,.2f}",
            f"Cash: ${self.portfolio_state['cash']:,.2f}",
            f"Daily P&L: ${self.portfolio_state['daily_pnl']:,.2f}",
            f"Total P&L: ${self.portfolio_state['total_pnl']:,.2f}",
            f"Mode: {self.config.execution_mode}",
            f"Status: {'⏸️ PAUSED' if self.is_paused else '🟢 RUNNING'}",
            f"Cycle: #{self.cycle_count}\n",
            "*Strategies:*"
        ]
        for s in self.strategies.values():
            icon = {
                StrategyStatus.RESEARCHING: "🔬",
                StrategyStatus.BACKTESTING: "📊",
                StrategyStatus.RISK_REVIEW: "🛡️",
                StrategyStatus.APPROVED: "✅",
                StrategyStatus.DEPLOYED: "📋",
                StrategyStatus.LIVE: "🟢",
                StrategyStatus.PAUSED: "⏸️",
                StrategyStatus.RETIRED: "🏁",
            }.get(s.status, "❓")
            lines.append(f"{icon} {s.name} [{s.status.value}] P&L: ${s.live_pnl:,.2f}")

        return "\n".join(lines)

    def resume(self):
        """Resume after circuit breaker."""
        self.is_paused = False
        for s in self.strategies.values():
            if s.status == StrategyStatus.PAUSED:
                s.status = StrategyStatus.LIVE
                s.log_change("human", "resumed", "Manual resume after circuit breaker")
