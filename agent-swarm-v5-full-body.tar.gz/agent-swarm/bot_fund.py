"""
Agent Swarm - Telegram Bot with Autonomous Hedge Fund

Standard agent commands:
  /start       - Welcome message
  /agents      - List available agents
  /direct      - Send task directly to an agent

Fund management commands:
  /fund_start  - Start the autonomous fund loop
  /fund_stop   - Stop the fund gracefully
  /fund_status - Full portfolio and strategy report
  /fund_config - View/update fund configuration
  /resume      - Resume after circuit breaker
  /kill        - Emergency: stop everything immediately
  /strategies  - List all strategies and their status
  /approve     - Manually approve a strategy
  /reject      - Manually reject a strategy
  /pause       - Pause a specific strategy
  /set_mode    - Switch between paper and live trading

Any other message gets routed through the orchestrator.
"""
import asyncio
import logging
import json
from datetime import datetime
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)
from agents.orchestrator import Orchestrator
from hedge_fund.fund_manager import FundManager, FundConfig, StrategyStatus
from config.settings import settings

logging.basicConfig(
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    level=logging.INFO
)
logger = logging.getLogger("AgentSwarm")

# Globals
orchestrator = Orchestrator()
fund_config = FundConfig()
fund_manager: FundManager = None
fund_task: asyncio.Task = None
active_tasks: dict[int, int] = {}

# Telegram notification callback
_bot_app = None

async def telegram_notify(message: str):
    """Send a notification to all allowed users."""
    if _bot_app and settings.ALLOWED_USERS:
        for user_id in settings.ALLOWED_USERS:
            try:
                await _bot_app.bot.send_message(
                    chat_id=user_id,
                    text=message,
                    parse_mode="Markdown"
                )
            except Exception as e:
                logger.error(f"Failed to notify {user_id}: {e}")


# ── Auth ────────────────────────────────────────────────────────

def authorized(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if settings.ALLOWED_USERS and user_id not in settings.ALLOWED_USERS:
            await update.message.reply_text("⛔ Unauthorized.")
            return
        return await func(update, context)
    return wrapper


# ── Standard Agent Commands ─────────────────────────────────────

@authorized
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome = """🤖 *Agent Swarm + Hedge Fund*

*Agent Commands:*
/agents - List agents
/direct `<agent> <task>` - Direct task to agent

*Fund Commands:*
/fund\\_start - Launch autonomous fund
/fund\\_stop - Stop fund loop
/fund\\_status - Portfolio report
/strategies - List all strategies
/set\\_mode `paper|live` - Switch mode
/resume - Resume after circuit breaker
/kill - Emergency stop

Or just type naturally and I'll route it."""
    await update.message.reply_text(welcome, parse_mode="Markdown")


@authorized
async def cmd_agents(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lines = ["📋 *Agents*\n"]
    for key, agent in orchestrator.agents.items():
        lines.append(f"*{key}* - {agent.description}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


@authorized
async def cmd_direct(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.replace("/direct", "", 1).strip()
    parts = text.split(" ", 1)
    if len(parts) < 2:
        await update.message.reply_text("Usage: /direct `<agent> <task>`", parse_mode="Markdown")
        return
    agent_key, task = parts[0].lower(), parts[1]
    if agent_key not in orchestrator.agents:
        await update.message.reply_text(f"Unknown agent. Available: {', '.join(orchestrator.agents.keys())}")
        return

    await update.message.reply_text(f"⏳ Sending to *{agent_key.upper()}*...", parse_mode="Markdown")
    result = await orchestrator.agents[agent_key].run(task)
    orchestrator.agents[agent_key].reset()
    icon = "✅" if result.success else "❌"
    await _send_long(update, f"{icon} *{agent_key.upper()}* ({result.elapsed_seconds:.1f}s)\n\n{result.response}")


# ── Fund Management Commands ────────────────────────────────────

@authorized
async def cmd_fund_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global fund_manager, fund_task

    if fund_task and not fund_task.done():
        await update.message.reply_text("⚠️ Fund is already running. Use /fund_stop first.")
        return

    fund_manager = FundManager(
        config=fund_config,
        orchestrator=orchestrator,
        telegram_notify=telegram_notify
    )

    fund_task = asyncio.create_task(fund_manager.run())
    await update.message.reply_text(
        f"🚀 *Fund Started*\n"
        f"Capital: ${fund_config.total_capital:,.2f}\n"
        f"Mode: {fund_config.execution_mode}\n"
        f"Research interval: {fund_config.research_interval_hours}h\n"
        f"Monitor interval: {fund_config.monitor_interval_minutes}m\n\n"
        f"The fund will now autonomously research, backtest, validate, "
        f"deploy, and monitor trading strategies. You'll receive "
        f"Telegram notifications for all key decisions.",
        parse_mode="Markdown"
    )


@authorized
async def cmd_fund_stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global fund_task
    if fund_manager:
        await fund_manager.stop()
        if fund_task:
            fund_task.cancel()
            fund_task = None
        await update.message.reply_text("🛑 Fund stopped gracefully.")
    else:
        await update.message.reply_text("Fund is not running.")


@authorized
async def cmd_fund_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not fund_manager:
        await update.message.reply_text("Fund is not running. Use /fund_start")
        return
    await _send_long(update, fund_manager.get_status())


@authorized
async def cmd_strategies(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not fund_manager or not fund_manager.strategies:
        await update.message.reply_text("No strategies yet. Start the fund with /fund_start")
        return

    for sid, s in fund_manager.strategies.items():
        lines = [
            f"*{s.name}* (`{sid}`)",
            f"Status: {s.status.value}",
            f"Assets: {', '.join(s.assets)}",
            f"Timeframe: {s.timeframe}",
        ]
        if s.sharpe_ratio:
            lines.extend([
                f"Sharpe: {s.sharpe_ratio:.2f}",
                f"Max DD: {s.max_drawdown:.1%}",
                f"Win Rate: {s.win_rate:.1%}",
                f"PF: {s.profit_factor:.2f}",
            ])
        if s.status in (StrategyStatus.LIVE, StrategyStatus.DEPLOYED):
            lines.extend([
                f"Live P&L: ${s.live_pnl:,.2f}",
                f"Live Trades: {s.live_trades}",
                f"Paper Days: {s.paper_trade_days}",
            ])
        if s.change_log:
            last = s.change_log[-1]
            lines.append(f"Last action: {last['agent']} → {last['action']}")

        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


@authorized
async def cmd_set_mode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.replace("/set_mode", "", 1).strip().lower()
    if text not in ("paper", "live"):
        await update.message.reply_text("Usage: /set_mode `paper` or /set_mode `live`", parse_mode="Markdown")
        return

    fund_config.execution_mode = text
    if fund_manager:
        fund_manager.config.execution_mode = text

    emoji = "📋" if text == "paper" else "💰"
    await update.message.reply_text(f"{emoji} Execution mode set to *{text.upper()}*", parse_mode="Markdown")

    if text == "live":
        await update.message.reply_text(
            "⚠️ *WARNING*: Live mode will execute real trades.\n"
            "Make sure your broker API keys are configured correctly."
            , parse_mode="Markdown"
        )


@authorized
async def cmd_resume(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if fund_manager:
        fund_manager.resume()
        await update.message.reply_text("▶️ Fund resumed. All paused strategies reactivated.")
    else:
        await update.message.reply_text("Fund is not running.")


@authorized
async def cmd_kill(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Emergency stop - kills everything immediately."""
    global fund_task
    if fund_manager:
        fund_manager.is_running = False
        fund_manager.is_paused = True
        for s in fund_manager.strategies.values():
            if s.status in (StrategyStatus.LIVE, StrategyStatus.DEPLOYED):
                s.status = StrategyStatus.PAUSED
        if fund_task:
            fund_task.cancel()
            fund_task = None
    await update.message.reply_text("🚨 *EMERGENCY STOP* - All strategies paused, fund loop killed.", parse_mode="Markdown")


@authorized
async def cmd_fund_config(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show current fund configuration."""
    config_text = f"""⚙️ *Fund Configuration*

💰 Capital: ${fund_config.total_capital:,.2f}
📊 Max per strategy: {fund_config.max_single_strategy_allocation:.0%}
📊 Max total deployed: {fund_config.max_total_deployed:.0%}

🛡️ *Risk Limits:*
Daily drawdown limit: {fund_config.max_daily_drawdown:.1%}
Weekly drawdown limit: {fund_config.max_weekly_drawdown:.1%}
Total drawdown limit: {fund_config.max_total_drawdown:.1%}
Min Sharpe for deploy: {fund_config.min_sharpe_for_deploy}
Min Profit Factor: {fund_config.min_profit_factor}
Min backtest trades: {fund_config.min_backtest_trades}

⏱️ *Timing:*
Research every: {fund_config.research_interval_hours}h
Monitor every: {fund_config.monitor_interval_minutes}m
Rebalance every: {fund_config.rebalance_interval_hours}h
Paper trade period: {fund_config.paper_trade_days_required} days

🔧 *Execution:*
Mode: {fund_config.execution_mode}
Broker: {fund_config.broker}
Human approval above: ${fund_config.human_approval_above_usd:,.2f}"""

    await update.message.reply_text(config_text, parse_mode="Markdown")


# ── General Message Handler ─────────────────────────────────────

@authorized
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    task = update.message.text.strip()
    if not task:
        return

    current = active_tasks.get(user_id, 0)
    if current >= settings.MAX_CONCURRENT_TASKS:
        await update.message.reply_text(f"⚠️ {current} tasks active. Wait for one to finish.")
        return

    active_tasks[user_id] = current + 1
    await update.message.reply_text("⏳ Processing...")

    try:
        response = await orchestrator.route_and_execute(task)
        await _send_long(update, response)
    except Exception as e:
        logger.error(f"Task failed: {e}", exc_info=True)
        await update.message.reply_text(f"❌ Error: {str(e)}")
    finally:
        active_tasks[user_id] = max(0, active_tasks.get(user_id, 1) - 1)


# ── Helpers ─────────────────────────────────────────────────────

async def _send_long(update: Update, text: str, chunk_size: int = 4000):
    if len(text) <= chunk_size:
        try:
            await update.message.reply_text(text, parse_mode="Markdown")
        except Exception:
            await update.message.reply_text(text)
        return
    chunks = []
    while text:
        if len(text) <= chunk_size:
            chunks.append(text)
            break
        split_at = text.rfind("\n", 0, chunk_size)
        if split_at == -1:
            split_at = chunk_size
        chunks.append(text[:split_at])
        text = text[split_at:].lstrip("\n")
    for chunk in chunks:
        try:
            await update.message.reply_text(chunk, parse_mode="Markdown")
        except Exception:
            await update.message.reply_text(chunk)
        await asyncio.sleep(0.3)


# ── Main ────────────────────────────────────────────────────────

def main():
    global _bot_app

    if not settings.TELEGRAM_BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN not set!")
        return
    if not settings.ANTHROPIC_API_KEY:
        logger.error("ANTHROPIC_API_KEY not set!")
        return

    logger.info("Starting Agent Swarm + Hedge Fund Bot...")

    app = Application.builder().token(settings.TELEGRAM_BOT_TOKEN).build()
    _bot_app = app

    # Standard commands
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("agents", cmd_agents))
    app.add_handler(CommandHandler("direct", cmd_direct))

    # Fund commands
    app.add_handler(CommandHandler("fund_start", cmd_fund_start))
    app.add_handler(CommandHandler("fund_stop", cmd_fund_stop))
    app.add_handler(CommandHandler("fund_status", cmd_fund_status))
    app.add_handler(CommandHandler("fund_config", cmd_fund_config))
    app.add_handler(CommandHandler("strategies", cmd_strategies))
    app.add_handler(CommandHandler("set_mode", cmd_set_mode))
    app.add_handler(CommandHandler("resume", cmd_resume))
    app.add_handler(CommandHandler("kill", cmd_kill))

    # Catch-all
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
